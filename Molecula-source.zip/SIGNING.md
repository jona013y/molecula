# Release signing

Molecula does not currently have publisher certificates configured. Without
them, macOS Gatekeeper asks users to approve the app and Windows SmartScreen
shows an unrecognized-app prompt. The local package helpers are prepared, but
the public release workflow still needs to be wired to them and configured with
the owner's certificates before a signed installer can be published. Never
commit certificates, passwords, or app-specific passwords.

## macOS

Requires an Apple Developer Program membership, a **Developer ID Application**
certificate exported as a password-protected `.p12`, and an app-specific Apple
ID password. Apple only notarizes Developer ID-signed software. Add these
repository Actions secrets:

| Secret | Value |
| --- | --- |
| `APPLE_CERTIFICATE_P12` | Base64-encoded `.p12` certificate |
| `APPLE_CERTIFICATE_PASSWORD` | Password used to export the `.p12` |
| `APPLE_SIGNING_IDENTITY` | Full Developer ID Application identity |
| `APPLE_ID` | Apple ID email for notarization |
| `APPLE_APP_SPECIFIC_PASSWORD` | App-specific password |
| `APPLE_TEAM_ID` | Apple Developer Team ID |

The planned workflow will import the certificate into a temporary CI
keychain, sign the app with Hardened Runtime, submit the DMG to Apple's notary
service, and staple the notarization ticket. Apple's membership price and
local availability are set by Apple.

## Windows

To display a verified publisher and begin building publisher reputation, add:

| Secret | Value |
| --- | --- |
| `WINDOWS_SIGNING_CERTIFICATE_BASE64` | Base64-encoded Authenticode `.pfx` |
| `WINDOWS_SIGNING_CERTIFICATE_PASSWORD` | Password used to export the `.pfx` |

The workflow signs the installer with SHA-256 and a trusted timestamp. A
signature does **not** guarantee that SmartScreen stops warning on first
downloads: Microsoft says new signed files can still need reputation. The
reliable way to avoid SmartScreen download warnings is Microsoft Store
distribution (normally an MSIX package). Do not turn off SmartScreen or ask
users to bypass it.

Until these secrets are configured, release builds remain unsigned. The
signing setup cannot be completed without the owner's certificates and account
access.
