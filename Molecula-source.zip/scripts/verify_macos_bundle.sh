#!/bin/bash
set -euo pipefail

APP="${1:?Usage: verify_macos_bundle.sh APP [arm64|universal]}"
MODE="${2:-arm64}"
INFO="$APP/Contents/Info.plist"
PKGINFO="$APP/Contents/PkgInfo"

test -d "$APP/Contents"
/usr/bin/plutil -lint "$INFO"
EXECUTABLE=$(/usr/libexec/PlistBuddy -c 'Print :CFBundleExecutable' "$INFO")
ICON=$(/usr/libexec/PlistBuddy -c 'Print :CFBundleIconFile' "$INFO")
ICON_PATH="$APP/Contents/Resources/$ICON"
test -x "$APP/Contents/MacOS/$EXECUTABLE" || {
  echo "Missing executable named by CFBundleExecutable: $EXECUTABLE" >&2
  exit 1
}
test -f "$ICON_PATH" || {
  echo "Missing Dock icon named by CFBundleIconFile: $ICON" >&2
  exit 1
}
test "$(cat "$PKGINFO")" = 'APPL????' || {
  echo "PkgInfo is missing or does not identify an application bundle" >&2
  exit 1
}

ICON_CHECK=$(mktemp -d "${TMPDIR:-/tmp}/molecula-icon-check.XXXXXX")
trap 'rm -rf "$ICON_CHECK"' EXIT
/usr/bin/iconutil -c iconset "$ICON_PATH" -o "$ICON_CHECK/Molecula.iconset"
if [[ "$MODE" == "universal" ]]; then
  /usr/bin/lipo "$APP/Contents/MacOS/$EXECUTABLE" -verify_arch arm64 x86_64
elif [[ "$MODE" == "arm64" ]]; then
  /usr/bin/lipo "$APP/Contents/MacOS/$EXECUTABLE" -verify_arch arm64
else
  echo "Unknown macOS bundle mode: $MODE" >&2
  exit 2
fi
echo "Verified $APP bundle, Dock icon, and $MODE executable"
