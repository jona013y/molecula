"""Build the original Molecula macOS app icon (requires Pillow)."""
from pathlib import Path
from PIL import Image, ImageDraw

root = Path(__file__).resolve().parents[1]
out = root / "assets" / "Molecula.iconset"
out.mkdir(exist_ok=True)
size = 1024
im = Image.new("RGBA", (size, size), (0, 0, 0, 0))
d = ImageDraw.Draw(im)
d.rounded_rectangle((45, 45, 979, 979), radius=225, fill=(24, 37, 59))
d.rounded_rectangle((68, 68, 956, 956), radius=203, outline=(69, 93, 130), width=3)
points = [(284, 502), (494, 315), (746, 420), (701, 689), (423, 744)]
for a, b in [(0, 1), (1, 2), (2, 3), (3, 4), (4, 0), (1, 4)]:
    d.line((points[a], points[b]), fill=(113, 221, 208), width=30, joint="curve")
for i, (x, y) in enumerate(points):
    r = 57 if i == 1 else 45
    fill = (255, 255, 255) if i in (0, 2, 4) else (117, 220, 208)
    d.ellipse((x-r, y-r, x+r, y+r), fill=fill)
for px in (16, 32, 128, 256, 512):
    small = im.resize((px, px), Image.Resampling.LANCZOS)
    small.save(out / f"icon_{px}x{px}.png")
    if px < 512:
        large = im.resize((px*2, px*2), Image.Resampling.LANCZOS)
        large.save(out / f"icon_{px}x{px}@2x.png")
im.save(out / "icon_512x512@2x.png")
im.save(root / "assets" / "molecula-icon.png")
im.save(root / "assets" / "Molecula.ico", format="ICO", sizes=[(16, 16), (32, 32), (48, 48), (64, 64), (128, 128), (256, 256)])
parts=[]
for px, kind in [(128,b"ic07"),(256,b"ic08"),(512,b"ic09"),(1024,b"ic10")]:
    from io import BytesIO
    stream=BytesIO()
    im.resize((px,px),Image.Resampling.LANCZOS).save(stream,format="PNG")
    data=stream.getvalue()
    parts.append(kind+(len(data)+8).to_bytes(4,"big")+data)
body=b"".join(parts)
icon=root/"molecula.app"/"Contents"/"Resources"/"Molecula.icns"
icon.parent.mkdir(parents=True,exist_ok=True)
icon.write_bytes(b"icns"+(len(body)+8).to_bytes(4,"big")+body)
