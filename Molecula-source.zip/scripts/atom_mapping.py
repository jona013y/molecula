"""Optional, local reaction atom mapping via RDKit and AtomMapper."""
import sys

try:
    from rdkit import Chem
    from atommapper import map_atoms

    operation = sys.argv[1] if len(sys.argv) > 1 else ""
    data = sys.stdin.read()
    if operation != "map-pair":
        raise ValueError("Unsupported atom-mapping operation")
    reactant_block, product_block = data.split("\n$$$$\n", 1)
    reactant = Chem.MolFromMolBlock(reactant_block, sanitize=True, removeHs=False)
    product = Chem.MolFromMolBlock(product_block, sanitize=True, removeHs=False)
    if reactant is None or product is None:
        raise ValueError("AtomMapper could not read the selected reactant/product MOL blocks")
    result = map_atoms(reactant, product, element_change=True, objective="change")
    if result.status != "complete":
        raise ValueError(
            f"Atom mapping did not complete ({result.status}): {result.reason or 'no reason supplied'}. No map numbers were changed."
        )
    changed_identifiers = {change.identifier for change in result.atom_changes}
    for change in result.bond_changes:
        changed_identifiers.update(change.identifiers)
    sys.stdout.write(f"STATUS\t{result.status}\n")
    sys.stdout.write(f"OPTIMALITY\t{result.metadata.get('optimality', 'unknown')}\n")
    sys.stdout.write(f"ENGINE\tAtomMapper {result.metadata.get('versions', {}).get('atommapper', 'unknown')} + RDKit {Chem.rdBase.rdkitVersion}\n")
    for pair in result.mapping:
        changed = 1 if pair.identifier in changed_identifiers else 0
        sys.stdout.write(f"PAIR\t{pair.source_index}\t{pair.target_index}\t{changed}\n")
except Exception as exc:
    sys.stdout.write(f"ERROR\t{exc}\n")
    raise SystemExit(1)
