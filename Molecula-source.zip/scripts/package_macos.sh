#!/bin/bash
set -euo pipefail

ROOT="$(cd "$(dirname "$0")/.." && pwd)"
MODE="${1:-arm64}"
APP_NAME="Molecula"
STAGE="$(mktemp -d "${TMPDIR:-/tmp}/molecula-package.XXXXXX")"
trap 'rm -rf "$STAGE"' EXIT

APP="$STAGE/$APP_NAME.app"
mkdir -p "$ROOT/dist"
ditto "$ROOT/molecula.app" "$APP"

case "$MODE" in
  arm64)
    cargo build --manifest-path "$ROOT/Cargo.toml" --release --locked --offline
    cp "$ROOT/target/release/marvin-rust" "$APP/Contents/MacOS/MolecularSketch"
    OUTPUT="$ROOT/dist/Molecula-macOS-arm64.dmg"
    ZIP_OUTPUT="$ROOT/dist/Molecula-macOS-arm64.zip"
    ;;
  universal)
    ARM="$ROOT/target/aarch64-apple-darwin/release/marvin-rust"
    INTEL="$ROOT/target/x86_64-apple-darwin/release/marvin-rust"
    test -f "$ARM" && test -f "$INTEL" || {
      echo "Build both aarch64-apple-darwin and x86_64-apple-darwin release targets first." >&2
      exit 1
    }
    lipo -create "$ARM" "$INTEL" -output "$APP/Contents/MacOS/MolecularSketch"
    OUTPUT="$ROOT/dist/Molecula-macOS-universal.dmg"
    ZIP_OUTPUT="$ROOT/dist/Molecula-macOS-universal.zip"
    ;;
  *)
    echo "Usage: $0 [arm64|universal]" >&2
    exit 2
    ;;
esac

chmod 755 "$APP/Contents/MacOS/MolecularSketch"
codesign --force --deep --sign - --timestamp=none "$APP"
ln -s /Applications "$STAGE/Applications"
cat > "$STAGE/Install-Molecula.txt" <<'EOF'
Install Molecula

1. Drag Molecula.app onto the Applications shortcut in this window.
2. Open Molecula from Applications.
3. If macOS says the app cannot be verified, Control-click Molecula.app in Applications,
   choose Open, then confirm. This build is not signed with an Apple Developer ID.
EOF

rm -f "$OUTPUT"
if hdiutil create -volname "$APP_NAME" -srcfolder "$STAGE" -ov -format UDZO "$OUTPUT"; then
  echo "Created $OUTPUT"
else
  rm -f "$OUTPUT"
  rm -f "$ZIP_OUTPUT"
  (cd "$STAGE" && /usr/bin/zip -qry -y "$ZIP_OUTPUT" .)
  echo "Disk image creation is unavailable here; created drag-to-Applications archive $ZIP_OUTPUT"
fi
