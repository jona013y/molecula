#!/bin/bash
set -euo pipefail

if [[ -z "${APPLE_CERTIFICATE_P12:-}" ]]; then
  echo "No Apple Developer ID certificate configured; building an ad-hoc-signed app."
  exit 0
fi

: "${APPLE_CERTIFICATE_PASSWORD:?Set APPLE_CERTIFICATE_PASSWORD}"
: "${APPLE_SIGNING_IDENTITY:?Set APPLE_SIGNING_IDENTITY}"
: "${APPLE_ID:?Set APPLE_ID}"
: "${APPLE_APP_SPECIFIC_PASSWORD:?Set APPLE_APP_SPECIFIC_PASSWORD}"
: "${APPLE_TEAM_ID:?Set APPLE_TEAM_ID}"

KEYCHAIN_PATH="$RUNNER_TEMP/molecula-signing.keychain-db"
KEYCHAIN_PASSWORD="$(openssl rand -hex 24)"
CERTIFICATE_PATH="$RUNNER_TEMP/molecula-signing.p12"
trap 'rm -f "$CERTIFICATE_PATH"' EXIT

printf '%s' "$APPLE_CERTIFICATE_P12" | base64 --decode > "$CERTIFICATE_PATH"
security create-keychain -p "$KEYCHAIN_PASSWORD" "$KEYCHAIN_PATH"
security set-keychain-settings -lut 21600 "$KEYCHAIN_PATH"
security unlock-keychain -p "$KEYCHAIN_PASSWORD" "$KEYCHAIN_PATH"
security import "$CERTIFICATE_PATH" -k "$KEYCHAIN_PATH" -P "$APPLE_CERTIFICATE_PASSWORD" -T /usr/bin/codesign
security set-key-partition-list -S apple-tool:,apple:,codesign: -s -k "$KEYCHAIN_PASSWORD" "$KEYCHAIN_PATH"
security list-keychains -d user -s "$KEYCHAIN_PATH"
security find-identity -v -p codesigning "$KEYCHAIN_PATH"

{
  printf 'MOLECULA_SIGNING_IDENTITY=%s\n' "$APPLE_SIGNING_IDENTITY"
  printf 'APPLE_ID=%s\n' "$APPLE_ID"
  printf 'APPLE_APP_SPECIFIC_PASSWORD=%s\n' "$APPLE_APP_SPECIFIC_PASSWORD"
  printf 'APPLE_TEAM_ID=%s\n' "$APPLE_TEAM_ID"
} >> "$GITHUB_ENV"
