"""Optional RDKit descriptor worker. Reads one MOL block from stdin."""
import sys

try:
    from rdkit import Chem, rdBase
    from rdkit.Chem import AllChem, Descriptors, rdMolDescriptors
    try:
        from rdkit.Chem import rdFreeSASA
    except ImportError:
        rdFreeSASA = None
except ImportError as exc:
    print("ERROR\tRDKit is not installed in the selected Python environment", flush=True)
    raise SystemExit(2) from exc

block = sys.stdin.read()
mol = Chem.MolFromMolBlock(block, sanitize=True, removeHs=False)
if mol is None:
    print("ERROR\tRDKit could not sanitize the MOL structure", flush=True)
    raise SystemExit(3)

print("ENGINE\tRDKit " + rdBase.rdkitVersion)
values = [
    ("Molar mass", Descriptors.MolWt(mol), "g/mol", "RDKit MolWt"),
    ("Exact mass", Descriptors.ExactMolWt(mol), "Da", "RDKit ExactMolWt"),
    ("logP", Descriptors.MolLogP(mol), "", "Wildman-Crippen / RDKit MolLogP"),
    ("TPSA", Descriptors.TPSA(mol), "Å²", "RDKit TPSA"),
    ("H-bond donors", rdMolDescriptors.CalcNumHBD(mol), "", "RDKit CalcNumHBD"),
    ("H-bond acceptors", rdMolDescriptors.CalcNumHBA(mol), "", "RDKit CalcNumHBA"),
    ("Rotatable bonds", rdMolDescriptors.CalcNumRotatableBonds(mol), "", "RDKit CalcNumRotatableBonds"),
    ("Rings", rdMolDescriptors.CalcNumRings(mol), "", "RDKit CalcNumRings"),
    ("Molar refractivity", Descriptors.MolMR(mol), "cm³/mol", "Wildman-Crippen / RDKit MolMR"),
    ("Heteroatoms", rdMolDescriptors.CalcNumHeteroatoms(mol), "", "RDKit CalcNumHeteroatoms"),
    ("Aromatic rings", rdMolDescriptors.CalcNumAromaticRings(mol), "", "RDKit CalcNumAromaticRings"),
    ("Aliphatic rings", rdMolDescriptors.CalcNumAliphaticRings(mol), "", "RDKit CalcNumAliphaticRings"),
    ("Saturated rings", rdMolDescriptors.CalcNumSaturatedRings(mol), "", "RDKit CalcNumSaturatedRings"),
    ("Stereocenters", rdMolDescriptors.CalcNumAtomStereoCenters(mol), "", "RDKit CalcNumAtomStereoCenters"),
    ("Amide bonds", rdMolDescriptors.CalcNumAmideBonds(mol), "", "RDKit CalcNumAmideBonds"),
    ("Bridgehead atoms", rdMolDescriptors.CalcNumBridgeheadAtoms(mol), "", "RDKit CalcNumBridgeheadAtoms"),
    ("Spiro atoms", rdMolDescriptors.CalcNumSpiroAtoms(mol), "", "RDKit CalcNumSpiroAtoms"),
    ("Fraction sp3 carbon", rdMolDescriptors.CalcFractionCSP3(mol), "", "RDKit CalcFractionCSP3"),
    ("Labute ASA", rdMolDescriptors.CalcLabuteASA(mol), "Å²", "RDKit CalcLabuteASA; includes hydrogens"),
    ("Hall-Kier alpha", rdMolDescriptors.CalcHallKierAlpha(mol), "", "RDKit CalcHallKierAlpha"),
    ("Kappa 1", rdMolDescriptors.CalcKappa1(mol), "", "RDKit CalcKappa1"),
    ("Kappa 2", rdMolDescriptors.CalcKappa2(mol), "", "RDKit CalcKappa2"),
    ("Kappa 3", rdMolDescriptors.CalcKappa3(mol), "", "RDKit CalcKappa3"),
]
for name, value, unit, method in values:
    print(f"VALUE\t{name}\t{value:.4f}\t{unit}\t{method}")

if rdFreeSASA is None:
    print("UNAVAILABLE\tSolvent-accessible surface area\tThis RDKit build does not include rdFreeSASA")
else:
    # SASA depends on a 3D conformation. Generate a deterministic conformer
    # without changing the user's drawing and report the geometry protocol.
    sasa_mol = Chem.AddHs(Chem.Mol(mol))
    params = AllChem.ETKDGv3()
    params.randomSeed = 20261120
    conformer_id = AllChem.EmbedMolecule(sasa_mol, params)
    if conformer_id < 0:
        print("UNAVAILABLE\tSolvent-accessible surface area\tRDKit ETKDGv3 could not generate a 3D conformer")
    else:
        force_field_name = None
        if AllChem.MMFFHasAllMoleculeParams(sasa_mol):
            properties = AllChem.MMFFGetMoleculeProperties(sasa_mol, mmffVariant="MMFF94")
            force_field = AllChem.MMFFGetMoleculeForceField(sasa_mol, properties, confId=conformer_id)
            force_field_name = "MMFF94"
        elif AllChem.UFFHasAllMoleculeParams(sasa_mol):
            force_field = AllChem.UFFGetMoleculeForceField(sasa_mol, confId=conformer_id)
            force_field_name = "UFF"
        else:
            force_field = None
        if force_field is None:
            print("UNAVAILABLE\tSolvent-accessible surface area\tNo MMFF94 or UFF parameters are available to minimize the generated conformer")
        else:
            force_field.Minimize(maxIts=200)
            periodic_table = Chem.GetPeriodicTable()
            radii = [periodic_table.GetRvdw(atom.GetAtomicNum()) for atom in sasa_mol.GetAtoms()]
            options = rdFreeSASA.SASAOpts(
                rdFreeSASA.SASAAlgorithm.ShrakeRupley,
                rdFreeSASA.SASAClassifier.Protor,
                1.4,
            )
            area = rdFreeSASA.CalcSASA(sasa_mol, radii, conformer_id, opts=options)
            method = (
                "RDKit rdFreeSASA Shrake-Rupley; 1.4 Å probe and RDKit van der Waals radii; "
                f"ETKDGv3 conformer minimized with {force_field_name} (seed 20261120)"
            )
            print(f"VALUE\tSolvent-accessible surface area\t{area:.4f}\tÅ²\t{method}")
