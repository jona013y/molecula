"""Optional RDKit descriptor worker. Reads one MOL block from stdin."""
import sys

try:
    from rdkit import Chem, rdBase
    from rdkit.Chem import Descriptors, rdMolDescriptors
except ImportError as exc:
    print("ERROR\tRDKit is not installed in the selected Python environment", flush=True)
    raise SystemExit(2) from exc

block = sys.stdin.read()
mol = Chem.MolFromMolBlock(block, sanitize=True, removeHs=False)
if mol is None:
    print("ERROR\tRDKit could not sanitize the MOL structure", flush=True)
    raise SystemExit(3)

print("ENGINE\tRDKit " + rdBase.rdkitVersion)
values = [
    ("Molar mass", Descriptors.MolWt(mol), "g/mol", "RDKit MolWt"),
    ("Exact mass", Descriptors.ExactMolWt(mol), "Da", "RDKit ExactMolWt"),
    ("logP", Descriptors.MolLogP(mol), "", "Wildman-Crippen / RDKit MolLogP"),
    ("TPSA", Descriptors.TPSA(mol), "Å²", "RDKit TPSA"),
    ("H-bond donors", rdMolDescriptors.CalcNumHBD(mol), "", "RDKit CalcNumHBD"),
    ("H-bond acceptors", rdMolDescriptors.CalcNumHBA(mol), "", "RDKit CalcNumHBA"),
    ("Rotatable bonds", rdMolDescriptors.CalcNumRotatableBonds(mol), "", "RDKit CalcNumRotatableBonds"),
    ("Rings", rdMolDescriptors.CalcNumRings(mol), "", "RDKit CalcNumRings"),
    ("Molar refractivity", Descriptors.MolMR(mol), "cm³/mol", "Wildman-Crippen / RDKit MolMR"),
    ("Heteroatoms", rdMolDescriptors.CalcNumHeteroatoms(mol), "", "RDKit CalcNumHeteroatoms"),
    ("Aromatic rings", rdMolDescriptors.CalcNumAromaticRings(mol), "", "RDKit CalcNumAromaticRings"),
    ("Aliphatic rings", rdMolDescriptors.CalcNumAliphaticRings(mol), "", "RDKit CalcNumAliphaticRings"),
    ("Saturated rings", rdMolDescriptors.CalcNumSaturatedRings(mol), "", "RDKit CalcNumSaturatedRings"),
    ("Stereocenters", rdMolDescriptors.CalcNumAtomStereoCenters(mol), "", "RDKit CalcNumAtomStereoCenters"),
    ("Amide bonds", rdMolDescriptors.CalcNumAmideBonds(mol), "", "RDKit CalcNumAmideBonds"),
    ("Bridgehead atoms", rdMolDescriptors.CalcNumBridgeheadAtoms(mol), "", "RDKit CalcNumBridgeheadAtoms"),
    ("Spiro atoms", rdMolDescriptors.CalcNumSpiroAtoms(mol), "", "RDKit CalcNumSpiroAtoms"),
    ("Fraction sp3 carbon", rdMolDescriptors.CalcFractionCSP3(mol), "", "RDKit CalcFractionCSP3"),
    ("Labute ASA", rdMolDescriptors.CalcLabuteASA(mol), "Å²", "RDKit CalcLabuteASA; includes hydrogens"),
    ("Hall-Kier alpha", rdMolDescriptors.CalcHallKierAlpha(mol), "", "RDKit CalcHallKierAlpha"),
    ("Kappa 1", rdMolDescriptors.CalcKappa1(mol), "", "RDKit CalcKappa1"),
    ("Kappa 2", rdMolDescriptors.CalcKappa2(mol), "", "RDKit CalcKappa2"),
    ("Kappa 3", rdMolDescriptors.CalcKappa3(mol), "", "RDKit CalcKappa3"),
]
for name, value, unit, method in values:
    print(f"VALUE\t{name}\t{value:.4f}\t{unit}\t{method}")
