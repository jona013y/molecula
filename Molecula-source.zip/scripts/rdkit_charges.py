"""Optional RDKit Gasteiger-Marsili charge worker; reads one MOL block."""
import math
import sys

try:
    from rdkit import Chem, rdBase
    from rdkit.Chem import AllChem

    block = sys.stdin.read()
    mol = Chem.MolFromMolBlock(block, sanitize=True, removeHs=False)
    if mol is None:
        raise ValueError("RDKit could not sanitize the MOL structure")
    AllChem.ComputeGasteigerCharges(mol, nIter=12, throwOnParamFailure=True)
    sys.stdout.write(f"ENGINE\tRDKit {rdBase.rdkitVersion}\n")
    sys.stdout.write("METHOD\tGasteiger-Marsili iterative electronegativity equalization; RDKit parameterization; 12 iterations\n")
    sys.stdout.write("UNIT\te (elementary charge)\n")
    net_charge = 0.0
    formal_charge = sum(atom.GetFormalCharge() for atom in mol.GetAtoms())
    for atom in mol.GetAtoms():
        charge = float(atom.GetProp("_GasteigerCharge"))
        implicit_hydrogen_charge = float(atom.GetProp("_GasteigerHCharge"))
        if not math.isfinite(charge) or not math.isfinite(implicit_hydrogen_charge):
            raise ValueError(f"Gasteiger charge is undefined at atom {atom.GetIdx() + 1}")
        net_charge += charge + implicit_hydrogen_charge
        sys.stdout.write(
            f"ATOM\t{atom.GetIdx() + 1}\t{atom.GetSymbol()}\t{charge:.6f}\t{implicit_hydrogen_charge:.6f}\n"
        )
    if abs(net_charge - formal_charge) > 1e-4:
        raise ValueError("Gasteiger charge sum did not reproduce the structure's formal charge")
    sys.stdout.write(f"SUMMARY\tNet model charge\t{net_charge:.6f} e\tFormal charge\t{formal_charge}\n")
except Exception as exc:
    sys.stdout.write(f"ERROR\t{exc}\n")
    raise SystemExit(1)
