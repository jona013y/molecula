$ErrorActionPreference = "Stop"
$repo = (Resolve-Path (Join-Path $PSScriptRoot "..")).Path

Push-Location $repo
try {
    cargo test --locked
    if ($LASTEXITCODE -ne 0) { throw "cargo test failed: $LASTEXITCODE" }

    $previousRustFlags = $env:RUSTFLAGS
    $buildHome = $env:USERPROFILE
    try {
        $remapFlag = "--remap-path-prefix=$buildHome=~"
        if ($previousRustFlags) { $env:RUSTFLAGS = "$previousRustFlags $remapFlag" }
        else { $env:RUSTFLAGS = $remapFlag }
        cargo build --release --locked
    } finally {
        $env:RUSTFLAGS = $previousRustFlags
    }
    if ($LASTEXITCODE -ne 0) { throw "cargo build failed: $LASTEXITCODE" }

    $binaryPath = Join-Path $repo "target\release\molecula.exe"
    $binaryBytes = [System.IO.File]::ReadAllBytes($binaryPath)
    $buildPaths = @($buildHome, $buildHome.Replace('\', '/')) | Where-Object { $_ }
    $binaryViews = @(
        [System.Text.Encoding]::UTF8.GetString($binaryBytes),
        [System.Text.Encoding]::Unicode.GetString($binaryBytes)
    )
    foreach ($buildPath in $buildPaths) {
        foreach ($binaryView in $binaryViews) {
            if ($binaryView.IndexOf($buildPath, [System.StringComparison]::OrdinalIgnoreCase) -ge 0) {
                throw "The packaged executable contains the build user's home path."
            }
        }
    }

    $compiler = $env:INNO_SETUP_COMPILER
    if (-not $compiler) {
        $candidates = @(
            "${env:ProgramFiles(x86)}\Inno Setup 7\ISCC.exe",
            "${env:ProgramFiles(x86)}\Inno Setup 6\ISCC.exe",
            "$env:ProgramFiles\Inno Setup 7\ISCC.exe"
        )
        $compiler = $candidates | Where-Object { Test-Path $_ } | Select-Object -First 1
    }
    if (-not $compiler -or -not (Test-Path $compiler)) {
        throw "Inno Setup Compiler was not found. Install Inno Setup 6/7 or set INNO_SETUP_COMPILER."
    }

    New-Item -ItemType Directory -Force -Path (Join-Path $repo "dist\windows") | Out-Null
    Push-Location (Join-Path $repo "installers\windows")
    try {
        & $compiler "Molecula.iss"
        if ($LASTEXITCODE -ne 0) { throw "Inno Setup failed: $LASTEXITCODE" }
    } finally {
        Pop-Location
    }

    $installer = Join-Path $repo "dist\windows\Molecula-Windows-Setup.exe"
    if (-not (Test-Path $installer)) { throw "Installer output was not created: $installer" }
    Write-Host "Created $installer"
} finally {
    Pop-Location
}
