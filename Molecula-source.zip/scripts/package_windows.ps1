$ErrorActionPreference = "Stop"
$repo = (Resolve-Path (Join-Path $PSScriptRoot "..")).Path

Push-Location $repo
try {
    cargo test --locked
    if ($LASTEXITCODE -ne 0) { throw "cargo test failed: $LASTEXITCODE" }

    cargo build --release --locked
    if ($LASTEXITCODE -ne 0) { throw "cargo build failed: $LASTEXITCODE" }

    $compiler = $env:INNO_SETUP_COMPILER
    if (-not $compiler) {
        $candidates = @(
            "${env:ProgramFiles(x86)}\Inno Setup 7\ISCC.exe",
            "${env:ProgramFiles(x86)}\Inno Setup 6\ISCC.exe",
            "$env:ProgramFiles\Inno Setup 7\ISCC.exe"
        )
        $compiler = $candidates | Where-Object { Test-Path $_ } | Select-Object -First 1
    }
    if (-not $compiler -or -not (Test-Path $compiler)) {
        throw "Inno Setup Compiler was not found. Install Inno Setup 6/7 or set INNO_SETUP_COMPILER."
    }

    New-Item -ItemType Directory -Force -Path (Join-Path $repo "dist\windows") | Out-Null
    Push-Location (Join-Path $repo "installers\windows")
    try {
        & $compiler "Molecula.iss"
        if ($LASTEXITCODE -ne 0) { throw "Inno Setup failed: $LASTEXITCODE" }
    } finally {
        Pop-Location
    }

    $installer = Join-Path $repo "dist\windows\Molecula-Windows-Setup.exe"
    if (-not (Test-Path $installer)) { throw "Installer output was not created: $installer" }
    Write-Host "Created $installer"
} finally {
    Pop-Location
}
