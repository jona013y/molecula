import sys

try:
    from rdkit import Chem
    from rdkit.Chem import rdDepictor, AllChem
    from rdkit import rdBase

    def read_molblock(block):
        mol = Chem.MolFromMolBlock(block, sanitize=True, removeHs=False)
        if mol is not None:
            # Some RDKit versions retain an empty V2000 atom-map field as an
            # explicit map 0. Molecula uses zero to mean "unmapped".
            for atom in mol.GetAtoms():
                if atom.GetAtomMapNum() == 0 and atom.HasProp("molAtomMapNumber"):
                    atom.ClearProp("molAtomMapNumber")
        return mol

    op = sys.argv[1] if len(sys.argv) > 1 else ""
    data = sys.stdin.read()
    if op == "from-smiles":
        mol = Chem.MolFromSmiles(data.strip())
        if mol is None:
            raise ValueError("RDKit could not parse this SMILES string")
        rdDepictor.Compute2DCoords(mol)
        # CTfile coordinates do not reliably carry alkene stereo in all
        # toolkits, so transport RDKit's explicit bond assignment alongside
        # the standard MOL block for the editor's graph model.
        stereo = []
        for bond in mol.GetBonds():
            value = str(bond.GetStereo())
            if value in ("STEREOE", "STEREOTRANS"):
                stereo.append((bond.GetIdx() + 1, "E"))
            elif value in ("STEREOZ", "STEREOCIS"):
                stereo.append((bond.GetIdx() + 1, "Z"))
        for index, value in stereo:
            sys.stdout.write(f"BONDSTEREO\t{index}\t{value}\n")
        sys.stdout.write(Chem.MolToMolBlock(mol))
    elif op == "to-smiles":
        annotations = []
        molblock = []
        for line in data.splitlines():
            if line.startswith("BONDSTEREO\t"):
                fields = line.split("\t")
                if len(fields) != 3:
                    raise ValueError("Malformed explicit alkene stereo annotation")
                annotations.append((int(fields[1]) - 1, fields[2]))
            else:
                molblock.append(line)
        mol = read_molblock("\n".join(molblock))
        if mol is None:
            raise ValueError("RDKit could not parse this MOL structure")
        if annotations:
            Chem.AssignStereochemistry(mol, cleanIt=True, force=True)
            for index, value in annotations:
                bond = mol.GetBondWithIdx(index)
                if bond.GetBondType() != Chem.BondType.DOUBLE:
                    raise ValueError("Explicit E/Z annotation references a non-double bond")
                begin_neighbors = [a for a in bond.GetBeginAtom().GetNeighbors()
                                   if a.GetIdx() != bond.GetEndAtomIdx()]
                end_neighbors = [a for a in bond.GetEndAtom().GetNeighbors()
                                 if a.GetIdx() != bond.GetBeginAtomIdx()]
                if not begin_neighbors or not end_neighbors:
                    raise ValueError("Explicit E/Z annotation needs a substituent on each alkene atom")
                begin = max(begin_neighbors, key=lambda atom: int(atom.GetProp("_CIPRank"))
                            if atom.HasProp("_CIPRank") else atom.GetIdx())
                end = max(end_neighbors, key=lambda atom: int(atom.GetProp("_CIPRank"))
                          if atom.HasProp("_CIPRank") else atom.GetIdx())
                bond.SetStereoAtoms(begin.GetIdx(), end.GetIdx())
                bond.SetStereo(Chem.BondStereo.STEREOE if value == "E" else Chem.BondStereo.STEREOZ)
        sys.stdout.write(Chem.MolToSmiles(mol, canonical=True, isomericSmiles=True) + "\n")
    elif op == "generate-3d":
        mol = read_molblock(data)
        if mol is None:
            raise ValueError("RDKit could not parse this MOL structure")
        mol = Chem.AddHs(mol, addCoords=True)
        if AllChem.EmbedMolecule(mol, randomSeed=0xC0FFEE) < 0:
            raise ValueError("RDKit could not generate a 3D conformer for this structure")
        if AllChem.MMFFHasAllMoleculeParams(mol):
            AllChem.MMFFOptimizeMolecule(mol, maxIters=500)
            method = "MMFF94"
        elif AllChem.UFFHasAllMoleculeParams(mol):
            AllChem.UFFOptimizeMolecule(mol, maxIters=500)
            method = "UFF"
        else:
            raise ValueError("RDKit has no MMFF/UFF parameters for this structure")
        mol = Chem.RemoveHs(mol)
        mol.SetProp("_Name", "MOLECULA_3D")
        sys.stdout.write(f"ENGINE\tRDKit {rdBase.rdkitVersion}\nMETHOD\t{method}\nMOLBLOCK\n")
        sys.stdout.write(Chem.MolToMolBlock(mol, includeStereo=True))
    elif op in ("aromatize", "kekulize"):
        mol = read_molblock(data)
        if mol is None:
            raise ValueError("RDKit could not parse this MOL structure")
        if op == "aromatize":
            Chem.SetAromaticity(mol)
        else:
            Chem.Kekulize(mol, clearAromaticFlags=True)
        sys.stdout.write(f"ENGINE\tRDKit {rdBase.rdkitVersion}\nOPERATION\t{op}\nMOLBLOCK\n")
        sys.stdout.write(Chem.MolToMolBlock(mol, includeStereo=True))
    elif op in ("tautomer-report", "stereoisomer-report"):
        mol = read_molblock(data)
        if mol is None:
            raise ValueError("RDKit could not parse this MOL structure")
        if op == "tautomer-report":
            from rdkit.Chem.MolStandardize import rdMolStandardize
            enumerator = rdMolStandardize.TautomerEnumerator()
            enumerator.SetMaxTautomers(100)
            result = enumerator.Enumerate(mol)
            candidates = sorted(result.smiles)
            sys.stdout.write(f"ENGINE\tRDKit {rdBase.rdkitVersion}\nMETHOD\tTautomerEnumerator; max 100 candidates\nCOUNT\t{len(candidates)}\nSTATUS\t{result.status}\n")
        else:
            from rdkit.Chem.EnumerateStereoisomers import EnumerateStereoisomers, StereoEnumerationOptions
            options = StereoEnumerationOptions(onlyUnassigned=True, unique=True, maxIsomers=64)
            candidates = sorted(Chem.MolToSmiles(candidate, canonical=True, isomericSmiles=True)
                                for candidate in EnumerateStereoisomers(mol, options=options))
            sys.stdout.write(f"ENGINE\tRDKit {rdBase.rdkitVersion}\nMETHOD\tEnumerateStereoisomers; unspecified centers only; unique; maximum 64\nCOUNT\t{len(candidates)}\n")
            if len(candidates) == 64:
                sys.stdout.write("NOTICE\tResult may be capped at 64 candidates.\n")
        for index, smiles in enumerate(candidates, 1):
            sys.stdout.write(f"CANDIDATE\t{index}\t{smiles}\n")
    elif op == "stereo-report":
        mol = read_molblock(data)
        if mol is None:
            raise ValueError("RDKit could not parse this MOL structure")
        Chem.AssignStereochemistry(mol, cleanIt=True, force=True)
        sys.stdout.write(f"ENGINE\tRDKit {rdBase.rdkitVersion}\nMETHOD\tRDKit stereochemistry assignment\n")
        found = False
        for atom in mol.GetAtoms():
            if atom.HasProp("_CIPCode"):
                sys.stdout.write(f"ATOM\t{atom.GetIdx()+1}\t{atom.GetProp('_CIPCode')}\n")
                found = True
        for bond in mol.GetBonds():
            stereo = str(bond.GetStereo())
            if stereo in ("STEREOE", "STEREOZ", "STEREOCIS", "STEREOTRANS"):
                sys.stdout.write(f"BOND\t{bond.GetBeginAtomIdx()+1}\t{bond.GetEndAtomIdx()+1}\t{stereo}\n")
                found = True
        if not found:
            sys.stdout.write("RESULT\tNo stereogenic atom or bond was assigned from the supplied 2D stereo marks.\n")
    elif op in ("from-mol2", "from-pdb", "from-inchi"):
        if op == "from-mol2":
            mol = Chem.MolFromMol2Block(data, sanitize=True, removeHs=False, cleanupSubstructures=True)
        elif op == "from-pdb":
            mol = Chem.MolFromPDBBlock(data, sanitize=True, removeHs=False, proximityBonding=True)
        else:
            from rdkit.Chem import inchi
            mol = inchi.MolFromInchi(data.strip(), sanitize=True, removeHs=False)
        if mol is None:
            raise ValueError(f"RDKit could not parse the {op[5:].upper()} input")
        if op == "from-pdb":
            mol.SetProp("_Name", "MOLECULA_3D")
        sys.stdout.write(f"ENGINE\tRDKit {rdBase.rdkitVersion}\nMOLBLOCK\n")
        sys.stdout.write(Chem.MolToMolBlock(mol, includeStereo=True, forceV3000=(mol.GetNumAtoms()>999 or mol.GetNumBonds()>999)))
    elif op in ("to-cml", "to-pdb", "to-inchi", "to-inchikey"):
        mol = read_molblock(data)
        if mol is None:
            raise ValueError("RDKit could not parse this MOL structure")
        if op == "to-cml":
            result = Chem.MolToCMLBlock(mol)
        elif op == "to-pdb":
            if mol.GetNumConformers()==0 or not mol.GetConformer().Is3D():
                raise ValueError("PDB export requires generated or imported 3D coordinates")
            result = Chem.MolToPDBBlock(mol)
        else:
            from rdkit.Chem import inchi
            result = inchi.MolToInchi(mol) if op == "to-inchi" else inchi.MolToInchiKey(mol)
        sys.stdout.write(f"ENGINE\tRDKit {rdBase.rdkitVersion}\nRESULT\n{result}\n")
    else:
        raise ValueError("Unknown RDKit conversion operation")
except Exception as exc:
    sys.stdout.write("ERROR\t" + str(exc) + "\n")
    sys.exit(1)
