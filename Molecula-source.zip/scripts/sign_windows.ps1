$ErrorActionPreference = "Stop"

$installer = Join-Path $PSScriptRoot "..\dist\windows\Molecula-Windows-Setup.exe"
$installer = (Resolve-Path $installer).Path

if (-not $env:WINDOWS_SIGNING_CERTIFICATE_BASE64 -or -not $env:WINDOWS_SIGNING_CERTIFICATE_PASSWORD) {
    throw "Authenticode signing requires WINDOWS_SIGNING_CERTIFICATE_BASE64 and WINDOWS_SIGNING_CERTIFICATE_PASSWORD."
}

$certificatePath = Join-Path $env:RUNNER_TEMP "molecula-code-signing.pfx"
try {
    [IO.File]::WriteAllBytes($certificatePath, [Convert]::FromBase64String($env:WINDOWS_SIGNING_CERTIFICATE_BASE64))

    $sdkRoot = Join-Path ${env:ProgramFiles(x86)} "Windows Kits\10\bin"
    $signTool = Get-ChildItem -Path $sdkRoot -Filter signtool.exe -Recurse -ErrorAction Stop |
        Where-Object { $_.Directory.Name -eq "x64" } |
        Sort-Object FullName -Descending |
        Select-Object -First 1 -ExpandProperty FullName
    if (-not $signTool) { throw "Windows SDK signtool.exe was not found." }

    & $signTool sign /fd SHA256 /tr "http://timestamp.digicert.com" /td SHA256 `
        /f $certificatePath /p $env:WINDOWS_SIGNING_CERTIFICATE_PASSWORD $installer
    if ($LASTEXITCODE -ne 0) { throw "Authenticode signing failed: $LASTEXITCODE" }

    & $signTool verify /pa /v $installer
    if ($LASTEXITCODE -ne 0) { throw "Authenticode signature verification failed: $LASTEXITCODE" }
} finally {
    Remove-Item $certificatePath -Force -ErrorAction SilentlyContinue
}
