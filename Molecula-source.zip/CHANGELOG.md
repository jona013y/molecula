# Changelog

## v1.0.6

- Include per-step reaction conditions in the calculation report, showing the text above and below each arrow.
- Keep conditions isolated to their own step and omit the conditions section when both arrow labels are blank.

## v1.0.5

- Add atomic automatic balancing for every reaction step. The editor solves each step before applying any coefficient changes, reports the result by step, and records the complete operation as one undoable edit.
- Add regression coverage for multi-step balancing, undo, and failure without partial edits.

## v1.0.4

- Add searchable, graph-backed templates for naphthalene, indole, quinoline, anthracene, phenanthrene, decalin and norbornane.
- Confirm detected data loss before writing SMILES, SMARTS, image and exchange-format exports.
- Add a bounded local SMILES import/export path for supported structures without requiring RDKit.
- Refresh the Mac application package and improve source-based Mac/Windows CI packaging.

Molecula remains an independent editor with a limited, documented chemistry scope; this release does not claim feature parity with MarvinSketch or completeness for research-grade cheminformatics.
