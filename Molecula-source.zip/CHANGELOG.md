# Changelog

## v1.0.10

- Let the selected single, double, triple or styled-bond tool edit an existing bond with one click on its midpoint; atom clicks still start the usual bond drawing gesture.
- Keep the in-place edit undoable and select the changed bond for immediate inspection.

## v1.0.9

- Prevent stale E/Z annotations when a double bond is changed to an aromatic or single bond.
- Keep wedge, hash and wavy stereobond display marks on single bonds; converting a double bond to that style is undoable.
- Report imported bond stereochemistry/display-style combinations that conflict with their bond order.

## v1.0.8

- Make reaction analysis check isotope counts separately from element totals and formal charge.
- Require isotope-labelled atoms to be conserved by automatic stoichiometric balancing; report isotope differences explicitly.
- Add regression coverage for isotope loss and isotope-preserving reactions.

## v1.0.7

- Add a per-component reaction table to the analysis report, listing role, coefficient, formula, formal charge and whether the role was explicitly assigned or inferred from geometry.
- Cover explicit/inferred role labels and coefficient/formula reporting with regression tests.

## v1.0.6

- Include per-step reaction conditions in the calculation report, showing the text above and below each arrow.
- Keep conditions isolated to their own step and omit the conditions section when both arrow labels are blank.

## v1.0.5

- Add atomic automatic balancing for every reaction step. The editor solves each step before applying any coefficient changes, reports the result by step, and records the complete operation as one undoable edit.
- Add regression coverage for multi-step balancing, undo, and failure without partial edits.

## v1.0.4

- Add searchable, graph-backed templates for naphthalene, indole, quinoline, anthracene, phenanthrene, decalin and norbornane.
- Confirm detected data loss before writing SMILES, SMARTS, image and exchange-format exports.
- Add a bounded local SMILES import/export path for supported structures without requiring RDKit.
- Refresh the Mac application package and improve source-based Mac/Windows CI packaging.

Molecula remains an independent editor with a limited, documented chemistry scope; this release does not claim feature parity with MarvinSketch or completeness for research-grade cheminformatics.
