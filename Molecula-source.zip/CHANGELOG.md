# Changelog

## v1.0.4

- Add searchable, graph-backed templates for naphthalene, indole, quinoline, anthracene, phenanthrene, decalin and norbornane.
- Confirm detected data loss before writing SMILES, SMARTS, image and exchange-format exports.
- Add a bounded local SMILES import/export path for supported structures without requiring RDKit.
- Refresh the Mac application package and improve source-based Mac/Windows CI packaging.

Molecula remains an independent editor with a limited, documented chemistry scope; this release does not claim feature parity with MarvinSketch or completeness for research-grade cheminformatics.
