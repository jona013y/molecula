# molecula

Molecula is an independent Rust desktop editor for drawing chemical structures and reaction diagrams. Version 0.5 adds reaction analysis and an optional RDKit descriptor bridge. It remains an incomplete implementation of the larger specification; see [STATUS.md](STATUS.md) before relying on advanced chemistry.

## Start on macOS

Open `molecula.app` in this folder. For development, install Rust and run:

```sh
cargo run --release --offline
```

The packaged app uses an embedded DejaVu Sans font, whose license is included in `assets/DEJAVU_LICENSE.txt`. The only Rust dependency is Macroquad 0.4.16.
The macOS icon is built from original vector shapes by `scripts/build_icon.py` (requires Pillow).

## Install packages

- **Mac (Apple Silicon):** [Molecula-macOS-arm64.zip](dist/Molecula-macOS-arm64.zip). Open the ZIP, then drag `Molecula.app` to Applications. This local archive is ad-hoc signed, not notarized; if Gatekeeper blocks it, Control-click the app and choose **Open** once.
- **Windows (64-bit):** download `Molecula-Windows-Setup.exe` from the latest GitHub release and run it to install per-user. If startup fails, open **Molecula → Open startup log** from the Start menu, or paste `%LOCALAPPDATA%\Molecula\startup.log` into File Explorer's address bar.

The local Mac archive checksum is in [SHA256SUMS.txt](dist/SHA256SUMS.txt).

The macOS packaging script uses a DMG when the host permits disk-image creation and falls back to a ZIP otherwise. Run `scripts/package_macos.sh arm64` on this Mac, or `scripts/package_macos.sh universal` after building both Apple and Intel targets.

## Basic workflow

1. Use the left toolbar to choose a bond, atom, ring, chain, arrow, plus sign, text, select, or erase tool.
   Choose **Sel**, then hold and drag across the canvas to box-select atoms. The inspector shows selected atom details or a summary for multiple atoms; click a bond or graphic to inspect it. Selection details stay in the right panel.
2. Drag to draw a bond or arrow. Choose **Chain** and drag to place a zigzag carbon chain; the start or end can snap onto an existing atom. A short click on an existing atom with a bond tool extends one bond at the standard length in a free direction.
3. Select an atom to edit charge or set a carbon-13 isotope in the right panel. Choose any of the 118 elements from **Elements**.
4. Use **Templates** to place benzene, aliphatic rings from 3 to 8 members, pyridine, pyrimidine, imidazole, ethanol, or a carboxyl group. **Structure** includes Clean 2D, explicit hydrogen conversion, rotate and mirror actions.
5. Choose **Structure → Name structure** to name a supported acyclic organic molecule. The built-in teaching subset handles common aldehyde, ketone, and alcohol priority; alkene/alkyne locants; and simple alphabetized prefixes such as ethyl, hydroxy, and oxo. It explains its steps and reports unsupported structures instead of guessing.
6. Save to `.mols` to preserve the full editable document. Open or export `.mol` for MOL V2000 interoperability; export `.svg` for a vector image. The editor warns before an export that loses editable data.

The **Insert** menu also provides line, rectangle, and ellipse tools. Drag on the canvas to draw one; they can be selected, deleted, and retained in `.mols` or SVG export.

Choose **Edit → Settings** to switch the interface between English and Danish. The language preference is saved automatically in the user's application support folder.

## Reactions and calculations

- Draw disconnected structures on each side of an arrow. The **Insert** menu offers reaction, equilibrium, resonance, and retrosynthesis arrows. Drag the curved-arrow tools in the left bar for one- or two-electron arrows. Select a reaction arrow to edit its conditions above/below or cycle its type.
- Choose **Calculations → Reaction analysis** to see each side's component formula and molar mass, charge, element/charge balance, and changes in bonds whose atoms have map numbers. Roles are inferred from position relative to the first reaction arrow. Every disconnected component has coefficient 1; agents are identified in the middle region. This is not a complete reaction engine.
- **Molecular properties** reports local formula, mass, element counts, atoms, bonds, and formal charge. The mass table and valence rules cover a limited subset of chemistry.
- **RDKit descriptors** runs an optional Python RDKit worker in the background for logP, TPSA, H-bond counts, ring and rotatable-bond counts, mass, and molar refractivity. It rejects query/R-group/alias/special-bond structures that the MOL bridge could change. Install RDKit into a compatible Python environment and set `MOLECULA_PYTHON=/path/to/python` before launching. The app works without RDKit and reports why a calculation is unavailable.

The file dialog takes a path relative to the process working directory or an absolute path. `Cmd/Ctrl+N`, `O`, `S`, `Z`, and `Y` cover new, open, save, undo, and redo. Delete removes the selected object. Drawing sequences are buffered for 0.65 seconds, so `1` and `12`, or `C` and `Cl`, can be distinguished. Use the **Help → Shortcuts** menu for the active keys.

## Project layout

- `src/main.rs`: editor UI, document actions, MOL V2000 and SVG rendering.
- `src/native.rs`: versioned, lossless `.mols` document format.
- `src/chemistry.rs`: element symbols, limited mass data, implicit hydrogen and basic valence checks.
- `src/reaction.rs`: disconnected-component reaction roles, balance, and mapped bond changes.
- `src/rdkit.rs` and `scripts/rdkit_descriptors.py`: optional background descriptor worker.
- `src/shortcuts.rs`: buffered quick chemistry input.
- `STATUS.md`: feature status and known limits.
- `REA_NOTES.md`: static observations of the installed MarvinSketch reference.

## Build and verify

```sh
cargo test --offline
cargo build --release --offline
```

The local mass calculation uses explicit, limited element and isotope tables. It does not replace RDKit or another full chemistry engine. Advanced calculations are unavailable when no suitable engine is installed. No results are fabricated.
