use std::io::Write;
use std::process::{Command, Stdio};

const SCRIPT: &str = include_str!("../scripts/rdkit_descriptors.py");
const CONVERT_SCRIPT: &str = include_str!("../scripts/rdkit_convert.py");

fn execute(script: &str, operation: &str, input_text: &str) -> Result<String, String> {
    let candidates = if let Ok(path) = std::env::var("MOLECULA_PYTHON") {
        vec![path]
    } else {
        vec!["python3.12".into(), "python3".into()]
    };
    let mut failure =
        "No Python interpreter found. Set MOLECULA_PYTHON to a Python with RDKit installed."
            .to_string();
    for python in candidates {
        let child = Command::new(&python)
            .arg("-c")
            .arg(script)
            .arg(operation)
            .stdin(Stdio::piped())
            .stdout(Stdio::piped())
            .stderr(Stdio::null())
            .spawn();
        let Ok(mut child) = child else { continue };
        if let Some(mut input) = child.stdin.take() {
            input
                .write_all(input_text.as_bytes())
                .map_err(|e| e.to_string())?;
        }
        let output = child.wait_with_output().map_err(|e| e.to_string())?;
        let body = String::from_utf8(output.stdout).map_err(|_| "RDKit returned invalid UTF-8")?;
        if output.status.success() {
            return Ok(body);
        }
        failure = body
            .strip_prefix("ERROR\t")
            .unwrap_or("RDKit conversion failed")
            .trim()
            .to_string();
    }
    Err(failure)
}

pub fn from_smiles(smiles: &str) -> Result<String, String> {
    execute(CONVERT_SCRIPT, "from-smiles", smiles)
}

pub fn to_smiles(molblock: &str) -> Result<String, String> {
    execute(CONVERT_SCRIPT, "to-smiles", molblock).map(|s| s.trim().to_string())
}

pub fn generate_3d(molblock: &str) -> Result<String, String> {
    execute(CONVERT_SCRIPT, "generate-3d", molblock)
}
pub fn aromatize(molblock: &str) -> Result<String, String> {
    execute(CONVERT_SCRIPT, "aromatize", molblock)
}
pub fn kekulize(molblock: &str) -> Result<String, String> {
    execute(CONVERT_SCRIPT, "kekulize", molblock)
}
pub fn stereo_report(molblock: &str) -> Result<String, String> {
    execute(CONVERT_SCRIPT, "stereo-report", molblock)
}

pub fn import_external(operation: &str, input: &str) -> Result<String, String> {
    execute(CONVERT_SCRIPT, operation, input)
}

pub fn export_external(operation: &str, molblock: &str) -> Result<String, String> {
    let output = execute(CONVERT_SCRIPT, operation, molblock)?;
    let (_, body) = output
        .split_once("RESULT\n")
        .ok_or("RDKit returned no export result")?;
    Ok(body.to_string())
}

pub fn descriptors(molblock: &str) -> Result<String, String> {
    let candidates = if let Ok(path) = std::env::var("MOLECULA_PYTHON") {
        vec![path]
    } else {
        vec!["python3.12".into(), "python3".into()]
    };
    let mut failure =
        "No Python interpreter found. Set MOLECULA_PYTHON to a Python with RDKit installed."
            .to_string();
    for python in candidates {
        let child = Command::new(&python)
            .arg("-c")
            .arg(SCRIPT)
            .stdin(Stdio::piped())
            .stdout(Stdio::piped())
            .stderr(Stdio::null())
            .spawn();
        let Ok(mut child) = child else { continue };
        if let Some(mut input) = child.stdin.take() {
            input
                .write_all(molblock.as_bytes())
                .map_err(|e| e.to_string())?;
        }
        let output = child.wait_with_output().map_err(|e| e.to_string())?;
        let body = String::from_utf8(output.stdout).map_err(|_| "RDKit returned invalid UTF-8")?;
        if output.status.success() {
            let mut lines = Vec::new();
            for line in body.lines() {
                let fields: Vec<&str> = line.split('\t').collect();
                if fields.len() == 2 && fields[0] == "ENGINE" {
                    lines.push(fields[1].to_string());
                } else if fields.len() == 5 && fields[0] == "VALUE" {
                    lines.push(format!(
                        "{}: {} {} ({})",
                        fields[1], fields[2], fields[3], fields[4]
                    ));
                }
            }
            if lines.len() < 2 {
                return Err("RDKit returned an incomplete descriptor report".into());
            }
            return Ok(lines.join("\n"));
        }
        failure = body
            .strip_prefix("ERROR\t")
            .unwrap_or("RDKit descriptor worker failed")
            .trim()
            .to_string();
    }
    Err(failure)
}

#[cfg(test)]
mod tests {
    use super::*;
    #[test]
    fn unavailable_engine_is_reported() {
        if std::env::var("MOLECULA_PYTHON").is_ok() {
            return;
        }
        let result = descriptors("invalid");
        assert!(result.is_err());
    }

    #[test]
    fn malformed_optional_format_conversions_never_succeed_silently() {
        assert!(import_external("from-inchi", "not an InChI").is_err());
        assert!(export_external("to-pdb", "not a MOL structure").is_err());
    }
}
