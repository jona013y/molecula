use std::io::Write;
use std::process::{Command, Stdio};

const SCRIPT: &str = include_str!("../scripts/rdkit_descriptors.py");

pub fn descriptors(molblock: &str) -> Result<String, String> {
    let candidates = if let Ok(path) = std::env::var("MOLECULA_PYTHON") {
        vec![path]
    } else {
        vec!["python3.12".into(), "python3".into()]
    };
    let mut failure =
        "No Python interpreter found. Set MOLECULA_PYTHON to a Python with RDKit installed."
            .to_string();
    for python in candidates {
        let child = Command::new(&python)
            .arg("-c")
            .arg(SCRIPT)
            .stdin(Stdio::piped())
            .stdout(Stdio::piped())
            .stderr(Stdio::null())
            .spawn();
        let Ok(mut child) = child else { continue };
        if let Some(mut input) = child.stdin.take() {
            input
                .write_all(molblock.as_bytes())
                .map_err(|e| e.to_string())?;
        }
        let output = child.wait_with_output().map_err(|e| e.to_string())?;
        let body = String::from_utf8(output.stdout).map_err(|_| "RDKit returned invalid UTF-8")?;
        if output.status.success() {
            let mut lines = Vec::new();
            for line in body.lines() {
                let fields: Vec<&str> = line.split('\t').collect();
                if fields.len() == 2 && fields[0] == "ENGINE" {
                    lines.push(fields[1].to_string());
                } else if fields.len() == 5 && fields[0] == "VALUE" {
                    lines.push(format!(
                        "{}: {} {} ({})",
                        fields[1], fields[2], fields[3], fields[4]
                    ));
                }
            }
            if lines.len() < 2 {
                return Err("RDKit returned an incomplete descriptor report".into());
            }
            return Ok(lines.join("\n"));
        }
        failure = body
            .strip_prefix("ERROR\t")
            .unwrap_or("RDKit descriptor worker failed")
            .trim()
            .to_string();
    }
    Err(failure)
}

#[cfg(test)]
mod tests {
    use super::*;
    #[test]
    fn unavailable_engine_is_reported() {
        if std::env::var("MOLECULA_PYTHON").is_ok() {
            return;
        }
        let result = descriptors("invalid");
        assert!(result.is_err());
    }
}
