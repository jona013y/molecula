//! Deliberately bounded systematic naming for simple, acyclic C/H/O/N/halogen graphs.
//! This is not a general IUPAC or preferred-name engine.
use crate::{BondStyle, Molecule};
use std::collections::{BTreeMap, BTreeSet};

#[derive(Debug, Clone, PartialEq, Eq)]
pub struct NameResult {
    pub name: String,
    pub explanation: String,
    pub steps: Vec<String>,
    pub highlighted_atoms: Vec<usize>,
}

#[derive(Clone, Copy, Debug, PartialEq, Eq)]
enum Principal {
    CarboxylicAcid(usize),
    Aldehyde(usize),
    Ketone(usize),
    Alcohol(usize),
}

fn root(n: usize) -> Option<&'static str> {
    Some(match n {
        1 => "meth",
        2 => "eth",
        3 => "prop",
        4 => "but",
        5 => "pent",
        6 => "hex",
        7 => "hept",
        8 => "oct",
        9 => "non",
        10 => "dec",
        11 => "undec",
        12 => "dodec",
        _ => return None,
    })
}

fn carbon_neighbors(m: &Molecule) -> Vec<Vec<usize>> {
    let mut out = vec![Vec::new(); m.atoms.len()];
    for b in &m.bonds {
        if m.atoms[b.a].element == "C" && m.atoms[b.b].element == "C" {
            out[b.a].push(b.b);
            out[b.b].push(b.a);
        }
    }
    out
}

fn has_cycle(neighbors: &[Vec<usize>], i: usize, parent: Option<usize>, seen: &mut [bool]) -> bool {
    seen[i] = true;
    for &j in &neighbors[i] {
        if !seen[j] {
            if has_cycle(neighbors, j, Some(i), seen) {
                return true;
            }
        } else if Some(j) != parent {
            return true;
        }
    }
    false
}

fn enumerate_paths(
    neighbors: &[Vec<usize>],
    current: usize,
    previous: Option<usize>,
    path: &mut Vec<usize>,
    all: &mut Vec<Vec<usize>>,
) {
    path.push(current);
    let mut extended = false;
    for &next in &neighbors[current] {
        if Some(next) != previous {
            extended = true;
            enumerate_paths(neighbors, next, Some(current), path, all);
        }
    }
    if !extended {
        all.push(path.clone());
    }
    path.pop();
}

fn bond_order(m: &Molecule, a: usize, b: usize) -> Option<u8> {
    m.bonds
        .iter()
        .find(|x| (x.a == a && x.b == b) || (x.a == b && x.b == a))
        .map(|x| x.order)
}

fn prefix_group(groups: &mut BTreeMap<String, Vec<usize>>, prefix: &str, locant: usize) {
    groups.entry(prefix.to_owned()).or_default().push(locant);
}

fn format_prefixes(groups: &mut BTreeMap<String, Vec<usize>>) -> String {
    let mut entries: Vec<(String, String)> = groups
        .iter_mut()
        .map(|(base, locants)| {
            locants.sort_unstable();
            let mult = match locants.len() {
                2 => "di",
                3 => "tri",
                4 => "tetra",
                _ => "",
            };
            let loc = locants
                .iter()
                .map(usize::to_string)
                .collect::<Vec<_>>()
                .join(",");
            let pref = format!("{loc}-{mult}{base}");
            (base.clone(), pref)
        })
        .collect();
    entries.sort_by(|a, b| a.0.cmp(&b.0));
    entries
        .into_iter()
        .map(|x| x.1)
        .collect::<Vec<_>>()
        .join("-")
}

/// Generate a teachable name for an acyclic carbon parent with common carbonyl/alcohol groups.
pub fn name(m: &Molecule) -> Result<NameResult, String> {
    if m.atoms.is_empty() {
        return Err("Draw one molecule before naming it.".into());
    }
    if m.atoms.len() > 64 {
        return Err("The built-in naming subset is limited to 64 atoms.".into());
    }
    if m.atoms.iter().any(|a| {
        a.aromatic
            || a.r_group.is_some()
            || a.query.is_some()
            || a.radical > 0
            || a.isotope.is_some()
    }) {
        return Err("This structure uses aromatic, query, R-group, radical, or isotope features outside the built-in naming subset.".into());
    }
    // Name exactly one connected component; a reaction canvas must be split into separate structures.
    let mut visited = vec![false; m.atoms.len()];
    let mut stack = vec![0usize];
    visited[0] = true;
    while let Some(i) = stack.pop() {
        for b in &m.bonds {
            let j = if b.a == i {
                Some(b.b)
            } else if b.b == i {
                Some(b.a)
            } else {
                None
            };
            if let Some(j) = j {
                if !visited[j] {
                    visited[j] = true;
                    stack.push(j);
                }
            }
        }
    }
    if visited.iter().any(|x| !*x) {
        return Err(
            "Name one connected molecule at a time; this canvas has multiple fragments.".into(),
        );
    }
    if m.atoms.iter().any(|a| {
        !matches!(
            a.element.as_str(),
            "C" | "H" | "O" | "N" | "F" | "Cl" | "Br" | "I"
        )
    }) {
        return Err(
            "The built-in naming subset supports C, H, O, N, F, Cl, Br, and I only.".into(),
        );
    }
    if m.bonds
        .iter()
        .any(|b| b.style != BondStyle::Normal || b.order == 4 || b.order > 3)
    {
        return Err("Special or aromatic bonds are outside the built-in naming subset.".into());
    }
    let cn = carbon_neighbors(m);
    let carbons: Vec<usize> = m
        .atoms
        .iter()
        .enumerate()
        .filter_map(|(i, a)| (a.element == "C").then_some(i))
        .collect();
    if carbons.is_empty() {
        return Err("No carbon parent chain was found.".into());
    }
    let mut seen = vec![false; m.atoms.len()];
    for &i in &carbons {
        if !seen[i] && has_cycle(&cn, i, None, &mut seen) {
            return Err("Ring systems are not supported by this naming subset.".into());
        }
    }
    let mut carbonyls = Vec::<(usize, usize, usize)>::new();
    let mut hydroxyls = Vec::new();
    let mut carboxylic_acids = Vec::new();
    for b in &m.bonds {
        if b.order == 2 {
            let (c, o) = if m.atoms[b.a].element == "C" && m.atoms[b.b].element == "O" {
                (b.a, b.b)
            } else if m.atoms[b.b].element == "C" && m.atoms[b.a].element == "O" {
                (b.b, b.a)
            } else {
                continue;
            };
            let c_neighbors: Vec<usize> = cn[c].clone();
            carbonyls.push((c, o, c_neighbors.len()));
        }
        if b.order == 1 {
            let (c, o) = if m.atoms[b.a].element == "C" && m.atoms[b.b].element == "O" {
                (b.a, b.b)
            } else if m.atoms[b.b].element == "C" && m.atoms[b.a].element == "O" {
                (b.b, b.a)
            } else {
                continue;
            };
            let oxygen_degree = m.bonds.iter().filter(|x| x.a == o || x.b == o).count();
            if oxygen_degree == 1 && m.atoms[o].charge == 0 {
                hydroxyls.push((c, o));
            }
        }
    }
    for &(c, _, _) in &carbonyls {
        let acid_oh = hydroxyls.iter().any(|(carbon, _)| *carbon == c);
        if acid_oh {
            carboxylic_acids.push(c);
        }
    }
    let aldehydes: Vec<usize> = carbonyls
        .iter()
        .filter_map(|(c, _, n)| (*n <= 1 && !carboxylic_acids.contains(c)).then_some(*c))
        .collect();
    if carboxylic_acids.len() > 1 {
        return Err("Multiple carboxylic acid groups are not yet supported.".into());
    }
    let ketones: Vec<usize> = carbonyls
        .iter()
        .filter_map(|(c, _, n)| (*n == 2).then_some(*c))
        .collect();
    if aldehydes.len() > 1 {
        return Err("Multiple aldehyde groups are not yet supported.".into());
    }
    let principal = if let Some(&c) = carboxylic_acids.first() {
        Principal::CarboxylicAcid(c)
    } else if let Some(&c) = aldehydes.first() {
        Principal::Aldehyde(c)
    } else if let Some(&(c, _, _)) = carbonyls.iter().find(|(_, _, n)| *n == 2) {
        Principal::Ketone(c)
    } else if !hydroxyls.is_empty() {
        if hydroxyls.len() > 1 {
            return Err("Multiple principal alcohol groups are not yet supported.".into());
        }
        Principal::Alcohol(hydroxyls[0].0)
    } else {
        return Err("No supported aldehyde, ketone, or alcohol group was found.".into());
    };
    if matches!(principal, Principal::Ketone(_)) && ketones.len() > 1 {
        return Err("Multiple ketone suffixes are not yet supported.".into());
    }
    let mut paths = Vec::new();
    for &i in &carbons {
        enumerate_paths(&cn, i, None, &mut Vec::new(), &mut paths);
    }
    let mut candidates: Vec<Vec<usize>> = paths
        .into_iter()
        .filter(|p| match principal {
            Principal::CarboxylicAcid(c)
            | Principal::Aldehyde(c)
            | Principal::Ketone(c)
            | Principal::Alcohol(c) => p.contains(&c),
        })
        .collect();
    let max_len = candidates.iter().map(Vec::len).max().unwrap_or(0);
    candidates.retain(|p| p.len() == max_len);
    let mut oriented = Vec::new();
    for mut p in candidates {
        let orient = |p: &[usize]| -> (usize, Vec<usize>) {
            let group_locs = match principal {
                Principal::CarboxylicAcid(c)
                | Principal::Aldehyde(c)
                | Principal::Ketone(c)
                | Principal::Alcohol(c) => {
                    vec![p.iter().position(|x| *x == c).unwrap() + 1]
                }
            };
            let unsats: Vec<usize> = (0..p.len().saturating_sub(1))
                .filter_map(|i| {
                    bond_order(m, p[i], p[i + 1])
                        .filter(|o| *o > 1)
                        .map(|_| i + 1)
                })
                .collect();
            (*group_locs.iter().min().unwrap_or(&99), unsats)
        };
        if matches!(principal,Principal::CarboxylicAcid(c) | Principal::Aldehyde(c) if p.last()==Some(&c))
        {
            p.reverse();
        } else if !matches!(
            principal,
            Principal::CarboxylicAcid(_) | Principal::Aldehyde(_)
        ) {
            let rev: Vec<usize> = p.iter().rev().copied().collect();
            if orient(&rev) < orient(&p) {
                p = rev;
            }
        }
        let (loc, unsat) = orient(&p);
        oriented.push((loc, unsat, p));
    }
    oriented.sort_by(|a, b| a.0.cmp(&b.0).then_with(|| a.1.cmp(&b.1)));
    let chain = oriented
        .into_iter()
        .next()
        .ok_or("No parent chain includes the principal group")?
        .2;
    let n = chain.len();
    let stem = root(n).ok_or("Parent chains longer than 12 carbons are not yet supported.")?;
    let locants: BTreeMap<usize, usize> =
        chain.iter().enumerate().map(|(i, &a)| (a, i + 1)).collect();
    let mut groups = BTreeMap::<String, Vec<usize>>::new();
    for &(c, _, neighbors) in &carbonyls {
        if neighbors == 2 {
            if let Some(&l) = locants.get(&c) {
                if !matches!(principal,Principal::Ketone(x) if x==c) {
                    prefix_group(&mut groups, "oxo", l);
                }
            }
        }
    }
    for &(c, _) in &hydroxyls {
        if matches!(principal, Principal::CarboxylicAcid(acid) if acid == c) {
            continue;
        }
        if let Some(&l) = locants.get(&c) {
            if !matches!(principal, Principal::Alcohol(_)) {
                prefix_group(&mut groups, "hydroxy", l);
            }
        }
    }
    let parent_set: BTreeSet<usize> = chain.iter().copied().collect();
    let mut covered = BTreeSet::new();
    for (i, &c) in chain.iter().enumerate() {
        for &neighbor in &cn[c] {
            if parent_set.contains(&neighbor) || covered.contains(&neighbor) {
                continue;
            }
            let mut branch = Vec::new();
            let mut todo = vec![(neighbor, c)];
            while let Some((x, prev)) = todo.pop() {
                if parent_set.contains(&x) || covered.contains(&x) {
                    continue;
                }
                covered.insert(x);
                branch.push(x);
                if cn[x].iter().any(|j| {
                    !parent_set.contains(j) && *j != prev && bond_order(m, x, *j) != Some(1)
                }) {
                    return Err("Unsaturated or branched side chains are not yet supported.".into());
                }
                for &j in &cn[x] {
                    if j != prev && !parent_set.contains(&j) {
                        todo.push((j, x));
                    }
                }
            }
            let alkyl = match branch.len() {
                1 => "methyl",
                2 => "ethyl",
                3 => "propyl",
                4 => "butyl",
                5 => "pentyl",
                6 => "hexyl",
                _ => {
                    return Err(
                        "Alkyl side chains longer than six carbons are not supported.".into(),
                    )
                }
            };
            prefix_group(&mut groups, alkyl, i + 1);
        }
    }
    for (i, &c) in chain.iter().enumerate() {
        for b in &m.bonds {
            let x = if b.a == c {
                b.b
            } else if b.b == c {
                b.a
            } else {
                continue;
            };
            if m.atoms[x].element == "N" && b.order == 1 {
                prefix_group(&mut groups, "amino", i + 1);
            } else if matches!(m.atoms[x].element.as_str(), "F" | "Cl" | "Br" | "I") {
                let p = match m.atoms[x].element.as_str() {
                    "F" => "fluoro",
                    "Cl" => "chloro",
                    "Br" => "bromo",
                    _ => "iodo",
                };
                prefix_group(&mut groups, p, i + 1);
            }
        }
    }
    let mut doubles = Vec::new();
    let mut triples = Vec::new();
    for i in 0..n - 1 {
        match bond_order(m, chain[i], chain[i + 1]) {
            Some(2) => doubles.push(i + 1),
            Some(3) => triples.push(i + 1),
            _ => {}
        }
    }
    let unsaturated = !doubles.is_empty() || !triples.is_empty();
    let unsat = if !unsaturated {
        format!("{stem}an")
    } else {
        let mut s = stem.to_owned();
        if !doubles.is_empty() {
            s += &format!(
                "-{}-{}",
                doubles
                    .iter()
                    .map(usize::to_string)
                    .collect::<Vec<_>>()
                    .join(","),
                if doubles.len() > 1 { "dien" } else { "en" }
            );
        }
        if !triples.is_empty() {
            s += &format!(
                "-{}-{}",
                triples
                    .iter()
                    .map(usize::to_string)
                    .collect::<Vec<_>>()
                    .join(","),
                if triples.len() > 1 { "diyn" } else { "yn" }
            );
        }
        s
    };
    let base = match principal {
        Principal::CarboxylicAcid(_) => format!("{unsat}oic acid"),
        Principal::Aldehyde(_) => {
            if unsaturated {
                format!("{unsat}al")
            } else {
                format!("{stem}al")
            }
        }
        Principal::Ketone(c) => format!("{unsat}-{}-one", locants[&c]),
        Principal::Alcohol(c) => format!("{unsat}-{}-ol", locants[&c]),
    };
    let prefix = format_prefixes(&mut groups);
    let name = if prefix.is_empty() {
        base
    } else {
        format!("{prefix}{base}")
    };
    let (group_text, principal_atom) = match principal {
        Principal::CarboxylicAcid(c) => ("carboxylic acid (-oic acid)", c),
        Principal::Aldehyde(c) => ("aldehyde (-al)", c),
        Principal::Ketone(c) => ("ketone (-one)", c),
        Principal::Alcohol(c) => ("alcohol (-ol)", c),
    };
    let unsat_text = if doubles.is_empty() && triples.is_empty() {
        "no multiple bonds".into()
    } else {
        format!(
            "multiple-bond locants: {}",
            doubles
                .iter()
                .map(|x| format!("{x}= "))
                .chain(triples.iter().map(|x| format!("{x}≡ ")))
                .collect::<String>()
        )
    };
    let parent = format!(
        "{} carbons: {}",
        n,
        if unsaturated {
            "alkene/alkyne"
        } else {
            "alkane"
        }
    );
    let prefix_text = if prefix.is_empty() {
        "none".to_string()
    } else {
        prefix.clone()
    };
    let steps=vec![
        format!("1. Principal group priority: {group_text} is the highest supported group found."),
        format!("2. Parent chain: choose the longest supported carbon chain containing the principal atom ({parent})."),
        format!("3. Numbering: begin at the principal group; the principal atom is locant {}.",locants[&principal_atom]),
        format!("4. Multiple bonds: {unsat_text}."),
        format!("5. Other groups: {prefix_text}; prefixes are alphabetized."),
        format!("6. Assemble the supported name: {name}."),
    ];
    let explanation = steps.join("\n")
        + "\n\nGenerated by Molecula's limited teaching rules; not a complete IUPAC/PIN name.";
    let mut highlighted_atoms = chain;
    highlighted_atoms.push(principal_atom);
    highlighted_atoms.sort_unstable();
    highlighted_atoms.dedup();
    Ok(NameResult {
        name,
        explanation,
        steps,
        highlighted_atoms,
    })
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::{Atom, Bond};
    use macroquad::prelude::vec2;
    fn bond(m: &mut Molecule, a: usize, b: usize, order: u8) {
        m.bonds.push(Bond {
            a,
            b,
            order,
            style: BondStyle::Normal,
            stereo: None,
            query: None,
        });
    }
    #[test]
    fn names_alkane_aldehyde_and_alkene_aldehyde_substituents() {
        let mut m = Molecule::default();
        for _ in 0..7 {
            m.atoms.push(Atom::new(vec2(0., 0.), "C"));
        }
        for i in 0..6 {
            bond(&mut m, i, i + 1, 1);
        }
        let o = m.atoms.len();
        m.atoms.push(Atom::new(vec2(0., 0.), "O"));
        bond(&mut m, 0, o, 2);
        m.bonds
            .iter_mut()
            .find(|b| (b.a == 3 && b.b == 4) || (b.a == 4 && b.b == 3))
            .unwrap()
            .order = 2;
        let ethyl = m.atoms.len();
        m.atoms.push(Atom::new(vec2(0., 0.), "C"));
        let ethyl2 = m.atoms.len();
        m.atoms.push(Atom::new(vec2(0., 0.), "C"));
        bond(&mut m, 3, ethyl, 1);
        bond(&mut m, ethyl, ethyl2, 1);
        let oh = m.atoms.len();
        m.atoms.push(Atom::new(vec2(0., 0.), "O"));
        bond(&mut m, 4, oh, 1);
        let oxo = m.atoms.len();
        m.atoms.push(Atom::new(vec2(0., 0.), "O"));
        bond(&mut m, 2, oxo, 2);
        let result = name(&m).unwrap();
        assert_eq!(result.name, "4-ethyl-5-hydroxy-3-oxohept-4-enal");
        assert!(result.steps.iter().any(|s| s.contains("aldehyde")));
        assert!(result.steps.iter().any(|s| s.contains("4-ethyl")));
        assert_eq!(result.highlighted_atoms.len(), 7);
    }

    #[test]
    fn names_carboxylic_acid_and_alkene_acid_with_substituents() {
        let mut m = Molecule::default();
        for _ in 0..5 {
            m.atoms.push(Atom::new(vec2(0., 0.), "C"));
        }
        for i in 0..4 {
            bond(&mut m, i, i + 1, 1);
        }
        // Put the carboxyl carbon at the chain end; the chain must number from this end.
        let carbonyl_o = m.atoms.len();
        m.atoms.push(Atom::new(vec2(0., 0.), "O"));
        bond(&mut m, 0, carbonyl_o, 2);
        let hydroxyl_o = m.atoms.len();
        m.atoms.push(Atom::new(vec2(0., 0.), "O"));
        bond(&mut m, 0, hydroxyl_o, 1);
        m.bonds
            .iter_mut()
            .find(|b| (b.a == 2 && b.b == 3) || (b.a == 3 && b.b == 2))
            .unwrap()
            .order = 2;
        let branch = m.atoms.len();
        m.atoms.push(Atom::new(vec2(0., 0.), "C"));
        bond(&mut m, 3, branch, 1);

        let result = name(&m).unwrap();
        assert_eq!(result.name, "4-methylpent-3-enoic acid");
        assert!(result.steps[0].contains("carboxylic acid"));
        assert_eq!(result.highlighted_atoms.len(), 5);
    }

    #[test]
    fn names_saturated_carboxylic_acid() {
        let mut m = Molecule::default();
        for _ in 0..3 {
            m.atoms.push(Atom::new(vec2(0., 0.), "C"));
        }
        bond(&mut m, 0, 1, 1);
        bond(&mut m, 1, 2, 1);
        let carbonyl_o = m.atoms.len();
        m.atoms.push(Atom::new(vec2(0., 0.), "O"));
        bond(&mut m, 0, carbonyl_o, 2);
        let hydroxyl_o = m.atoms.len();
        m.atoms.push(Atom::new(vec2(0., 0.), "O"));
        bond(&mut m, 0, hydroxyl_o, 1);
        assert_eq!(name(&m).unwrap().name, "propanoic acid");
    }
}
