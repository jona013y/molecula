#![cfg_attr(target_os = "windows", windows_subsystem = "windows")]

use macroquad::prelude::*;
use std::borrow::Cow;
use std::cell::{Cell, RefCell};
use std::fs;
#[cfg(target_os = "windows")]
use std::fs::OpenOptions;
#[cfg(target_os = "windows")]
use std::io::Write;
use std::path::{Path, PathBuf};
use std::sync::mpsc::{self, Receiver};

mod chemistry;
mod naming;
mod native;
mod rdkit;
mod reaction;
mod shortcuts;

const TOP: f32 = 86.;
const LEFT: f32 = 88.;
const BOTTOM: f32 = 86.;
const RIGHT: f32 = 250.;
const BOND: f32 = 43.;
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
enum Language {
    English,
    Danish,
}
impl Language {
    fn from_settings(value: &str) -> Self {
        if value.trim() == "language=da" {
            Self::Danish
        } else {
            Self::English
        }
    }
    fn setting(self) -> &'static str {
        match self {
            Self::English => "language=en\n",
            Self::Danish => "language=da\n",
        }
    }
}
fn settings_path() -> PathBuf {
    let home = std::env::var_os("HOME")
        .map(PathBuf::from)
        .unwrap_or_else(|| PathBuf::from("."));
    if cfg!(target_os = "macos") {
        home.join("Library/Application Support/Molecula/settings.conf")
    } else {
        std::env::var_os("XDG_CONFIG_HOME")
            .map(PathBuf::from)
            .unwrap_or_else(|| home.join(".config"))
            .join("molecula/settings.conf")
    }
}
fn load_language() -> Language {
    load_language_from(&settings_path())
}
fn load_language_from(path: &Path) -> Language {
    fs::read_to_string(path)
        .map(|value| Language::from_settings(&value))
        .unwrap_or(Language::English)
}
fn save_language(language: Language) -> std::io::Result<()> {
    save_language_to(&settings_path(), language)
}
fn save_language_to(path: &Path, language: Language) -> std::io::Result<()> {
    if let Some(parent) = path.parent() {
        fs::create_dir_all(parent)?;
    }
    fs::write(path, language.setting())
}
fn localized<'a>(language: Language, source: &'a str) -> Cow<'a, str> {
    if language == Language::English {
        return Cow::Borrowed(source);
    }
    let exact = match source {
        "File" => "Filer",
        "Edit" => "Rediger",
        "View" => "Vis",
        "Insert" => "Indsæt",
        "Atom" => "Atom",
        "Bond" => "Binding",
        "Structure" => "Struktur",
        "Calculations" => "Beregninger",
        "Services" => "Tjenester",
        "Help" => "Hjælp",
        "New" => "Nyt",
        "Open" => "Åbn",
        "Save" => "Gem",
        "Undo" => "Fortryd",
        "Redo" => "Gentag",
        "Delete selection" => "Slet markering",
        "Fit" => "Tilpas visning",
        "Elements" => "Grundstoffer",
        "Templates" => "Skabeloner",
        "Arrow" => "Reaktionspil",
        "Equilibrium arrow" => "Ligevægtspil",
        "Resonance arrow" => "Resonanspil",
        "Retrosynthesis arrow" => "Retrosyntesepil",
        "Electron pair arrow" => "Elektronparspil",
        "Single electron arrow" => "Enkelt-elektronpil",
        "Plus" => "Plus",
        "Text" => "Tekst",
        "Line" => "Linje",
        "Rectangle" => "Rektangel",
        "Ellipse" => "Ellipse",
        "Charge +" => "Ladning +",
        "Charge -" => "Ladning -",
        "Single" => "Enkeltbinding",
        "Double" => "Dobbeltbinding",
        "Triple" => "Tripelbinding",
        "Aromatic" => "Aromatisk",
        "Wedge" => "Fyldt kile",
        "Hash" => "Stiplet kile",
        "Wavy" => "Bølgebinding",
        "Validate" => "Kontrollér struktur",
        "Name structure" => "Navngiv struktur",
        "Clean 2D" => "Ryd op i 2D",
        "Add explicit hydrogens" => "Tilføj eksplicitte hydrogenatomer",
        "Remove explicit hydrogens" => "Fjern eksplicitte hydrogenatomer",
        "Rotate 90 CW" => "Rotér 90° med uret",
        "Rotate 90 CCW" => "Rotér 90° mod uret",
        "Rotate 180" => "Rotér 180°",
        "Flip left-right" => "Vend venstre-højre",
        "Flip up-down" => "Vend op-ned",
        "Benzene template" => "Benzen-skabelon",
        "Formula & mass" => "Formel og masse",
        "Molecular properties" => "Molekyleegenskaber",
        "Reaction analysis" => "Reaktionsanalyse",
        "RDKit descriptors" => "RDKit-deskriptorer",
        "Integration status" => "Integrationsstatus",
        "Quick start guide" => "Hurtig vejledning",
        "Shortcuts" => "Tastaturgenveje",
        "Feature status" => "Funktionsstatus",
        "Settings" => "Indstillinger",
        "Edit text above" => "Redigér tekst over pilen",
        "Edit text below" => "Redigér tekst under pilen",
        "Change arrow type" => "Skift piltype",
        "Document" => "Dokument",
        "Local graph properties" => "Lokale grafegenskaber",
        "Elements:" => "Grundstoffer:",
        "Atoms:" => "Atomer:",
        "Bonds:" => "Bindinger:",
        "Method: local valence/H count and embedded mass table." => "Metode: lokal valens-/H-beregning og indbygget massetabel.",
        "Method: graph counts and embedded mass table." => "Metode: graftælling og indbygget massetabel.",
        "Unusual valence, query chemistry and unsupported elements may be unresolved." => "Usædvanlig valens, søgekemi og ikke-understøttede grundstoffer kan være uafklarede.",
        "logP, TPSA, pKa, NMR and 3D require a verified chemistry engine." => "logP, TPSA, pKa, NMR og 3D kræver en verificeret kemimotor.",
        "Select and drag atoms or graphic objects (Esc)" => "Vælg, eller træk atomer og grafiske objekter (Esc)",
        "Delete one atom, bond or object (E)" => "Slet et atom, en binding eller et objekt (E)",
        "Draw a single bond (1)" => "Tegn en enkeltbinding (1)",
        "Draw a double bond (2)" => "Tegn en dobbeltbinding (2)",
        "Draw a triple bond (3)" => "Tegn en tripelbinding (3)",
        "Draw an aromatic bond (4)" => "Tegn en aromatisk binding (4)",
        "Draw a filled wedge (5)" => "Tegn en fyldt kile (5)",
        "Draw a hashed wedge (6)" => "Tegn en stiplet kile (6)",
        "Draw an unspecified stereo bond (7)" => "Tegn en binding med uspecificeret stereokemi (7)",
        "Place or replace an atom (element symbol)" => "Placér eller udskift et atom (grundstofsymbol)",
        "Draw a zigzag carbon chain (drag between endpoints)" => "Tegn en zigzag-kæde af kulstof (træk mellem endepunkter)",
        "Place a six-membered ring (Shift+R)" => "Placér en seksleddet ring (Shift+R)",
        "Place a five-membered ring" => "Placér en femleddet ring",
        "Increase atom charge (+)" => "Forøg atomets ladning (+)",
        "Decrease atom charge (-)" => "Sænk atomets ladning (-)",
        "Drag to draw a reaction arrow" => "Træk for at tegne en reaktionspil",
        "Drag to draw a single-electron fishhook arrow" => "Træk for at tegne en fiskekrogspil for ét elektron",
        "Drag to draw a two-electron curved arrow" => "Træk for at tegne en buet pil for to elektroner",
        "Place a reaction plus sign" => "Placér et plustegn mellem reaktanter",
        "Place a text label" => "Placér en tekstetiket",
        "Drag to draw a line" => "Træk for at tegne en linje",
        "Drag to draw a rectangle" => "Træk for at tegne et rektangel",
        "Drag to draw an ellipse" => "Træk for at tegne en ellipse",
        "Click canvas to place template" => "Klik på lærredet for at placere skabelonen",
        "MOLECULA · QUICK START" => "MOLECULA · HURTIG VEJLEDNING",
        "01  DRAW" => "01  TEGN",
        "Choose a bond on the left, then drag or click two points. Choose Chain near the top of the tools to draw a zigzag carbon chain." => "Vælg en binding til venstre, og træk eller klik på to punkter. Vælg Kæde for at tegne en zigzag-kæde af kulstof.",
        "02  CHANGE ATOMS" => "02  SKIFT ATOMER",
        "Choose C, N, O or another element below. Click an atom to replace it. Use the periodic table for all elements." => "Vælg C, N, O eller et andet grundstof nedenfor. Klik på et atom for at udskifte det. Brug periodesystemet til alle grundstoffer.",
        "03  BUILD A REACTION" => "03  BYG EN REAKTION",
        "Place reactants left and products right. Insert → Arrow draws a reaction arrow. Use Calculations → Reaction analysis when you want formula, molar mass and balance. Use e⁻ tools for curved electron flow." => "Placér reaktanter til venstre og produkter til højre. Indsæt → Reaktionspil tegner en pil. Brug Beregninger → Reaktionsanalyse til formel, molmasse og balance. Brug e⁻-værktøjerne til buet elektronbevægelse.",
        "04  NAME AND CHECK" => "04  NAVNGIV OG KONTROLLÉR",
        "Structure → Name structure gives a name in the supported teaching subset. Molecular properties shows formula and mass." => "Struktur → Navngiv struktur giver et navn inden for det understøttede undervisningsområde. Molekyleegenskaber viser formel og masse.",
        "05  SAVE" => "05  GEM",
        "File → Save writes a .mols document with editable chemistry and graphics." => "Filer → Gem opretter et .mols-dokument med redigerbar kemi og grafik.",
        "UNDO Cmd/Ctrl+Z   ·   REDO Cmd/Ctrl+Y   ·   DELETE Delete   ·   CANCEL Esc" => "FORTRYD Cmd/Ctrl+Z   ·   GENTAG Cmd/Ctrl+Y   ·   SLET Delete   ·   ANNULLÉR Esc",
        "Sel" => "Vælg",
        "Del" => "Slet",
        "Chain" => "Kæde",
        "->" => "Pil",
        "e2" => "e-par",
        "e1" => "e−",
        "+R" => "Plus",
        "Txt" => "Tekst",
        "Wd" => "Kile",
        "Hs" => "Stiplet",
        "Wv" => "Bølge",
        "INSPECTOR" => "INSPEKTØR",
        "Properties" => "Egenskaber",
        "Canvas selection" => "Markering på lærredet",
        "Selected bond" => "Valgt binding",
        "Reaction arrow" => "Reaktionspil",
        "Electron-flow arrow" => "Elektronpil",
        "Graphic object" => "Grafisk objekt",
        "Nothing selected" => "Intet valgt",
        "Drag a box to select atoms" => "Træk en boks for at vælge atomer",
        "or click a bond/object" => "eller klik på binding/objekt",
        "Whole document" => "Hele dokumentet",
        "Analysis & information" => "Analyse og information",
        "Close" => "Luk",
        "Language preference saved" => "Sprogvalg gemt",
        "Could not save language preference" => "Sprogvalget kunne ikke gemmes",
        "Enter text" => "Indtast tekst",
        "Cancel" => "Annullér",
        "Apply" => "Anvend",
        "Periodic table - choose an element" => "Periodesystem – vælg et grundstof",
        "Choose a tool or drag on the canvas" => "Vælg et værktøj, eller træk på lærredet",
        "Start drawing chemistry" => "Begynd at tegne kemi",
        "Ready: draw a bond or choose a tool" => "Klar: tegn en binding, eller vælg et værktøj",
        "Analysis" => "Analyse",
        "ELEMENTS" => "GRUNDSTOFFER",
        "TOOLS" => "VÆRKTØJER",
        "English" | "Dansk" => source,
        "Language" => "Sprog",
        "Interface language" => "Grænsefladesprog",
        "Saved automatically" => "Gemmes automatisk",
        "New document" => "Nyt dokument",
        "Open MOL or MOLS" => "Åbn MOL eller MOLS",
        "Save molecule" => "Gem molekyle",
        "Export may lose information" => "Eksport kan miste information",
        "Save as .mols to preserve the full document." => "Gem som .mols for at bevare hele dokumentet.",
        "Use an absolute path or a path relative to the launch folder." => "Brug en absolut sti eller en sti relativ til programmets mappe.",
        "Draw a reaction, equilibrium, or retrosynthesis arrow first" => "Tegn først en reaktions-, ligevægts- eller retrosyntesepil",
        "RDKit and Open Babel are not installed." => "RDKit og Open Babel er ikke installeret.",
        "3D generation, IUPAC names, advanced descriptors, InChI and broad format conversion are unavailable." => "3D-generering, IUPAC-navne, avancerede deskriptorer, InChI og bred filkonvertering er utilgængelige.",
        "Local drawing, MOL and MOLS still work." => "Lokal tegning samt MOL og MOLS fungerer stadig.",
        "RDKit descriptor worker failed" => "RDKit-beregningen mislykkedes",
        "Calculating RDKit descriptors…" => "Beregner RDKit-deskriptorer…",
        "Draw a molecule first" => "Tegn først et molekyle",
        "Click canvas to place benzene" => "Klik på lærredet for at placere benzen",
        "Select an atom before assigning an R-group" => "Vælg et atom, før du tilføjer en R-gruppe",
        "Select an atom before assigning a map number" => "Vælg et atom, før du tilføjer et atomkortnummer",
        "Select an atom before assigning a query" => "Vælg et atom, før du tilføjer et søgekriterium",
        "Calculating with RDKit..." => "Beregner med RDKit...",
        "Arrow placed" => "Pil placeret",
        "Undid edit" => "Redigering fortrudt",
        "Redid edit" => "Redigering gentaget",
        "No implicit hydrogens to expand" => "Ingen implicitte hydrogenatomer at udvide",
        "Added explicit hydrogen atoms" => "Tilføjede eksplicitte hydrogenatomer",
        "No attached explicit hydrogens to remove" => "Ingen tilknyttede eksplicitte hydrogenatomer at fjerne",
        "Removed explicit hydrogen atoms" => "Fjernede eksplicitte hydrogenatomer",
        "Draw a structure first" => "Tegn først en struktur",
        "Draw at least two atoms before cleaning" => "Tegn mindst to atomer før oprydning",
        "Cleaned 2D coordinates using a spring layout" => "Ryddede op i 2D-koordinater med fjederlayout",
        "MOL V2000 cannot store more than 999 atoms or bonds" => "MOL V2000 kan højst gemme 999 atomer eller bindinger",
        "Unsupported extension. Use .mols, .mol or .svg" => "Filtypen understøttes ikke. Brug .mols, .mol eller .svg",
        "Calculation finished" => "Beregning færdig",
        "Discarded calculation for an earlier molecule" => "Kasserede beregning for et tidligere molekyle",
        "Click the arrow end point, or drag from the start" => "Klik på pilens slutpunkt, eller træk fra startpunktet",
        "GRAPH" => "GRAF",
        "Clear iso" => "Fjern isotop",
        "Delete bond" => "Slet binding",
        "Export" => "Eksportér",
        "Type: reaction" => "Type: reaktion",
        "Type: equilibrium" => "Type: ligevægt",
        "Type: resonance" => "Type: resonans",
        "Type: retrosynthesis" => "Type: retrosyntese",
        "No basic valence warnings found. Advanced stereochemistry and structure checks require a chemistry engine." => "Ingen grundlæggende valensadvarsler. Avanceret stereokemi og strukturkontrol kræver en kemimotor.",
        "See STATUS.md in the source folder for implemented, partial and unavailable functions." => "Se STATUS.md i programmets mappe for funktioner, der er implementeret, delvise eller utilgængelige.",
        "Cmd/Ctrl+N: New | O: Open | S: Save | Z: Undo | Y: Redo" => "Cmd/Ctrl+N: Nyt | O: Åbn | S: Gem | Z: Fortryd | Y: Gentag",
        "Delete: delete selection | Esc: select tool | Shift+R: six-membered ring" => "Delete: slet markering | Esc: vælgerværktøj | Shift+R: seksleddet ring",
        "Drawing buffer: 1/2/3 orders, 4 aromatic, 5 wedge, 6 hash, 7 wavy" => "Tegneinput: 1/2/3 bindinger, 4 aromatisk, 5 kile, 6 stiplet, 7 bølget",
        "C, N, O, Cl... select element; + and - change selected charge" => "C, N, O, Cl... vælg grundstof; + og - ændrer ladningen",
        "R1...R32767 assigns R-group; M1... assigns atom map" => "R1...R32767 angiver R-gruppe; M1... angiver atomkort",
        "Ctrl+E opens the periodic table." => "Ctrl+E åbner periodesystemet.",
        _ => return localized_dynamic(source),
    };
    Cow::Borrowed(exact)
}
fn localized_dynamic(source: &str) -> Cow<'_, str> {
    for (prefix, replacement) in [
        ("Charge:", "Ladning:"),
        ("Isotope:", "Isotop:"),
        ("Map:", "Atomkort:"),
        ("Query:", "Søgekriterium:"),
        ("Bond order:", "Bindingsorden:"),
        ("Style:", "Stil:"),
        ("Stereo:", "Stereokemi:"),
        ("Internal bonds:", "Interne bindinger:"),
        ("Formal charge:", "Formel ladning:"),
        ("Formula:", "Formel:"),
        ("Molar:", "Molmasse:"),
        ("Exact:", "Eksakt:"),
        ("Selected implicit H:", "Valgt implicit H:"),
        ("Warnings:", "Advarsler:"),
        ("Elements:", "Grundstoffer:"),
        ("Atoms:", "Atomer:"),
        ("Bonds:", "Bindinger:"),
        ("Reactants:", "Reaktanter:"),
        ("Products:", "Produkter:"),
        ("Agents:", "Reagenser:"),
        ("Balance unavailable:", "Balance utilgængelig:"),
        ("Method:", "Metode:"),
        ("Element: ", "Grundstof: "),
        ("Selected ", "Valgte "),
        ("Saved ", "Gemt "),
        ("Opened ", "Åbnede "),
        ("Drew a ", "Tegnede en "),
    ] {
        if let Some(rest) = source.strip_prefix(prefix) {
            return Cow::Owned(format!("{replacement}{rest}"));
        }
    }
    if let Some(count) = source.strip_suffix(" atoms") {
        return Cow::Owned(format!("{count} atomer"));
    }
    if source.contains(" atoms  ·  ") && source.ends_with(" bonds") {
        return Cow::Owned(
            source
                .replace(" atoms", " atomer")
                .replace(" bonds", " bindinger"),
        );
    }
    Cow::Borrowed(source)
}
fn ink() -> Color {
    Color::from_rgba(25, 49, 39, 255)
}
fn muted() -> Color {
    Color::from_rgba(103, 129, 115, 255)
}
fn navy() -> Color {
    Color::from_rgba(20, 49, 39, 255)
}
fn accent() -> Color {
    Color::from_rgba(36, 139, 94, 255)
}
fn surface() -> Color {
    Color::from_rgba(246, 250, 247, 255)
}
fn round_rect(x: f32, y: f32, w: f32, h: f32, r: f32, c: Color) {
    let r = r.min(w / 2.).min(h / 2.);
    draw_rectangle(x + r, y, w - 2. * r, h, c);
    draw_rectangle(x, y + r, r, h - 2. * r, c);
    draw_rectangle(x + w - r, y + r, r, h - 2. * r, c);
    for (cx, cy) in [
        (x + r, y + r),
        (x + w - r, y + r),
        (x + r, y + h - r),
        (x + w - r, y + h - r),
    ] {
        draw_circle(cx, cy, r, c);
    }
}
fn round_border(x: f32, y: f32, w: f32, h: f32, r: f32, c: Color) {
    round_rect(x, y, w, h, r, c);
    round_rect(x + 1., y + 1., w - 2., h - 2., (r - 1.).max(0.), WHITE);
}
fn draw_shape(kind: ShapeKind, a: Vec2, b: Vec2, color: Color) {
    let x = a.x.min(b.x);
    let y = a.y.min(b.y);
    let w = (a.x - b.x).abs().max(1.);
    let h = (a.y - b.y).abs().max(1.);
    match kind {
        ShapeKind::Line => draw_line(a.x, a.y, b.x, b.y, 2., color),
        ShapeKind::Rectangle => draw_rectangle_lines(x, y, w, h, 2., color),
        ShapeKind::Ellipse => {
            for k in 0..48 {
                let t = std::f32::consts::TAU * k as f32 / 48.;
                let u = std::f32::consts::TAU * (k + 1) as f32 / 48.;
                draw_line(
                    x + w / 2. + w / 2. * t.cos(),
                    y + h / 2. + h / 2. * t.sin(),
                    x + w / 2. + w / 2. * u.cos(),
                    y + h / 2. + h / 2. * u.sin(),
                    2.,
                    color,
                );
            }
        }
    }
}
fn tool_button(x: f32, y: f32, w: f32, h: f32, t: Tool, active: bool) -> bool {
    let p = vec2(mouse_position().0, mouse_position().1);
    let hover = p.x >= x && p.x < x + w && p.y >= y && p.y < y + h;
    if active {
        round_rect(x, y, w, h, 11., accent());
    } else if hover {
        round_rect(x, y, w, h, 11., Color::from_rgba(37, 78, 61, 255));
    }
    let c = if active || hover {
        WHITE
    } else {
        Color::from_rgba(175, 205, 187, 255)
    };
    let cx = x + w / 2.;
    let cy = y + h / 2.;
    match t {
        Tool::Select => {
            draw_line(cx - 9., cy - 10., cx - 9., cy + 8., 2., c);
            draw_line(cx - 9., cy - 10., cx + 7., cy + 2., 2., c);
            draw_line(cx + 7., cy + 2., cx - 9., cy + 2., 2., c);
        }
        Tool::Erase => {
            draw_line(cx - 10., cy + 5., cx + 4., cy - 9., 4., c);
            draw_line(cx + 4., cy - 9., cx + 11., cy - 2., 4., c);
            draw_line(cx - 3., cy + 11., cx + 11., cy + 11., 1.5, c);
        }
        Tool::Bond(n) => {
            for k in 0..n {
                let o = (k as f32 - (n as f32 - 1.) / 2.) * 4.;
                draw_line(cx - 12., cy + 7. + o, cx + 12., cy - 7. + o, 2., c);
            }
        }
        Tool::StyledBond(BondStyle::Aromatic) => {
            draw_line(cx - 12., cy + 6., cx + 12., cy - 6., 2., c);
            draw_line(cx - 7., cy + 10., cx + 7., cy - 10., 1., c);
        }
        Tool::StyledBond(BondStyle::Wedge) => {
            draw_triangle(
                vec2(cx - 12., cy + 7.),
                vec2(cx + 11., cy - 10.),
                vec2(cx + 9., cy - 2.),
                c,
            );
        }
        Tool::StyledBond(BondStyle::Hash) => {
            for k in 0..5 {
                let xx = cx - 10. + k as f32 * 5.;
                draw_line(
                    xx,
                    cy + 7. - k as f32 * 3.,
                    xx + 3.,
                    cy + 9. - k as f32 * 2.,
                    1.5,
                    c,
                );
            }
        }
        Tool::StyledBond(BondStyle::Wavy) => {
            for k in 0..5 {
                let xx = cx - 12. + k as f32 * 5.;
                draw_line(
                    xx,
                    cy + if k % 2 == 0 { 3. } else { -3. },
                    xx + 5.,
                    cy + if k % 2 == 0 { -3. } else { 3. },
                    1.8,
                    c,
                );
            }
        }
        Tool::Atom => {
            draw_text("C", cx - 7., cy + 7., 21., c);
        }
        Tool::Chain => {
            draw_line(cx - 12., cy + 6., cx - 4., cy - 6., 2., c);
            draw_line(cx - 4., cy - 6., cx + 4., cy + 6., 2., c);
            draw_line(cx + 4., cy + 6., cx + 12., cy - 6., 2., c);
        }
        Tool::Ring(n) => {
            let count = n;
            for k in 0..count {
                let a = std::f32::consts::TAU * k as f32 / n as f32;
                let b = std::f32::consts::TAU * (k + 1) as f32 / n as f32;
                draw_line(
                    cx + 11. * a.cos(),
                    cy + 11. * a.sin(),
                    cx + 11. * b.cos(),
                    cy + 11. * b.sin(),
                    1.7,
                    c,
                );
            }
        }
        Tool::Arrow => {
            draw_line(cx - 12., cy, cx + 11., cy, 2., c);
            draw_line(cx + 11., cy, cx + 3., cy - 6., 2., c);
            draw_line(cx + 11., cy, cx + 3., cy + 6., 2., c);
        }
        Tool::Shape(ShapeKind::Line) => {
            draw_line(cx - 11., cy + 8., cx + 11., cy - 8., 2., c);
        }
        Tool::Shape(ShapeKind::Rectangle) => {
            draw_rectangle_lines(cx - 11., cy - 8., 22., 16., 2., c);
        }
        Tool::Shape(ShapeKind::Ellipse) => {
            for k in 0..24 {
                let a = std::f32::consts::TAU * k as f32 / 24.;
                let b = std::f32::consts::TAU * (k + 1) as f32 / 24.;
                draw_line(
                    cx + 11. * a.cos(),
                    cy + 8. * a.sin(),
                    cx + 11. * b.cos(),
                    cy + 8. * b.sin(),
                    1.7,
                    c,
                );
            }
        }
        Tool::Electron(n) => {
            let a = vec2(cx - 12., cy + 8.);
            let b = vec2(cx + 11., cy + 5.);
            let control = vec2(cx, cy - 13.);
            let mut prev = a;
            for k in 1..=12 {
                let t = k as f32 / 12.;
                let p = a * (1. - t).powi(2) + control * (2. * t * (1. - t)) + b * t * t;
                draw_line(prev.x, prev.y, p.x, p.y, 1.8, c);
                prev = p;
            }
            draw_line(b.x, b.y, b.x - 6., b.y - 6., 1.8, c);
            if n == 2 {
                draw_line(b.x, b.y, b.x - 7., b.y + 3., 1.8, c);
            }
        }
        Tool::Plus => {
            draw_line(cx - 9., cy, cx + 9., cy, 2., c);
            draw_line(cx, cy - 9., cx, cy + 9., 2., c);
        }
        Tool::Text => draw_text("T", cx - 6., cy + 7., 21., c),
        Tool::Charge(n) => {
            draw_text(if n > 0 { "+" } else { "−" }, cx - 7., cy + 7., 22., c);
        }
        _ => draw_circle(cx, cy, 4., c),
    }
    hover && is_mouse_button_pressed(MouseButton::Left) && UI_INPUT_ENABLED.with(Cell::get)
}
fn swap_stereo(s: &mut String) {
    let replacement = match s.as_str() {
        "R" => "S",
        "S" => "R",
        "r" => "s",
        "s" => "r",
        "CW" => "CCW",
        "CCW" => "CW",
        "E" => "Z",
        "Z" => "E",
        "cis" => "trans",
        "trans" => "cis",
        _ => return,
    };
    *s = replacement.into();
}
thread_local! {
    static UI_FONT: RefCell<Option<Font>> = const { RefCell::new(None) };
    static UI_LANGUAGE: Cell<Language> = const { Cell::new(Language::English) };
    static UI_INPUT_ENABLED: Cell<bool> = const { Cell::new(true) };
}
fn draw_text(s: &str, x: f32, y: f32, size: f32, color: Color) {
    let text = UI_LANGUAGE.with(|language| localized(language.get(), s));
    UI_FONT.with(|f| {
        let borrowed = f.borrow();
        macroquad::text::draw_text_ex(
            text.as_ref(),
            x,
            y,
            TextParams {
                font: borrowed.as_ref(),
                font_size: size as u16,
                color,
                ..Default::default()
            },
        );
    });
}
fn measure_text(s: &str, font: Option<&Font>, size: u16, scale: f32) -> TextDimensions {
    UI_FONT.with(|f| {
        let borrowed = f.borrow();
        macroquad::text::measure_text(s, font.or(borrowed.as_ref()), size, scale)
    })
}

fn window_conf() -> Conf {
    // Install before Macroquad creates its WGL context so driver panics are
    // recorded too (the previous location ran only after context creation).
    #[cfg(target_os = "windows")]
    {
        install_startup_diagnostics();
        // The Windows installer ships Mesa's OpenGL runtime beside the app.
        // Force its CPU renderer so WGL works even when the system driver lacks
        // WGL_ARB_pixel_format (the crash reported on the affected PC).
        std::env::set_var("GALLIUM_DRIVER", "llvmpipe");
        std::env::set_var("LIBGL_ALWAYS_SOFTWARE", "1");
    }

    Conf {
        window_title: "molecula — Structure Studio".into(),
        window_width: 1400,
        window_height: 900,
        window_resizable: true,
        high_dpi: true,
        // Use the Molecula mark for the running window and macOS Dock as well
        // as the app bundle's Finder icon. Miniquad's default is its red/black
        // logo, which otherwise appears in the Dock while this app is open.
        icon: Some(macroquad::miniquad::conf::Icon {
            small: *include_bytes!("../assets/molecula-16.rgba"),
            medium: *include_bytes!("../assets/molecula-32.rgba"),
            big: *include_bytes!("../assets/molecula-64.rgba"),
        }),
        // Avoid requiring a 4x multisample WGL pixel format. Some older and
        // remote Windows graphics drivers fail during context creation when
        // that format is unavailable.
        sample_count: 1,
        ..Default::default()
    }
}

#[cfg(target_os = "windows")]
fn install_startup_diagnostics() {
    let directory = std::env::var_os("LOCALAPPDATA")
        .map(PathBuf::from)
        .unwrap_or_else(std::env::temp_dir)
        .join("Molecula");
    let _ = fs::create_dir_all(&directory);
    let log_path = directory.join("startup.log");
    let _ = fs::write(
        &log_path,
        "Molecula started; waiting for editor initialization.\n",
    );

    let previous_hook = std::panic::take_hook();
    std::panic::set_hook(Box::new(move |info| {
        if let Ok(mut file) = OpenOptions::new().create(true).append(true).open(&log_path) {
            let _ = writeln!(file, "Startup error: {info}");
            let _ = writeln!(
                file,
                "Backtrace:\n{}",
                std::backtrace::Backtrace::force_capture()
            );
        }
        previous_hook(info);
    }));
}

#[cfg(target_os = "windows")]
fn record_startup_note(note: &str) {
    let directory = std::env::var_os("LOCALAPPDATA")
        .map(PathBuf::from)
        .unwrap_or_else(std::env::temp_dir)
        .join("Molecula");
    if let Ok(mut file) = OpenOptions::new()
        .create(true)
        .append(true)
        .open(directory.join("startup.log"))
    {
        let _ = writeln!(file, "{note}");
    }
}

#[derive(Clone, Debug, PartialEq)]
struct Atom {
    pos: Vec2,
    z: Option<f32>,
    element: String,
    charge: i8,
    isotope: Option<u16>,
    radical: u8,
    explicit_h: u8,
    implicit_h_override: Option<u8>,
    alias: Option<String>,
    atom_map: Option<u16>,
    aromatic: bool,
    stereo: Option<String>,
    r_group: Option<u16>,
    query: Option<String>,
}
impl Atom {
    fn new(pos: Vec2, element: &str) -> Self {
        Self {
            pos,
            z: None,
            element: element.into(),
            charge: 0,
            isotope: None,
            radical: 0,
            explicit_h: 0,
            implicit_h_override: None,
            alias: None,
            atom_map: None,
            aromatic: false,
            stereo: None,
            r_group: None,
            query: None,
        }
    }
}
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
enum BondStyle {
    Normal,
    Aromatic,
    Wedge,
    Hash,
    Wavy,
    Coordinate,
    Any,
}
impl BondStyle {
    fn code(self) -> &'static str {
        match self {
            Self::Normal => "normal",
            Self::Aromatic => "aromatic",
            Self::Wedge => "wedge",
            Self::Hash => "hash",
            Self::Wavy => "wavy",
            Self::Coordinate => "coordinate",
            Self::Any => "any",
        }
    }
    fn parse(s: &str) -> Option<Self> {
        Some(match s {
            "normal" => Self::Normal,
            "aromatic" => Self::Aromatic,
            "wedge" => Self::Wedge,
            "hash" => Self::Hash,
            "wavy" => Self::Wavy,
            "coordinate" => Self::Coordinate,
            "any" => Self::Any,
            _ => return None,
        })
    }
}
#[derive(Clone, Debug, PartialEq)]
struct Bond {
    a: usize,
    b: usize,
    order: u8,
    style: BondStyle,
    stereo: Option<String>,
    query: Option<String>,
}
#[derive(Clone, Debug, Default, PartialEq)]
struct Molecule {
    atoms: Vec<Atom>,
    bonds: Vec<Bond>,
    name: String,
    properties: Vec<(String, String)>,
}
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
enum ShapeKind {
    Line,
    Rectangle,
    Ellipse,
}
impl ShapeKind {
    fn code(&self) -> &'static str {
        match self {
            Self::Line => "line",
            Self::Rectangle => "rectangle",
            Self::Ellipse => "ellipse",
        }
    }
    fn parse(s: &str) -> Option<Self> {
        Some(match s {
            "line" => Self::Line,
            "rectangle" => Self::Rectangle,
            "ellipse" => Self::Ellipse,
            _ => return None,
        })
    }
}
#[derive(Clone, Debug, PartialEq)]
enum Graphic {
    Arrow {
        start: Vec2,
        end: Vec2,
        kind: String,
        above: String,
        below: String,
    },
    Text {
        pos: Vec2,
        text: String,
        size: f32,
        bold: bool,
        italic: bool,
    },
    Plus {
        pos: Vec2,
    },
    ElectronArrow {
        start: Vec2,
        control: Vec2,
        end: Vec2,
        electrons: u8,
    },
    Shape {
        kind: ShapeKind,
        start: Vec2,
        end: Vec2,
    },
}
#[derive(Clone)]
struct Snapshot {
    mol: Molecule,
    graphics: Vec<Graphic>,
}
#[derive(Clone, Copy, PartialEq)]
enum Tool {
    Select,
    Erase,
    Bond(u8),
    StyledBond(BondStyle),
    Atom,
    Chain,
    Ring(usize),
    Charge(i8),
    Arrow,
    Electron(u8),
    Plus,
    Text,
    Template(&'static str),
    Shape(ShapeKind),
}
#[derive(Clone, Copy)]
enum TextTarget {
    New(Vec2),
    ArrowAbove(usize),
    ArrowBelow(usize),
}
struct Editor {
    mol: Molecule,
    graphics: Vec<Graphic>,
    undo: Vec<Snapshot>,
    redo: Vec<Snapshot>,
    tool: Tool,
    element: String,
    selected: Option<usize>,
    selected_atoms: Vec<usize>,
    selected_bond: Option<usize>,
    selected_graphic: Option<usize>,
    drag_start: Option<Vec2>,
    selection_box: Option<Vec2>,
    moved: bool,
    file_dialog: Option<bool>,
    path_input: String,
    status: String,
    quick: shortcuts::QuickInput,
    pending_export: Option<String>,
    periodic_open: bool,
    templates_open: bool,
    text_target: Option<TextTarget>,
    text_buffer: String,
    bond_query: Option<String>,
    menu_open: Option<usize>,
    palette_open: bool,
    palette_query: String,
    palette_selection: usize,
    info_overlay: Option<String>,
    settings_open: bool,
    language: Language,
    arrow_kind: String,
    pending_arrow: Option<Vec2>,
    calc_rx: Option<(Molecule, Receiver<Result<String, String>>)>,
}
impl Editor {
    fn set_language(&mut self, language: Language) {
        self.language = language;
        UI_LANGUAGE.with(|current| current.set(language));
        self.status = match save_language(language) {
            Ok(()) => "Language preference saved".into(),
            Err(_) => "Could not save language preference".into(),
        };
    }
    fn finish_arrow(&mut self, p: Vec2) {
        let drag = self.drag_start.unwrap_or(p);
        let start = if drag.distance(p) > 18. {
            Some(drag)
        } else {
            self.pending_arrow.filter(|a| a.distance(p) > 18.)
        };
        if let Some(start) = start {
            self.checkpoint();
            match self.tool {
                Tool::Arrow => self.graphics.push(Graphic::Arrow {
                    start,
                    end: p,
                    kind: self.arrow_kind.clone(),
                    above: String::new(),
                    below: String::new(),
                }),
                Tool::Electron(electrons) => self.graphics.push(Graphic::ElectronArrow {
                    start,
                    control: electron_control(start, p),
                    end: p,
                    electrons,
                }),
                _ => return,
            }
            self.pending_arrow = None;
            self.status = "Arrow placed".into();
        } else {
            self.pending_arrow = Some(p);
            self.status = "Click the arrow end point, or drag from the start".into();
        }
    }
    fn new() -> Self {
        Self {
            mol: Molecule::default(),
            graphics: vec![],
            undo: vec![],
            redo: vec![],
            tool: Tool::Bond(1),
            element: "C".into(),
            selected: None,
            selected_atoms: Vec::new(),
            selected_bond: None,
            selected_graphic: None,
            drag_start: None,
            selection_box: None,
            moved: false,
            file_dialog: None,
            path_input: format!(
                "{}/Documents/molecule.mols",
                std::env::var("HOME").unwrap_or_else(|_| ".".into())
            ),
            status: "Ready: draw a bond or choose a tool".into(),
            quick: shortcuts::QuickInput::default(),
            pending_export: None,
            periodic_open: false,
            templates_open: false,
            text_target: None,
            text_buffer: String::new(),
            bond_query: None,
            menu_open: None,
            palette_open: false,
            palette_query: String::new(),
            palette_selection: 0,
            info_overlay: None,
            settings_open: false,
            language: load_language(),
            arrow_kind: "reaction".into(),
            pending_arrow: None,
            calc_rx: None,
        }
    }
    fn checkpoint(&mut self) {
        self.undo.push(Snapshot {
            mol: self.mol.clone(),
            graphics: self.graphics.clone(),
        });
        if self.undo.len() > 100 {
            self.undo.remove(0);
        }
        self.redo.clear();
    }
    fn undo(&mut self) {
        if let Some(m) = self.undo.pop() {
            self.redo.push(Snapshot {
                mol: self.mol.clone(),
                graphics: self.graphics.clone(),
            });
            self.mol = m.mol;
            self.graphics = m.graphics;
            self.selected = None;
            self.selected_atoms.clear();
            self.selected_bond = None;
            self.selected_graphic = None;
            self.status = "Undid edit".into();
        }
    }
    fn redo(&mut self) {
        if let Some(m) = self.redo.pop() {
            self.undo.push(Snapshot {
                mol: self.mol.clone(),
                graphics: self.graphics.clone(),
            });
            self.mol = m.mol;
            self.graphics = m.graphics;
            self.selected = None;
            self.selected_atoms.clear();
            self.selected_bond = None;
            self.selected_graphic = None;
            self.status = "Redid edit".into();
        }
    }
    fn hit_atom(&self, p: Vec2) -> Option<usize> {
        self.mol
            .atoms
            .iter()
            .enumerate()
            .rev()
            .find(|(_, a)| a.pos.distance(p) < 15.)
            .map(|(i, _)| i)
    }
    fn hit_bond(&self, p: Vec2) -> Option<usize> {
        self.mol
            .bonds
            .iter()
            .enumerate()
            .find(|(_, b)| {
                distance_segment(p, self.mol.atoms[b.a].pos, self.mol.atoms[b.b].pos) < 9.
            })
            .map(|(i, _)| i)
    }
    fn atoms_in_rect(&self, a: Vec2, b: Vec2) -> Vec<usize> {
        let (left, right) = (a.x.min(b.x), a.x.max(b.x));
        let (top, bottom) = (a.y.min(b.y), a.y.max(b.y));
        self.mol
            .atoms
            .iter()
            .enumerate()
            .filter_map(|(i, atom)| {
                (atom.pos.x >= left
                    && atom.pos.x <= right
                    && atom.pos.y >= top
                    && atom.pos.y <= bottom)
                    .then_some(i)
            })
            .collect()
    }
    fn select_at(&mut self, p: Vec2) {
        self.selected = self.hit_atom(p);
        self.selected_atoms = self.selected.into_iter().collect();
        self.selected_bond = if self.selected.is_none() {
            self.hit_bond(p)
        } else {
            None
        };
        self.selected_graphic = if self.selected.is_none() && self.selected_bond.is_none() {
            self.hit_graphic(p)
        } else {
            None
        };
        self.selection_box = if self.selected.is_none()
            && self.selected_bond.is_none()
            && self.selected_graphic.is_none()
        {
            Some(p)
        } else {
            None
        };
    }
    fn select_box(&mut self, a: Vec2, b: Vec2) {
        self.selected_atoms = self.atoms_in_rect(a, b);
        self.selected = (self.selected_atoms.len() == 1).then(|| self.selected_atoms[0]);
        self.selected_bond = None;
        self.selected_graphic = None;
        self.status = if self.selected_atoms.is_empty() {
            "Nothing selected".into()
        } else {
            format!("Selected {} atom(s)", self.selected_atoms.len())
        };
    }
    fn hit_graphic(&self, p: Vec2) -> Option<usize> {
        self.graphics
            .iter()
            .enumerate()
            .rev()
            .find(|(_, g)| match g {
                Graphic::Arrow { start, end, .. } => distance_segment(p, *start, *end) < 10.,
                Graphic::ElectronArrow {
                    start,
                    control,
                    end,
                    ..
                } => (0..16).any(|k| {
                    let t = k as f32 / 16.;
                    let a =
                        *start * (1. - t).powi(2) + *control * (2. * t * (1. - t)) + *end * t * t;
                    let u = (k + 1) as f32 / 16.;
                    let b =
                        *start * (1. - u).powi(2) + *control * (2. * u * (1. - u)) + *end * u * u;
                    distance_segment(p, a, b) < 10.
                }),
                Graphic::Plus { pos } => p.distance(*pos) < 18.,
                Graphic::Shape {
                    kind: ShapeKind::Line,
                    start,
                    end,
                } => distance_segment(p, *start, *end) < 9.,
                Graphic::Shape {
                    kind: ShapeKind::Rectangle,
                    start,
                    end,
                } => {
                    let (x0, x1) = (start.x.min(end.x), start.x.max(end.x));
                    let (y0, y1) = (start.y.min(end.y), start.y.max(end.y));
                    p.x >= x0 - 7.
                        && p.x <= x1 + 7.
                        && p.y >= y0 - 7.
                        && p.y <= y1 + 7.
                        && ((p.x - x0).abs() < 9.
                            || (p.x - x1).abs() < 9.
                            || (p.y - y0).abs() < 9.
                            || (p.y - y1).abs() < 9.)
                }
                Graphic::Shape {
                    kind: ShapeKind::Ellipse,
                    start,
                    end,
                } => {
                    let rx = (start.x - end.x).abs() / 2.;
                    let ry = (start.y - end.y).abs() / 2.;
                    let c = (*start + *end) / 2.;
                    rx > 1.
                        && ry > 1.
                        && (((p.x - c.x) / rx).powi(2) + ((p.y - c.y) / ry).powi(2) - 1.).abs()
                            < 0.22
                }
                Graphic::Text {
                    pos, text, size, ..
                } => {
                    p.x >= pos.x
                        && p.x <= pos.x + text.len() as f32 * size * 0.6
                        && p.y >= pos.y - size
                        && p.y <= pos.y
                }
            })
            .map(|(i, _)| i)
    }
    fn add_atom(&mut self, p: Vec2, element: &str) -> usize {
        self.mol.atoms.push(Atom::new(p, element));
        self.mol.atoms.len() - 1
    }
    fn draw_chain(&mut self, start: Vec2, finish: Vec2) {
        let a_existing = self.hit_atom(start);
        let origin = a_existing.map(|i| self.mol.atoms[i].pos).unwrap_or(start);
        let delta = finish - origin;
        let length = delta.length();
        let direction = if length > 1. {
            delta / length
        } else {
            vec2(1., 0.)
        };
        let count = if length < 18. {
            3
        } else {
            ((length / BOND).round() as usize).clamp(2, 10)
        };
        let end = if length < 18. {
            origin + direction * (BOND * count as f32)
        } else {
            finish
        };
        let normal = vec2(-direction.y, direction.x);
        let mut points = Vec::with_capacity(count + 1);
        for k in 0..=count {
            let t = k as f32 / count as f32;
            let zig = if k == 0 || k == count {
                0.
            } else if k % 2 == 1 {
                -1.
            } else {
                1.
            };
            points.push(origin + (end - origin) * t + normal * zig * (BOND * 0.22));
        }
        points[0] = origin;
        points[count] = end;
        let first = a_existing.unwrap_or_else(|| self.add_atom(origin, "C"));
        let last_existing = self.hit_atom(end).filter(|i| *i != first);
        let mut prev = first;
        for point in points.iter().take(count).skip(1) {
            let next = self.add_atom(*point, "C");
            self.add_bond(prev, next, 1);
            prev = next;
        }
        let last = last_existing.unwrap_or_else(|| self.add_atom(end, "C"));
        self.add_bond(prev, last, 1);
        self.status = format!("Drew a {}-bond carbon chain", count);
    }
    fn add_bond(&mut self, a: usize, b: usize, order: u8) {
        if a == b {
            return;
        }
        if let Some(x) = self
            .mol
            .bonds
            .iter_mut()
            .find(|x| (x.a == a && x.b == b) || (x.a == b && x.b == a))
        {
            x.order = order;
        } else {
            self.mol.bonds.push(Bond {
                a,
                b,
                order,
                style: BondStyle::Normal,
                stereo: None,
                query: None,
            });
        }
    }
    fn add_styled_bond(&mut self, a: usize, b: usize, style: BondStyle) {
        self.add_bond(a, b, 1);
        if let Some(bond) = self
            .mol
            .bonds
            .iter_mut()
            .find(|x| (x.a == a && x.b == b) || (x.a == b && x.b == a))
        {
            bond.style = style;
            bond.order = if style == BondStyle::Aromatic { 4 } else { 1 };
        }
    }
    fn remove_atom(&mut self, i: usize) {
        self.mol.atoms.remove(i);
        self.mol.bonds.retain(|b| b.a != i && b.b != i);
        for b in &mut self.mol.bonds {
            if b.a > i {
                b.a -= 1;
            }
            if b.b > i {
                b.b -= 1;
            }
        }
    }
    fn ring(&mut self, center: Vec2, n: usize) {
        let radius = BOND / (2. * (std::f32::consts::PI / n as f32).sin());
        let mut ids = Vec::new();
        for k in 0..n {
            let t = -std::f32::consts::FRAC_PI_2 + 2. * std::f32::consts::PI * k as f32 / n as f32;
            let p = center + vec2(t.cos(), t.sin()) * radius;
            let id = self.hit_atom(p).unwrap_or_else(|| self.add_atom(p, "C"));
            ids.push(id);
        }
        for k in 0..n {
            self.add_bond(ids[k], ids[(k + 1) % n], 1);
        }
    }
    fn add_explicit_hydrogens(&mut self) {
        let analysis = chemistry::analyze(&self.mol);
        let original_len = self.mol.atoms.len();
        let mut planned = Vec::new();
        for i in 0..original_len {
            let atom = &self.mol.atoms[i];
            if atom.element == "H" {
                continue;
            }
            let Some(implicit) = analysis.implicit_h.get(i).copied().flatten() else {
                continue;
            };
            let total = implicit.saturating_add(atom.explicit_h).min(8);
            if total == 0 {
                continue;
            }
            let origin = atom.pos;
            let neighbors: Vec<Vec2> = self
                .mol
                .bonds
                .iter()
                .filter_map(|b| {
                    let other = if b.a == i {
                        Some(b.b)
                    } else if b.b == i {
                        Some(b.a)
                    } else {
                        None
                    }?;
                    let d = self.mol.atoms[other].pos - origin;
                    (d.length() > 0.1).then(|| d.normalize())
                })
                .collect();
            let sum = neighbors.iter().copied().sum::<Vec2>();
            let base = if sum.length() > 0.1 {
                -sum.normalize()
            } else {
                vec2(1., 0.)
            };
            for k in 0..total {
                let angle = base.y.atan2(base.x) + std::f32::consts::TAU * k as f32 / total as f32;
                planned.push((i, origin + vec2(angle.cos(), angle.sin()) * (BOND * 0.72)));
            }
        }
        if planned.is_empty() {
            self.status = "No implicit hydrogens to expand".into();
            return;
        }
        self.checkpoint();
        for (parent, pos) in planned {
            let h = self.add_atom(pos, "H");
            self.add_bond(parent, h, 1);
        }
        for atom in &mut self.mol.atoms[..original_len] {
            if atom.element != "H" {
                atom.explicit_h = 0;
                atom.implicit_h_override = None;
            }
        }
        self.status = "Added explicit hydrogen atoms".into();
    }
    fn remove_explicit_hydrogens(&mut self) {
        let ids: Vec<usize> = self
            .mol
            .atoms
            .iter()
            .enumerate()
            .filter_map(|(i, a)| {
                if a.element != "H" {
                    return None;
                }
                self.mol
                    .bonds
                    .iter()
                    .any(|b| {
                        (b.a == i && self.mol.atoms[b.b].element != "H")
                            || (b.b == i && self.mol.atoms[b.a].element != "H")
                    })
                    .then_some(i)
            })
            .collect();
        if ids.is_empty() {
            self.status = "No attached explicit hydrogens to remove".into();
            return;
        }
        self.checkpoint();
        for i in ids.into_iter().rev() {
            self.remove_atom(i);
        }
        self.status = "Removed explicit hydrogen atoms".into();
    }
    fn transform_document(&mut self, angle: f32, flip_x: bool, flip_y: bool) {
        if self.mol.atoms.is_empty() {
            self.status = "Draw a structure first".into();
            return;
        }
        self.checkpoint();
        let center =
            self.mol.atoms.iter().map(|a| a.pos).sum::<Vec2>() / self.mol.atoms.len() as f32;
        let transform = |p: Vec2| {
            let mut q = p - center;
            if flip_x {
                q.x = -q.x;
            }
            if flip_y {
                q.y = -q.y;
            }
            let (s, c) = angle.sin_cos();
            center + vec2(q.x * c - q.y * s, q.x * s + q.y * c)
        };
        for atom in &mut self.mol.atoms {
            atom.pos = transform(atom.pos);
        }
        for graphic in &mut self.graphics {
            match graphic {
                Graphic::Arrow { start, end, .. } => {
                    *start = transform(*start);
                    *end = transform(*end);
                }
                Graphic::Text { pos, .. } | Graphic::Plus { pos } => *pos = transform(*pos),
                Graphic::Shape { start, end, .. } => {
                    *start = transform(*start);
                    *end = transform(*end);
                }
                Graphic::ElectronArrow {
                    start,
                    control,
                    end,
                    ..
                } => {
                    *start = transform(*start);
                    *control = transform(*control);
                    *end = transform(*end);
                }
            }
        }
        if flip_x ^ flip_y {
            for atom in &mut self.mol.atoms {
                if let Some(s) = &mut atom.stereo {
                    swap_stereo(s);
                }
            }
            for bond in &mut self.mol.bonds {
                if let Some(s) = &mut bond.stereo {
                    swap_stereo(s);
                }
            }
        }
        self.status = if flip_x || flip_y {
            "Mirrored document; stereo labels inverted".into()
        } else {
            "Rotated document in 2D".into()
        };
    }
    fn clean_2d(&mut self) {
        let n = self.mol.atoms.len();
        if n < 2 {
            self.status = "Draw at least two atoms before cleaning".into();
            return;
        }
        if n > 400 {
            self.status = "Clean 2D is limited to 400 atoms for responsiveness".into();
            return;
        }
        self.checkpoint();
        let mut seen = vec![false; n];
        for root in 0..n {
            if seen[root] {
                continue;
            }
            let mut stack = vec![root];
            let mut group = Vec::new();
            seen[root] = true;
            while let Some(i) = stack.pop() {
                group.push(i);
                for b in &self.mol.bonds {
                    let j = if b.a == i {
                        Some(b.b)
                    } else if b.b == i {
                        Some(b.a)
                    } else {
                        None
                    };
                    if let Some(j) = j {
                        if !seen[j] {
                            seen[j] = true;
                            stack.push(j);
                        }
                    }
                }
            }
            if group.len() < 2 {
                continue;
            }
            let map: std::collections::BTreeMap<usize, usize> =
                group.iter().enumerate().map(|(j, &i)| (i, j)).collect();
            let edges: Vec<(usize, usize)> = self
                .mol
                .bonds
                .iter()
                .filter_map(|b| Some((*map.get(&b.a)?, *map.get(&b.b)?)))
                .collect();
            let mut p: Vec<Vec2> = group.iter().map(|&i| self.mol.atoms[i].pos).collect();
            let k = BOND;
            for step in 0..100 {
                let mut d = vec![vec2(0., 0.); p.len()];
                for i in 0..p.len() {
                    for j in i + 1..p.len() {
                        let mut v = p[i] - p[j];
                        let mut len = v.length();
                        if len < 0.01 {
                            v = vec2((i + 1) as f32, (j + 1) as f32);
                            len = v.length();
                        }
                        let f = k * k / len;
                        let force = v / len * f;
                        d[i] += force;
                        d[j] -= force;
                    }
                }
                for &(i, j) in &edges {
                    let v = p[i] - p[j];
                    let len = v.length().max(0.01);
                    let force = v / len * (len * len / k);
                    d[i] -= force;
                    d[j] += force;
                }
                let temp = 8. * (1. - step as f32 / 100.);
                for i in 0..p.len() {
                    let len = d[i].length();
                    if len > 0.001 {
                        p[i] += d[i] / len * len.min(temp);
                    }
                }
            }
            let old =
                group.iter().map(|&i| self.mol.atoms[i].pos).sum::<Vec2>() / group.len() as f32;
            let new = p.iter().copied().sum::<Vec2>() / p.len() as f32;
            for (j, &i) in group.iter().enumerate() {
                self.mol.atoms[i].pos = p[j] + old - new;
            }
        }
        self.status = "Cleaned 2D coordinates using a spring layout".into();
    }
    fn suggest_endpoint(&self, i: usize) -> Vec2 {
        let origin = self.mol.atoms[i].pos;
        let neighbors: Vec<Vec2> = self
            .mol
            .bonds
            .iter()
            .filter_map(|b| {
                if b.a == i {
                    Some(self.mol.atoms[b.b].pos - origin)
                } else if b.b == i {
                    Some(self.mol.atoms[b.a].pos - origin)
                } else {
                    None
                }
            })
            .collect();
        if neighbors.is_empty() {
            return origin + vec2(BOND, 0.);
        }
        let sum = neighbors.iter().copied().sum::<Vec2>();
        let dir = if sum.length() < 0.1 {
            vec2(0., -1.)
        } else {
            -sum.normalize()
        };
        let angle = if neighbors.len() == 1 {
            std::f32::consts::FRAC_PI_3
        } else {
            0.
        };
        let out = vec2(
            dir.x * angle.cos() - dir.y * angle.sin(),
            dir.x * angle.sin() + dir.y * angle.cos(),
        );
        origin + out * BOND
    }
    fn insert_template(&mut self, kind: &str, center: Vec2) {
        self.checkpoint();
        match kind {
            "Benzene" | "Cyclohexane" | "Pyridine" | "Pyrimidine" | "Imidazole" => {
                let first_b = self.mol.bonds.len();
                let first_a = self.mol.atoms.len();
                let size = if kind == "Imidazole" { 5 } else { 6 };
                self.ring(center, size);
                if kind != "Cyclohexane" {
                    for b in self.mol.bonds.iter_mut().skip(first_b) {
                        b.style = BondStyle::Aromatic;
                        b.order = 4;
                    }
                    for a in self.mol.atoms.iter_mut().skip(first_a) {
                        a.aromatic = true;
                    }
                }
                if kind == "Pyridine" && self.mol.atoms.len() > first_a {
                    self.mol.atoms[first_a].element = "N".into();
                }
                if kind == "Pyrimidine" && self.mol.atoms.len() >= first_a + 4 {
                    self.mol.atoms[first_a].element = "N".into();
                    self.mol.atoms[first_a + 3].element = "N".into();
                }
                if kind == "Imidazole" && self.mol.atoms.len() >= first_a + 3 {
                    self.mol.atoms[first_a].element = "N".into();
                    self.mol.atoms[first_a + 2].element = "N".into();
                }
            }
            "Cyclopropane" | "Cyclobutane" | "Cyclopentane" | "Cycloheptane" | "Cyclooctane" => {
                let n = match kind {
                    "Cyclopropane" => 3,
                    "Cyclobutane" => 4,
                    "Cyclopentane" => 5,
                    "Cycloheptane" => 7,
                    _ => 8,
                };
                self.ring(center, n);
            }
            "Ethanol" => {
                let a = self.add_atom(center - vec2(BOND, 0.), "C");
                let b = self.add_atom(center, "C");
                let c = self.add_atom(center + vec2(BOND, 0.), "O");
                self.add_bond(a, b, 1);
                self.add_bond(b, c, 1);
            }
            "Carboxyl" => {
                let a = self.add_atom(center, "C");
                let b = self.add_atom(center + vec2(BOND * 0.8, -BOND * 0.6), "O");
                let c = self.add_atom(center + vec2(BOND * 0.8, BOND * 0.6), "O");
                self.add_bond(a, b, 2);
                self.add_bond(a, c, 1);
            }
            _ => {}
        }
    }
    fn save(&mut self, path: &str) {
        let lower = path.to_lowercase();
        if lower.ends_with(".mol") && (self.mol.atoms.len() > 999 || self.mol.bonds.len() > 999) {
            self.status = "MOL V2000 cannot store more than 999 atoms or bonds".into();
            return;
        }
        let result = if lower.ends_with(".svg") {
            self.write_svg(path, screen_width(), screen_height())
        } else if lower.ends_with(".mols") {
            fs::write(
                path,
                native::write(&Snapshot {
                    mol: self.mol.clone(),
                    graphics: self.graphics.clone(),
                }),
            )
        } else if lower.ends_with(".mol") {
            fs::write(path, self.molfile())
        } else {
            self.status = "Unsupported extension. Use .mols, .mol or .svg".into();
            return;
        };
        self.status = match result {
            Ok(_) => format!("Saved {path}"),
            Err(e) => format!("Save failed: {e}"),
        };
    }
    fn load(&mut self, path: &str) {
        match fs::read_to_string(path) {
            Ok(s) => {
                let parsed = if path.to_lowercase().ends_with(".mols") {
                    native::read(&s)
                } else {
                    parse_mol(&s).map(|mol| Snapshot {
                        mol,
                        graphics: vec![],
                    })
                };
                match parsed {
                    Ok(snapshot) => {
                        self.checkpoint();
                        self.mol = snapshot.mol;
                        self.graphics = snapshot.graphics;
                        self.selected = None;
                        self.selected_atoms.clear();
                        self.selected_bond = None;
                        self.selected_graphic = None;
                        self.status = format!("Opened {path}");
                    }
                    Err(e) => self.status = e,
                }
            }
            Err(e) => self.status = format!("Open failed: {e}"),
        }
    }
    fn export_losses(&self, path: &str) -> Vec<&'static str> {
        if path.to_lowercase().ends_with(".mols") {
            return vec![];
        }
        if path.to_lowercase().ends_with(".svg") {
            return vec!["editable chemical graph and objects"];
        }
        let mut v = Vec::new();
        if !self.graphics.is_empty() {
            v.push("graphics, reaction arrows and text");
        }
        if self.mol.atoms.iter().any(|a| {
            a.alias.is_some()
                || a.query.is_some()
                || a.r_group.is_some()
                || a.stereo.is_some()
                || a.radical > 0
                || a.z.is_some()
                || a.implicit_h_override.is_some()
        }) {
            v.push("advanced atom properties");
        }
        if self
            .mol
            .bonds
            .iter()
            .any(|b| b.style != BondStyle::Normal || b.stereo.is_some() || b.query.is_some())
        {
            v.push("bond styles or query data");
        }
        if self.mol.atoms.iter().any(|a| a.atom_map.is_some()) {
            v.push("atom maps");
        }
        v
    }
    fn request_save(&mut self, path: String) {
        let loss = self.export_losses(&path);
        if loss.is_empty() {
            self.save(&path)
        } else {
            self.pending_export = Some(path);
            self.status = format!("Export will lose: {}", loss.join(", "));
        }
    }
    fn commit_text(&mut self) {
        if let Some(target) = self.text_target.take() {
            self.checkpoint();
            match target {
                TextTarget::New(pos) => self.graphics.push(Graphic::Text {
                    pos,
                    text: self.text_buffer.clone(),
                    size: 20.,
                    bold: false,
                    italic: false,
                }),
                TextTarget::ArrowAbove(i) => {
                    if let Some(Graphic::Arrow { above, .. }) = self.graphics.get_mut(i) {
                        *above = self.text_buffer.clone();
                    }
                }
                TextTarget::ArrowBelow(i) => {
                    if let Some(Graphic::Arrow { below, .. }) = self.graphics.get_mut(i) {
                        *below = self.text_buffer.clone();
                    }
                }
            }
            self.text_buffer.clear();
        }
    }
    fn menu_action(&mut self, cmd: &str) {
        match cmd{
        "New"=>{self.checkpoint();self.mol=Molecule::default();self.graphics.clear();self.selected=None;self.selected_atoms.clear();self.selected_bond=None;self.selected_graphic=None;},
        "Open"=>self.file_dialog=Some(false),"Save"=>self.file_dialog=Some(true),"Undo"=>self.undo(),"Redo"=>self.redo(),
        "Delete selection"=>{if self.selected_atoms.len()>1{self.checkpoint();for i in self.selected_atoms.clone().into_iter().rev(){self.remove_atom(i);}self.selected_atoms.clear();self.selected=None;}else if let Some(i)=self.selected.take(){self.checkpoint();self.remove_atom(i);self.selected_atoms.clear();}else if let Some(i)=self.selected_bond.take(){self.checkpoint();self.mol.bonds.remove(i);}else if let Some(i)=self.selected_graphic.take(){self.checkpoint();self.graphics.remove(i);}},
        "Fit"=>{let n=self.mol.atoms.len();if n>0{self.checkpoint();let center=self.mol.atoms.iter().map(|a|a.pos).sum::<Vec2>()/n as f32;let dest=vec2((screen_width()-RIGHT+LEFT)/2.,(screen_height()-BOTTOM+TOP)/2.);for a in &mut self.mol.atoms{a.pos+=dest-center;}}},
        "Elements"=>self.periodic_open=true,"Templates"=>self.templates_open=true,
        "Arrow"=>{self.tool=Tool::Arrow;self.arrow_kind="reaction".into()},
        "Line"=>self.tool=Tool::Shape(ShapeKind::Line),
        "Rectangle"=>self.tool=Tool::Shape(ShapeKind::Rectangle),
        "Ellipse"=>self.tool=Tool::Shape(ShapeKind::Ellipse),
        "Equilibrium arrow"=>{self.tool=Tool::Arrow;self.arrow_kind="equilibrium".into()},
        "Resonance arrow"=>{self.tool=Tool::Arrow;self.arrow_kind="resonance".into()},
        "Retrosynthesis arrow"=>{self.tool=Tool::Arrow;self.arrow_kind="retrosynthesis".into()},
        "Electron pair arrow"=>self.tool=Tool::Electron(2),
        "Single electron arrow"=>self.tool=Tool::Electron(1),
        "Plus"=>self.tool=Tool::Plus,"Text"=>self.tool=Tool::Text,
        "Charge +"=>self.tool=Tool::Charge(1),"Charge -"=>self.tool=Tool::Charge(-1),
        "Single"=>self.tool=Tool::Bond(1),"Double"=>self.tool=Tool::Bond(2),"Triple"=>self.tool=Tool::Bond(3),
        "Aromatic"=>self.tool=Tool::StyledBond(BondStyle::Aromatic),"Wedge"=>self.tool=Tool::StyledBond(BondStyle::Wedge),"Hash"=>self.tool=Tool::StyledBond(BondStyle::Hash),"Wavy"=>self.tool=Tool::StyledBond(BondStyle::Wavy),
        "Validate"=>{let a=chemistry::analyze(&self.mol);self.info_overlay=Some(if a.warnings.is_empty(){"No basic valence warnings found. Advanced stereochemistry and structure checks require a chemistry engine.".into()}else{a.warnings.join("\n")});},
        "Name structure"=>self.info_overlay=Some(match naming::name(&self.mol){Ok(n)=>format!("Basic systematic name\n{}\n\n{}",n.name,n.explanation),Err(e)=>format!("Name unavailable\n{e}")}),
        "Clean 2D"=>self.clean_2d(),
        "Add explicit hydrogens"=>self.add_explicit_hydrogens(),
        "Remove explicit hydrogens"=>self.remove_explicit_hydrogens(),
        "Rotate 90 CW"=>self.transform_document(std::f32::consts::FRAC_PI_2,false,false),
        "Rotate 90 CCW"=>self.transform_document(-std::f32::consts::FRAC_PI_2,false,false),
        "Rotate 180"=>self.transform_document(std::f32::consts::PI,false,false),
        "Flip left-right"=>self.transform_document(0.,true,false),
        "Flip up-down"=>self.transform_document(0.,false,true),
        "Benzene template"=>{self.tool=Tool::Template("Benzene");self.status="Click canvas to place benzene".into();},
        "Formula & mass"=>{let a=chemistry::analyze(&self.mol);self.info_overlay=Some(format!("Formula: {}\nMolar mass: {} g/mol\nExact mass: {} Da\nMethod: local valence/H count and embedded mass table.\nUnusual valence, query chemistry and unsupported elements may be unresolved.",a.formula,a.molar_mass.map(|x|format!("{x:.3}")).unwrap_or_else(||"unavailable".into()),a.exact_mass.map(|x|format!("{x:.4}")).unwrap_or_else(||"unavailable".into())));},
        "Molecular properties"=>{let a=chemistry::analyze(&self.mol);let comp=a.composition.iter().map(|(el,n)|format!("{el}: {n}")).collect::<Vec<_>>().join(", ");self.info_overlay=Some(format!("Local graph properties\nFormula: {}\nElements: {}\nMolar mass: {} g/mol\nExact mass: {} Da\nAtoms: {} (heavy: {})\nBonds: {}\nFormal charge: {}\nMethod: graph counts and embedded mass table.\nlogP, TPSA, pKa, NMR and 3D require a verified chemistry engine.",a.formula,comp,a.molar_mass.map(|x|format!("{x:.3}")).unwrap_or_else(||"unavailable".into()),a.exact_mass.map(|x|format!("{x:.4}")).unwrap_or_else(||"unavailable".into()),a.atom_count,a.heavy_atom_count,a.bond_count,a.formal_charge));},
        "Reaction analysis"=>self.info_overlay=Some(match reaction::analyze(&self.mol,&self.graphics){Ok(r)=>reaction::report_text(&r),Err(e)=>e}),
        "RDKit descriptors"=>{
            if self.mol.atoms.is_empty(){self.info_overlay=Some("Draw a molecule first".into());}
            else if self.mol.atoms.len()>999||self.mol.bonds.len()>999 {self.info_overlay=Some("RDKit bridge currently accepts MOL V2000 (maximum 999 atoms/bonds)".into());}
            else if self.mol.atoms.iter().any(|a|a.query.is_some()||a.r_group.is_some()||a.alias.is_some()||!chemistry::valid_element(&a.element))||self.mol.bonds.iter().any(|b|b.style!=BondStyle::Normal||b.query.is_some()) {self.info_overlay=Some("This structure contains query, R-group, alias, or special bond data that the RDKit MOL bridge cannot preserve. No descriptor was calculated.".into());}
            else {let block=self.molfile();let captured=self.mol.clone();let (tx,rx)=mpsc::channel();std::thread::spawn(move||{let _=tx.send(rdkit::descriptors(&block));});self.calc_rx=Some((captured,rx));self.info_overlay=Some("Calculating RDKit descriptors…".into());self.status="Calculating with RDKit...".into();}
        },
        "Settings"=>self.settings_open=true,
        "Command palette"=>{self.palette_open=true;self.palette_query.clear();self.palette_selection=0;},
        "Integration status"=>self.info_overlay=Some("RDKit and Open Babel are not installed.\n3D generation, IUPAC names, advanced descriptors, InChI and broad format conversion are unavailable.\nLocal drawing, MOL and MOLS still work.".into()),
        "Shortcuts"=>self.info_overlay=Some("Cmd/Ctrl+N: New | O: Open | S: Save | Z: Undo | Y: Redo\nCmd/Ctrl+Shift+P: Command palette | Delete: delete selection\nEsc: select tool | Shift+R: six-membered ring\nDrawing buffer: 1/2/3 orders, 4 aromatic, 5 wedge, 6 hash, 7 wavy\nC, N, O, Cl... select element; + and - change selected charge\nR1...R32767 assigns R-group; M1... assigns atom map\nCtrl+E opens the periodic table.".into()),
        "Quick start guide"=>self.info_overlay=Some("MOLECULA · QUICK START\n\n01  DRAW\nChoose a bond on the left, then drag or click two points. Choose Chain near the top of the tools to draw a zigzag carbon chain.\n\n02  CHANGE ATOMS\nChoose C, N, O or another element below. Click an atom to replace it. Use the periodic table for all elements.\n\n03  BUILD A REACTION\nPlace reactants left and products right. Insert → Arrow draws a reaction arrow. Use Calculations → Reaction analysis when you want formula, molar mass and balance. Use e⁻ tools for curved electron flow.\n\n04  NAME AND CHECK\nStructure → Name structure gives a name in the supported teaching subset. Molecular properties shows formula and mass.\n\n05  SAVE\nFile → Save writes a .mols document with editable chemistry and graphics.\n\nUNDO Cmd/Ctrl+Z   ·   REDO Cmd/Ctrl+Y   ·   DELETE Delete   ·   CANCEL Esc".into()),
        "Feature status"=>self.info_overlay=Some("See STATUS.md in the source folder for implemented, partial and unavailable functions.".into()),
        _=>{}
    }
    }
    fn apply_quick(&mut self, a: shortcuts::QuickAction) {
        use shortcuts::QuickAction::*;
        match a {
            Bond(n) => {
                self.bond_query = None;
                self.tool = match n {
                    1..=3 => Tool::Bond(n),
                    4 => Tool::StyledBond(BondStyle::Aromatic),
                    5 => Tool::StyledBond(BondStyle::Wedge),
                    6 => Tool::StyledBond(BondStyle::Hash),
                    7 => Tool::StyledBond(BondStyle::Wavy),
                    _ => Tool::StyledBond(BondStyle::Any),
                };
            }
            BondQuery(q) => {
                self.tool = Tool::StyledBond(BondStyle::Any);
                self.bond_query = Some(q.into());
                self.status = format!("Query bond: {q}");
            }
            Element(s) => {
                self.element = s.clone();
                if let Some(i) = self.selected {
                    self.checkpoint();
                    self.mol.atoms[i].element = s;
                } else {
                    self.tool = Tool::Atom;
                }
            }
            Charge(n) => {
                if let Some(i) = self.selected {
                    self.checkpoint();
                    self.mol.atoms[i].charge = (self.mol.atoms[i].charge + n).clamp(-9, 9);
                } else {
                    self.tool = Tool::Charge(n);
                }
            }
            RGroup(n) => {
                if let Some(i) = self.selected {
                    self.checkpoint();
                    self.mol.atoms[i].r_group = Some(n);
                    self.mol.atoms[i].element = "R".into();
                } else {
                    self.status = "Select an atom before assigning an R-group".into();
                }
            }
            AtomMap(n) => {
                if let Some(i) = self.selected {
                    self.checkpoint();
                    self.mol.atoms[i].atom_map = if n == 0 { None } else { Some(n) };
                } else {
                    self.status = "Select an atom before assigning a map number".into();
                }
            }
            Query(q) => {
                if let Some(i) = self.selected {
                    self.checkpoint();
                    self.mol.atoms[i].query = Some(q);
                } else {
                    self.status = "Select an atom before assigning a query".into();
                }
            }
        }
    }
    fn molfile(&self) -> String {
        let mut s = String::from("Molecular Sketch\n  Rust\n\n");
        s += &format!(
            "{:>3}{:>3}  0  0  0  0            999 V2000\n",
            self.mol.atoms.len(),
            self.mol.bonds.len()
        );
        for a in &self.mol.atoms {
            let x = (a.pos.x - LEFT - 100.) / BOND * 1.5;
            let y = -(a.pos.y - TOP - 100.) / BOND * 1.5;
            s += &format!(
                "{:>10.4}{:>10.4}{:>10.4} {:<3} 0  0  0  0  0  0  0  0  0  0  0  0\n",
                x, y, 0., a.element
            );
        }
        for b in &self.mol.bonds {
            s += &format!("{:>3}{:>3}{:>3}  0  0  0  0\n", b.a + 1, b.b + 1, b.order);
        }
        for (i, a) in self.mol.atoms.iter().enumerate() {
            if a.charge != 0 {
                s += &format!("M  CHG  1 {:>3} {:>3}\n", i + 1, a.charge);
            }
            if let Some(isotope) = a.isotope {
                s += &format!("M  ISO  1 {:>3} {:>3}\n", i + 1, isotope);
            }
        }
        s += "M  END\n";
        s
    }
    fn svg_with_size(&self, width: f32, height: f32) -> String {
        let mut s = format!(
            "<svg xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 {} {}\" width=\"{}\" height=\"{}\"><rect width=\"100%\" height=\"100%\" fill=\"white\"/>",
            width as i32, height as i32, width as i32, height as i32
        );
        for b in &self.mol.bonds {
            let a = self.mol.atoms[b.a].pos;
            let c = self.mol.atoms[b.b].pos;
            let d = (c - a).normalize_or_zero();
            let q = vec2(-d.y, d.x);
            if b.style == BondStyle::Wedge {
                s += &format!(
                    "<polygon points=\"{},{} {},{} {},{}\" fill=\"#222\"/>",
                    a.x,
                    a.y,
                    c.x + q.x * 6.,
                    c.y + q.y * 6.,
                    c.x - q.x * 6.,
                    c.y - q.y * 6.
                );
                continue;
            }
            for k in 0..b.order.min(3) {
                let offset = (k as f32 - (b.order as f32 - 1.) / 2.) * 5.;
                let p = a + q * offset;
                let r = c + q * offset;
                s+=&format!("<line x1=\"{}\" y1=\"{}\" x2=\"{}\" y2=\"{}\" stroke=\"#222\" stroke-width=\"2\"/>",p.x,p.y,r.x,r.y);
            }
        }
        for (i, a) in self.mol.atoms.iter().enumerate() {
            if show_label(&self.mol, i) {
                let label = format!(
                    "{}{}{}",
                    a.isotope.map(|n| n.to_string()).unwrap_or_default(),
                    a.alias.as_ref().unwrap_or(&a.element),
                    charge_label(a.charge)
                );
                s+=&format!("<text x=\"{}\" y=\"{}\" font-family=\"Arial\" font-size=\"17\" text-anchor=\"middle\" fill=\"#222\">{}</text>",a.pos.x,a.pos.y+5.,xml_escape(&label));
            }
        }
        for g in &self.graphics {
            match g {
                Graphic::Arrow {
                    start,
                    end,
                    kind,
                    above,
                    below,
                } => {
                    s+=&format!("<line x1=\"{}\" y1=\"{}\" x2=\"{}\" y2=\"{}\" stroke=\"#222\" stroke-width=\"2\"/>",start.x,start.y,end.x,end.y);
                    let d = (*end - *start).normalize_or_zero();
                    let q = vec2(-d.y, d.x);
                    s += &format!(
                        "<polygon points=\"{},{} {},{} {},{}\" fill=\"#222\"/>",
                        end.x,
                        end.y,
                        end.x - d.x * 12. + q.x * 5.,
                        end.y - d.y * 12. + q.y * 5.,
                        end.x - d.x * 12. - q.x * 5.,
                        end.y - d.y * 12. - q.y * 5.
                    );
                    if kind == "equilibrium" {
                        s+=&format!("<line x1=\"{}\" y1=\"{}\" x2=\"{}\" y2=\"{}\" stroke=\"#222\" stroke-width=\"1.5\"/>",start.x+q.x*6.,start.y+q.y*6.,end.x+q.x*6.,end.y+q.y*6.);
                    }
                    if kind == "resonance" {
                        s += &format!(
                            "<polygon points=\"{},{} {},{} {},{}\" fill=\"#222\"/>",
                            start.x,
                            start.y,
                            start.x + d.x * 12. + q.x * 5.,
                            start.y + d.y * 12. + q.y * 5.,
                            start.x + d.x * 12. - q.x * 5.,
                            start.y + d.y * 12. - q.y * 5.
                        );
                    }
                    if kind == "retrosynthesis" {
                        s+=&format!("<line x1=\"{}\" y1=\"{}\" x2=\"{}\" y2=\"{}\" stroke=\"#222\" stroke-width=\"2\"/>",end.x+q.x*7.,end.y+q.y*7.,end.x-q.x*7.,end.y-q.y*7.);
                    }
                    let mid = (*start + *end) / 2.;
                    s += &format!(
                        "<text x=\"{}\" y=\"{}\">{}</text><text x=\"{}\" y=\"{}\">{}</text>",
                        mid.x,
                        mid.y - 12.,
                        xml_escape(above),
                        mid.x,
                        mid.y + 25.,
                        xml_escape(below)
                    );
                }
                Graphic::Text {
                    pos, text, size, ..
                } => {
                    s += &format!(
                        "<text x=\"{}\" y=\"{}\" font-size=\"{}\">{}</text>",
                        pos.x,
                        pos.y,
                        size,
                        xml_escape(text)
                    )
                }
                Graphic::Plus { pos } => {
                    s += &format!(
                        "<text x=\"{}\" y=\"{}\" font-size=\"30\">+</text>",
                        pos.x, pos.y
                    )
                }
                Graphic::Shape { kind, start, end } => {
                    let x = start.x.min(end.x);
                    let y = start.y.min(end.y);
                    let w = (start.x - end.x).abs();
                    let h = (start.y - end.y).abs();
                    match kind {
                        ShapeKind::Line=>s+=&format!("<line x1=\"{}\" y1=\"{}\" x2=\"{}\" y2=\"{}\" stroke=\"#222\" stroke-width=\"2\"/>",start.x,start.y,end.x,end.y),
                        ShapeKind::Rectangle=>s+=&format!("<rect x=\"{x}\" y=\"{y}\" width=\"{w}\" height=\"{h}\" fill=\"none\" stroke=\"#222\" stroke-width=\"2\"/>"),
                        ShapeKind::Ellipse=>s+=&format!("<ellipse cx=\"{}\" cy=\"{}\" rx=\"{}\" ry=\"{}\" fill=\"none\" stroke=\"#222\" stroke-width=\"2\"/>",(start.x+end.x)/2.,(start.y+end.y)/2.,w/2.,h/2.),
                    }
                }
                Graphic::ElectronArrow {
                    start,
                    control,
                    end,
                    electrons,
                } => {
                    s+=&format!("<path d=\"M {} {} Q {} {} {} {}\" fill=\"none\" stroke=\"#222\" stroke-width=\"2\"/>",start.x,start.y,control.x,control.y,end.x,end.y);
                    let d = (*end - *control).normalize_or_zero();
                    let q = vec2(-d.y, d.x);
                    s+=&format!("<line x1=\"{}\" y1=\"{}\" x2=\"{}\" y2=\"{}\" stroke=\"#222\" stroke-width=\"2\"/>",end.x,end.y,end.x-d.x*12.+q.x*5.,end.y-d.y*12.+q.y*5.);
                    if *electrons == 2 {
                        s+=&format!("<line x1=\"{}\" y1=\"{}\" x2=\"{}\" y2=\"{}\" stroke=\"#222\" stroke-width=\"2\"/>",end.x,end.y,end.x-d.x*12.-q.x*5.,end.y-d.y*12.-q.y*5.);
                    }
                }
            }
        }
        s += "</svg>";
        s
    }
    fn write_svg(&self, path: &str, width: f32, height: f32) -> std::io::Result<()> {
        fs::write(path, self.svg_with_size(width, height))
    }
}
fn xml_escape(s: &str) -> String {
    s.replace('&', "&amp;")
        .replace('<', "&lt;")
        .replace('>', "&gt;")
        .replace('"', "&quot;")
        .replace('\'', "&apos;")
}
fn charge_label(c: i8) -> String {
    match c {
        0 => String::new(),
        1 => "+".into(),
        -1 => "-".into(),
        x if x > 0 => format!("{}+", x),
        x => format!("{}-", -x),
    }
}
fn show_label(m: &Molecule, i: usize) -> bool {
    let a = &m.atoms[i];
    a.element != "C"
        || a.charge != 0
        || m.bonds.iter().filter(|b| b.a == i || b.b == i).count() == 0
}
fn distance_segment(p: Vec2, a: Vec2, b: Vec2) -> f32 {
    let d = b - a;
    let t = ((p - a).dot(d) / d.length_squared().max(0.001)).clamp(0., 1.);
    p.distance(a + d * t)
}
fn parse_mol(s: &str) -> Result<Molecule, String> {
    parse_mol_at(
        s,
        vec2(screen_width() / 2., (TOP + screen_height() - BOTTOM) / 2.),
    )
}
fn parse_mol_at(s: &str, center: Vec2) -> Result<Molecule, String> {
    let lines: Vec<&str> = s.lines().collect();
    let ci = lines
        .iter()
        .position(|l| l.contains("V2000"))
        .ok_or("Only MOL V2000 files are supported")?;
    let count = lines[ci];
    let fields: Vec<&str> = count.split_whitespace().collect();
    if fields.len() < 2 {
        return Err("Invalid MOL counts line".into());
    }
    let na = fields[0]
        .parse::<usize>()
        .map_err(|_| "Invalid atom count")?;
    let nb = fields[1]
        .parse::<usize>()
        .map_err(|_| "Invalid bond count")?;
    if na > 999 || nb > 999 || lines.len() < ci + 1 + na + nb {
        return Err("MOL file is incomplete or too large".into());
    }
    if !lines
        .iter()
        .skip(ci + 1 + na + nb)
        .any(|l| l.trim() == "M  END")
    {
        return Err("MOL file is missing M  END".into());
    }
    let mut m = Molecule::default();
    let mut coords = Vec::new();
    for i in 0..na {
        let f: Vec<&str> = lines[ci + 1 + i].split_whitespace().collect();
        if f.len() < 4 {
            return Err("Invalid atom line".into());
        }
        let x = f[0].parse::<f32>().map_err(|_| "Invalid coordinate")?;
        let y = f[1].parse::<f32>().map_err(|_| "Invalid coordinate")?;
        if !x.is_finite() || !y.is_finite() {
            return Err("MOL coordinates must be finite numbers".into());
        }
        coords.push(vec2(x, y));
        m.atoms.push(Atom::new(vec2(0., 0.), f[3]));
    }
    let mid = if coords.is_empty() {
        vec2(0., 0.)
    } else {
        coords.iter().copied().sum::<Vec2>() / na as f32
    };
    for (a, p) in m.atoms.iter_mut().zip(coords) {
        a.pos = center + vec2(p.x - mid.x, -p.y + mid.y) * (BOND / 1.5);
    }
    for i in 0..nb {
        let f: Vec<&str> = lines[ci + 1 + na + i].split_whitespace().collect();
        if f.len() < 3 {
            return Err("Invalid bond line".into());
        }
        let a = f[0].parse::<usize>().map_err(|_| "Invalid bond")?;
        let b = f[1].parse::<usize>().map_err(|_| "Invalid bond")?;
        let order = f[2].parse::<u8>().map_err(|_| "Invalid bond order")?;
        if a == 0 || b == 0 || a > na || b > na || a == b {
            return Err("Bond references missing atom".into());
        }
        if !(1..=4).contains(&order) {
            return Err("Unsupported MOL bond order".into());
        }
        m.bonds.push(Bond {
            a: a - 1,
            b: b - 1,
            order,
            style: if order == 4 {
                BondStyle::Aromatic
            } else {
                BondStyle::Normal
            },
            stereo: None,
            query: None,
        });
    }
    for l in lines.iter().skip(ci + 1 + na + nb) {
        let f: Vec<&str> = l.split_whitespace().collect();
        if f.len() >= 5 && f[0] == "M" && f[1] == "CHG" {
            if let (Ok(i), Ok(c)) = (f[3].parse::<usize>(), f[4].parse::<i8>()) {
                if i > 0 && i <= na {
                    m.atoms[i - 1].charge = c;
                }
            }
        }
        if f.len() >= 5 && f[0] == "M" && f[1] == "ISO" {
            if let (Ok(i), Ok(n)) = (f[3].parse::<usize>(), f[4].parse::<u16>()) {
                if i > 0 && i <= na {
                    m.atoms[i - 1].isotope = Some(n);
                }
            }
        }
    }
    Ok(m)
}

fn button(x: f32, y: f32, w: f32, h: f32, label: &str, active: bool) -> bool {
    let label = UI_LANGUAGE.with(|language| localized(language.get(), label));
    let p = vec2(mouse_position().0, mouse_position().1);
    let hover = p.x >= x && p.x < x + w && p.y >= y && p.y < y + h;
    let top = y < 40.;
    let toolbar = (40. ..TOP).contains(&y);
    let palette = y >= screen_height() - BOTTOM && y < screen_height() - BOTTOM + 52.;
    let fill = if top {
        if active {
            Color::from_rgba(45, 102, 76, 255)
        } else if hover {
            Color::from_rgba(32, 74, 56, 255)
        } else {
            navy()
        }
    } else if active {
        if palette {
            accent()
        } else {
            Color::from_rgba(229, 237, 255, 255)
        }
    } else if hover {
        Color::from_rgba(235, 240, 250, 255)
    } else if toolbar {
        Color::from_rgba(255, 255, 255, 18)
    } else {
        WHITE
    };
    round_rect(x, y, w, h, 8., fill);
    if !top && !toolbar && !active && !hover {
        round_border(x, y, w, h, 8., Color::from_rgba(220, 228, 239, 255));
    }
    let mut size = if top {
        14.
    } else if toolbar {
        15.
    } else {
        16.
    };
    while size > 11. && measure_text(label.as_ref(), None, size as u16, 1.).width > w - 8. {
        size -= 1.;
    }
    let d = measure_text(label.as_ref(), None, size as u16, 1.);
    draw_text(
        label.as_ref(),
        x + (w - d.width) / 2.,
        y + (h + d.height) / 2. - 3.,
        size,
        if top || palette && active {
            WHITE
        } else if active {
            accent()
        } else {
            ink()
        },
    );
    hover && is_mouse_button_pressed(MouseButton::Left) && UI_INPUT_ENABLED.with(Cell::get)
}
fn draw_bond(a: Vec2, b: Vec2, order: u8, color: Color) {
    let d = (b - a).normalize_or_zero();
    let q = vec2(-d.y, d.x);
    for k in 0..order {
        let o = (k as f32 - (order as f32 - 1.) / 2.) * 5.;
        let start = a + q * o;
        let end = b + q * o;
        draw_line(start.x, start.y, end.x, end.y, 2., color);
    }
}
fn draw_chem_bond(a: Vec2, b: Vec2, bond: &Bond, color: Color) {
    let d = (b - a).normalize_or_zero();
    let q = vec2(-d.y, d.x);
    match bond.style {
        BondStyle::Normal => draw_bond(a, b, bond.order.min(3), color),
        BondStyle::Aromatic => {
            draw_bond(a, b, 1, color);
            for k in 0..6 {
                let t = k as f32 / 6.;
                let u = (t + 0.08).min(1.);
                let p = a.lerp(b, t) + q * 5.;
                let r = a.lerp(b, u) + q * 5.;
                draw_line(p.x, p.y, r.x, r.y, 1.5, color);
            }
        }
        BondStyle::Wedge => draw_triangle(a, b + q * 6., b - q * 6., color),
        BondStyle::Hash => {
            for k in 0..11 {
                let t = k as f32 / 11.;
                let p = a.lerp(b, t);
                let width = 1. + t * 6.;
                draw_line(
                    p.x - q.x * width,
                    p.y - q.y * width,
                    p.x + q.x * width,
                    p.y + q.y * width,
                    1.5,
                    color,
                );
            }
        }
        BondStyle::Wavy => {
            let mut prev = a;
            for k in 1..=24 {
                let t = k as f32 / 24.;
                let p = a.lerp(b, t) + q * (t * std::f32::consts::TAU * 4.).sin() * 3.;
                draw_line(prev.x, prev.y, p.x, p.y, 1.7, color);
                prev = p;
            }
        }
        BondStyle::Coordinate => {
            draw_line(a.x, a.y, b.x, b.y, 1.7, color);
            draw_triangle(b, b - d * 10. + q * 4., b - d * 10. - q * 4., color);
        }
        BondStyle::Any => {
            for k in 0..8 {
                let p = a.lerp(b, k as f32 / 8.);
                let r = a.lerp(b, (k as f32 + 0.55) / 8.);
                draw_line(p.x, p.y, r.x, r.y, 2., color);
            }
        }
    }
}
fn canvas(p: Vec2) -> bool {
    p.x > LEFT && p.x < screen_width() - RIGHT && p.y > TOP && p.y < screen_height() - BOTTOM
}
fn electron_control(start: Vec2, end: Vec2) -> Vec2 {
    let d = end - start;
    (start + end) / 2. + vec2(d.y, -d.x) * 0.34
}
fn draw_electron_arrow(start: Vec2, control: Vec2, end: Vec2, electrons: u8, color: Color) {
    let mut prev = start;
    for k in 1..=32 {
        let t = k as f32 / 32.;
        let p = start * (1. - t).powi(2) + control * (2. * t * (1. - t)) + end * t * t;
        draw_line(prev.x, prev.y, p.x, p.y, 2., color);
        prev = p;
    }
    let d = (end - control).normalize_or_zero();
    let q = vec2(-d.y, d.x);
    draw_line(
        end.x,
        end.y,
        end.x - d.x * 12. + q.x * 5.,
        end.y - d.y * 12. + q.y * 5.,
        2.,
        color,
    );
    if electrons == 2 {
        draw_line(
            end.x,
            end.y,
            end.x - d.x * 12. - q.x * 5.,
            end.y - d.y * 12. - q.y * 5.,
            2.,
            color,
        );
    }
}
fn draw_reaction_arrow(start: Vec2, end: Vec2, kind: &str, color: Color) {
    let d = (end - start).normalize_or_zero();
    let q = vec2(-d.y, d.x);
    if kind == "equilibrium" {
        let a = start - q * 4.;
        let b = end - q * 4.;
        draw_line(a.x, a.y, b.x, b.y, 2., color);
        draw_line(
            b.x,
            b.y,
            b.x - d.x * 10. - q.x * 5.,
            b.y - d.y * 10. - q.y * 5.,
            2.,
            color,
        );
        let a = end + q * 4.;
        let b = start + q * 4.;
        draw_line(a.x, a.y, b.x, b.y, 2., color);
        draw_line(
            b.x,
            b.y,
            b.x + d.x * 10. + q.x * 5.,
            b.y + d.y * 10. + q.y * 5.,
            2.,
            color,
        );
    } else {
        draw_line(start.x, start.y, end.x, end.y, 2., color);
        let head = |at: Vec2, dir: Vec2| {
            draw_line(
                at.x,
                at.y,
                at.x - dir.x * 12. + q.x * 6.,
                at.y - dir.y * 12. + q.y * 6.,
                2.,
                color,
            );
            draw_line(
                at.x,
                at.y,
                at.x - dir.x * 12. - q.x * 6.,
                at.y - dir.y * 12. - q.y * 6.,
                2.,
                color,
            );
        };
        head(end, d);
        if kind == "resonance" {
            head(start, -d);
        }
        if kind == "retrosynthesis" {
            draw_line(
                end.x - q.x * 8.,
                end.y - q.y * 8.,
                end.x + q.x * 8.,
                end.y + q.y * 8.,
                2.,
                color,
            );
        }
    }
}
fn periodic_cell(z: usize) -> (usize, usize) {
    let n = z + 1;
    match n {
        1 => (0, 0),
        2 => (17, 0),
        3..=10 => {
            let j = n - 3;
            (if j < 2 { j } else { j + 10 }, 1)
        }
        11..=18 => {
            let j = n - 11;
            (if j < 2 { j } else { j + 10 }, 2)
        }
        19..=36 => (n - 19, 3),
        37..=54 => (n - 37, 4),
        55..=56 => (n - 55, 5),
        57..=71 => (n - 57 + 2, 7),
        72..=86 => (n - 72 + 3, 5),
        87..=88 => (n - 87, 6),
        89..=103 => (n - 89 + 2, 8),
        104..=118 => (n - 104 + 3, 6),
        _ => (0, 0),
    }
}
const MENU_NAMES: [&str; 10] = [
    "File",
    "Edit",
    "View",
    "Insert",
    "Atom",
    "Bond",
    "Structure",
    "Calculations",
    "Services",
    "Help",
];
fn menu_items(i: usize) -> &'static [&'static str] {
    match i {
        0 => &["New", "Open", "Save"],
        1 => &["Undo", "Redo", "Delete selection", "Settings"],
        2 => &["Fit", "Elements"],
        3 => &[
            "Templates",
            "Arrow",
            "Equilibrium arrow",
            "Resonance arrow",
            "Retrosynthesis arrow",
            "Electron pair arrow",
            "Single electron arrow",
            "Plus",
            "Text",
            "Line",
            "Rectangle",
            "Ellipse",
        ],
        4 => &["Elements", "Charge +", "Charge -"],
        5 => &[
            "Single", "Double", "Triple", "Aromatic", "Wedge", "Hash", "Wavy",
        ],
        6 => &[
            "Validate",
            "Name structure",
            "Clean 2D",
            "Add explicit hydrogens",
            "Remove explicit hydrogens",
            "Rotate 90 CW",
            "Rotate 90 CCW",
            "Rotate 180",
            "Flip left-right",
            "Flip up-down",
            "Benzene template",
        ],
        7 => &[
            "Formula & mass",
            "Molecular properties",
            "Reaction analysis",
            "RDKit descriptors",
        ],
        8 => &["Integration status"],
        9 => &[
            "Quick start guide",
            "Shortcuts",
            "Feature status",
            "Command palette",
        ],
        _ => &[],
    }
}
fn all_commands() -> Vec<&'static str> {
    let mut commands = Vec::new();
    for menu in 0..MENU_NAMES.len() {
        for command in menu_items(menu) {
            if !commands.contains(command) {
                commands.push(*command);
            }
        }
    }
    commands
}

#[macroquad::main(window_conf)]
async fn main() {
    if let Ok(font) = load_ttf_font_from_bytes(include_bytes!("../assets/DejaVuSans.ttf")) {
        UI_FONT.with(|f| *f.borrow_mut() = Some(font));
    }
    let mut e = Editor::new();
    #[cfg(target_os = "windows")]
    record_startup_note("Editor initialized; ready.");
    UI_LANGUAGE.with(|language| language.set(e.language));
    loop {
        UI_LANGUAGE.with(|language| language.set(e.language));
        UI_INPUT_ENABLED.with(|enabled| enabled.set(!e.settings_open));
        if let Some((current, result)) = e.calc_rx.as_ref().and_then(|(captured, rx)| {
            rx.try_recv()
                .ok()
                .map(|result| (captured == &e.mol, result))
        }) {
            e.calc_rx = None;
            if current {
                e.info_overlay=Some(match result {Ok(report)=>report,Err(message)=>format!("RDKit unavailable: {message}\nInstall RDKit in a Python environment and set MOLECULA_PYTHON to its interpreter.")});
                e.status = "Calculation finished".into();
            } else {
                e.status = "Discarded calculation for an earlier molecule".into();
            }
        }
        let w = screen_width();
        let h = screen_height();
        let p = vec2(mouse_position().0, mouse_position().1);
        clear_background(surface());
        draw_rectangle(0., 0., w, 39., navy());
        draw_rectangle(0., 39., w, TOP - 39., WHITE);
        draw_line(0., TOP, w, TOP, 1., Color::from_rgba(218, 226, 238, 255));
        draw_line(
            16.,
            22.,
            27.,
            13.,
            2.5,
            Color::from_rgba(128, 219, 169, 255),
        );
        draw_line(
            27.,
            13.,
            38.,
            22.,
            2.5,
            Color::from_rgba(128, 219, 169, 255),
        );
        draw_line(
            38.,
            22.,
            27.,
            29.,
            2.5,
            Color::from_rgba(128, 219, 169, 255),
        );
        for (cx, cy) in [(16., 22.), (27., 13.), (38., 22.), (27., 29.)] {
            draw_circle(cx, cy, 3.5, WHITE);
        }
        draw_text("molecula", 52., 27., 21., WHITE);
        draw_text(
            "STRUCTURE STUDIO",
            165.,
            25.,
            10.,
            Color::from_rgba(150, 168, 194, 255),
        );
        for (i, name) in MENU_NAMES.iter().enumerate() {
            if button(
                304. + i as f32 * 94.,
                3.,
                90.,
                32.,
                name,
                e.menu_open == Some(i),
            ) {
                e.menu_open = if e.menu_open == Some(i) {
                    None
                } else {
                    Some(i)
                };
            }
        }
        let menu = [
            ("New", 0),
            ("Open", 1),
            ("Save", 2),
            ("Undo", 3),
            ("Redo", 4),
            ("Fit", 5),
            ("Elements", 6),
            ("Templates", 7),
        ];
        round_rect(
            14.,
            45.,
            610.,
            34.,
            10.,
            Color::from_rgba(246, 248, 252, 255),
        );
        let mut mx = 17.;
        for (label, id) in menu {
            if button(mx, 44., 70., 31., label, false) {
                match id {
                    0 => {
                        e.checkpoint();
                        e.mol = Molecule::default();
                        e.graphics.clear();
                        e.status = "New document".into();
                    }
                    1 => e.file_dialog = Some(false),
                    2 => e.file_dialog = Some(true),
                    3 => e.undo(),
                    4 => e.redo(),
                    5 => {
                        let n = e.mol.atoms.len();
                        if n > 0 {
                            let center =
                                e.mol.atoms.iter().fold(vec2(0., 0.), |acc, a| acc + a.pos)
                                    / n as f32;
                            let dest = vec2((w + LEFT) / 2., (h + TOP - BOTTOM) / 2.);
                            for a in &mut e.mol.atoms {
                                a.pos += dest - center;
                            }
                        }
                    }
                    6 => e.periodic_open = true,
                    7 => e.templates_open = true,
                    _ => {}
                }
            }
            mx += 76.;
        }
        draw_rectangle(0., TOP, LEFT, h - TOP - BOTTOM, navy());
        draw_text(
            "TOOLS",
            17.,
            TOP + 20.,
            10.,
            Color::from_rgba(132, 152, 183, 255),
        );
        let tools = [
            ("Sel", Tool::Select),
            ("Del", Tool::Erase),
            ("Chain", Tool::Chain),
            ("1", Tool::Bond(1)),
            ("=", Tool::Bond(2)),
            ("3", Tool::Bond(3)),
            ("Ar", Tool::StyledBond(BondStyle::Aromatic)),
            ("C", Tool::Atom),
            ("R6", Tool::Ring(6)),
            ("R5", Tool::Ring(5)),
            ("->", Tool::Arrow),
            ("e2", Tool::Electron(2)),
            ("e1", Tool::Electron(1)),
            ("+R", Tool::Plus),
            ("Txt", Tool::Text),
            ("+", Tool::Charge(1)),
            ("-", Tool::Charge(-1)),
            ("Wd", Tool::StyledBond(BondStyle::Wedge)),
            ("Hs", Tool::StyledBond(BondStyle::Hash)),
            ("Wv", Tool::StyledBond(BondStyle::Wavy)),
        ];
        for (i, (label, t)) in tools.iter().enumerate() {
            let y = TOP + 30. + i as f32 * 35.;
            if tool_button(18., y, 52., 33., *t, e.tool == *t) {
                e.pending_arrow = None;
                e.tool = *t;
                e.status = format!("Tool: {label}");
            }
        }
        let grid = Color::from_rgba(224, 231, 242, 255);
        let mut x = LEFT + 26.;
        while x < w - RIGHT {
            let mut y = TOP + 25.;
            while y < h - BOTTOM {
                draw_circle(x, y, 1., grid);
                y += 28.;
            }
            x += 28.;
        }
        if e.mol.atoms.is_empty() && e.graphics.is_empty() {
            let cx = (LEFT + w - RIGHT) / 2.;
            let cy = (TOP + h - BOTTOM) / 2.;
            round_rect(
                cx - 47.,
                cy - 115.,
                94.,
                94.,
                24.,
                Color::from_rgba(231, 238, 252, 255),
            );
            let ghost = Color::from_rgba(113, 148, 220, 255);
            for k in 0..6 {
                let a = std::f32::consts::TAU * k as f32 / 6.;
                let b = std::f32::consts::TAU * (k + 1) as f32 / 6.;
                draw_line(
                    cx + 26. * a.cos(),
                    cy - 68. + 26. * a.sin(),
                    cx + 26. * b.cos(),
                    cy - 68. + 26. * b.sin(),
                    2.,
                    ghost,
                );
            }
            draw_text("Start drawing chemistry", cx - 148., cy + 22., 25., ink());
            draw_text(
                "Choose a tool or drag on the canvas",
                cx - 154.,
                cy + 53.,
                16.,
                muted(),
            );
            round_rect(
                cx - 105.,
                cy + 74.,
                210.,
                30.,
                15.,
                Color::from_rgba(235, 241, 252, 255),
            );
            draw_text(
                "1  single bond    •    C  carbon",
                cx - 91.,
                cy + 95.,
                13.,
                accent(),
            );
        }
        for (i, b) in e.mol.bonds.iter().enumerate() {
            let a = e.mol.atoms[b.a].pos;
            let c = e.mol.atoms[b.b].pos;
            draw_chem_bond(
                a,
                c,
                b,
                if e.selected_bond == Some(i) {
                    accent()
                } else if e.tool == Tool::Erase && e.hit_bond(p) == Some(i) {
                    RED
                } else {
                    DARKGRAY
                },
            );
        }
        for (gi, g) in e.graphics.iter().enumerate() {
            match g {
                Graphic::Arrow {
                    start,
                    end,
                    kind,
                    above,
                    below,
                } => {
                    draw_reaction_arrow(*start, *end, kind, DARKGRAY);
                    let mid = (*start + *end) / 2.;
                    draw_text(above, mid.x, mid.y - 12., 18., DARKGRAY);
                    draw_text(below, mid.x, mid.y + 25., 18., DARKGRAY);
                }
                Graphic::ElectronArrow {
                    start,
                    control,
                    end,
                    electrons,
                } => draw_electron_arrow(*start, *control, *end, *electrons, DARKGRAY),
                Graphic::Text {
                    pos, text, size, ..
                } => {
                    draw_text(text, pos.x, pos.y, *size, DARKGRAY);
                }
                Graphic::Plus { pos } => {
                    draw_text("+", pos.x, pos.y, 30., DARKGRAY);
                }
                Graphic::Shape { kind, start, end } => draw_shape(*kind, *start, *end, DARKGRAY),
            }
            if e.selected_graphic == Some(gi) {
                let center = match g {
                    Graphic::Arrow { start, end, .. } => (*start + *end) / 2.,
                    Graphic::ElectronArrow { control, .. } => *control,
                    Graphic::Text { pos, .. } | Graphic::Plus { pos } => *pos,
                    Graphic::Shape { start, end, .. } => (*start + *end) / 2.,
                };
                draw_circle_lines(center.x, center.y, 16., 1.5, accent());
            }
        }
        for (i, a) in e.mol.atoms.iter().enumerate() {
            if e.selected_atoms.contains(&i) {
                draw_circle(a.pos.x, a.pos.y, 17., Color::from_rgba(196, 223, 253, 255));
            }
            if show_label(&e.mol, i) {
                let label = format!(
                    "{}{}{}",
                    a.isotope.map(|n| n.to_string()).unwrap_or_default(),
                    a.alias.as_ref().unwrap_or(&a.element),
                    charge_label(a.charge)
                );
                let d = measure_text(&label, None, 21, 1.);
                draw_rectangle(
                    a.pos.x - d.width / 2. - 3.,
                    a.pos.y - 16.,
                    d.width + 6.,
                    24.,
                    Color::from_rgba(248, 249, 251, 255),
                );
                draw_text(
                    &label,
                    a.pos.x - d.width / 2.,
                    a.pos.y + 5.,
                    21.,
                    if a.element == "O" {
                        RED
                    } else if a.element == "N" {
                        accent()
                    } else {
                        DARKGRAY
                    },
                );
            } else if e.tool == Tool::Select && e.hit_atom(p) == Some(i) {
                draw_circle_lines(a.pos.x, a.pos.y, 7., 1., accent());
            }
            if let Some(n) = a.atom_map {
                draw_text(&format!("{n}"), a.pos.x + 10., a.pos.y + 17., 13., GRAY);
            }
        }
        if let Some(start) = e.selection_box {
            let left = start.x.min(p.x);
            let top = start.y.min(p.y);
            let width = (start.x - p.x).abs();
            let height = (start.y - p.y).abs();
            draw_rectangle(left, top, width, height, Color::from_rgba(36, 139, 94, 28));
            draw_rectangle_lines(left, top, width, height, 1.5, accent());
        }
        if let Some(start) = e.drag_start.or(e.pending_arrow) {
            if matches!(e.tool, Tool::Bond(_) | Tool::StyledBond(_)) && canvas(p) {
                let origin = e
                    .hit_atom(start)
                    .map(|i| e.mol.atoms[i].pos)
                    .unwrap_or(start);
                let end = if p.distance(origin) < 14. {
                    e.hit_atom(start)
                        .map(|i| e.suggest_endpoint(i))
                        .unwrap_or(origin + vec2(BOND, 0.))
                } else {
                    p
                };
                let preview = Bond {
                    a: 0,
                    b: 1,
                    order: match e.tool {
                        Tool::Bond(o) => o,
                        _ => 1,
                    },
                    style: match e.tool {
                        Tool::StyledBond(s) => s,
                        _ => BondStyle::Normal,
                    },
                    stereo: None,
                    query: None,
                };
                draw_chem_bond(origin, end, &preview, accent());
                draw_circle_lines(end.x, end.y, 6., 1., accent());
            } else if e.tool == Tool::Chain && canvas(p) {
                let origin = e
                    .hit_atom(start)
                    .map(|i| e.mol.atoms[i].pos)
                    .unwrap_or(start);
                let delta = p - origin;
                let length = delta.length();
                let dir = if length > 1. {
                    delta / length
                } else {
                    vec2(1., 0.)
                };
                let count = if length < 18. {
                    3
                } else {
                    ((length / BOND).round() as usize).clamp(2, 10)
                };
                let end = if length < 18. {
                    origin + dir * BOND * count as f32
                } else {
                    p
                };
                let normal = vec2(-dir.y, dir.x);
                let mut prev = origin;
                for k in 1..=count {
                    let t = k as f32 / count as f32;
                    let zig = if k == count {
                        0.
                    } else if k % 2 == 1 {
                        -1.
                    } else {
                        1.
                    };
                    let next = origin + (end - origin) * t + normal * zig * (BOND * 0.22);
                    draw_line(prev.x, prev.y, next.x, next.y, 2., accent());
                    prev = next;
                }
            } else if e.tool == Tool::Arrow && canvas(p) {
                draw_reaction_arrow(start, p, &e.arrow_kind, accent());
            } else if let Tool::Shape(kind) = e.tool {
                if canvas(p) {
                    draw_shape(kind, start, p, accent());
                }
            } else if let Tool::Electron(n) = e.tool {
                if canvas(p) {
                    draw_electron_arrow(start, electron_control(start, p), p, n, accent());
                }
            }
        }
        let panel_x = w - RIGHT;
        draw_rectangle(
            panel_x,
            TOP,
            RIGHT,
            h - TOP - BOTTOM,
            Color::from_rgba(244, 247, 252, 255),
        );
        draw_line(
            panel_x,
            TOP,
            panel_x,
            h - BOTTOM,
            1.,
            Color::from_rgba(218, 226, 238, 255),
        );
        draw_text("INSPECTOR", panel_x + 16., TOP + 23., 11., muted());
        round_rect(panel_x + 11., TOP + 38., 228., 255., 12., WHITE);
        draw_text("Properties", panel_x + 130., TOP + 24., 16., ink());
        if e.selected_atoms.len() > 1 {
            let mut elements = std::collections::BTreeMap::<String, usize>::new();
            let mut charge = 0i32;
            for &i in &e.selected_atoms {
                if let Some(atom) = e.mol.atoms.get(i) {
                    *elements.entry(atom.element.clone()).or_default() += 1;
                    charge += atom.charge as i32;
                }
            }
            let element_summary = elements
                .iter()
                .map(|(element, count)| format!("{element} × {count}"))
                .collect::<Vec<_>>()
                .join(", ");
            let internal_bonds = e
                .mol
                .bonds
                .iter()
                .filter(|b| e.selected_atoms.contains(&b.a) && e.selected_atoms.contains(&b.b))
                .count();
            draw_text("Canvas selection", panel_x + 16., TOP + 61., 18., DARKGRAY);
            draw_text(
                &format!("{} atoms", e.selected_atoms.len()),
                panel_x + 16.,
                TOP + 94.,
                16.,
                DARKGRAY,
            );
            draw_text(
                &element_summary.chars().take(28).collect::<String>(),
                panel_x + 16.,
                TOP + 124.,
                14.,
                DARKGRAY,
            );
            draw_text(
                &format!("Internal bonds: {internal_bonds}"),
                panel_x + 16.,
                TOP + 154.,
                15.,
                DARKGRAY,
            );
            draw_text(
                &format!("Formal charge: {charge:+}"),
                panel_x + 16.,
                TOP + 184.,
                15.,
                DARKGRAY,
            );
            draw_text(
                "Drag a box on the canvas to select",
                panel_x + 16.,
                TOP + 222.,
                12.,
                muted(),
            );
        } else if let Some(i) = e.selected.filter(|i| *i < e.mol.atoms.len()) {
            let atom = &e.mol.atoms[i];
            draw_text(
                &format!("Atom {}: {}", i + 1, atom.element),
                panel_x + 16.,
                TOP + 61.,
                18.,
                DARKGRAY,
            );
            draw_text(
                &format!("Charge: {}", atom.charge),
                panel_x + 16.,
                TOP + 91.,
                17.,
                DARKGRAY,
            );
            draw_text(
                &format!(
                    "Isotope: {}",
                    atom.isotope
                        .map(|n| n.to_string())
                        .unwrap_or_else(|| "natural".into())
                ),
                panel_x + 16.,
                TOP + 121.,
                17.,
                DARKGRAY,
            );
            draw_text(
                &format!(
                    "Map: {}",
                    atom.atom_map
                        .map(|n| n.to_string())
                        .unwrap_or_else(|| "none".into())
                ),
                panel_x + 16.,
                TOP + 151.,
                17.,
                DARKGRAY,
            );
            if let Some(q) = &atom.query {
                draw_text(
                    &format!("Query: {q}"),
                    panel_x + 16.,
                    TOP + 181.,
                    16.,
                    DARKGRAY,
                );
            }
            if button(panel_x + 16., TOP + 203., 100., 33., "Charge +", false) {
                e.checkpoint();
                e.mol.atoms[i].charge += 1;
            }
            if button(panel_x + 126., TOP + 203., 100., 33., "Charge -", false) {
                e.checkpoint();
                e.mol.atoms[i].charge -= 1;
            }
            if button(panel_x + 16., TOP + 246., 100., 33., "13C", false) {
                e.checkpoint();
                e.mol.atoms[i].element = "C".into();
                e.mol.atoms[i].isotope = Some(13);
            }
            if button(panel_x + 126., TOP + 246., 100., 33., "Clear iso", false) {
                e.checkpoint();
                e.mol.atoms[i].isotope = None;
            }
        } else if let Some(i) = e.selected_bond.filter(|i| *i < e.mol.bonds.len()) {
            let bond = &e.mol.bonds[i];
            let a = &e.mol.atoms[bond.a];
            let b = &e.mol.atoms[bond.b];
            draw_text("Selected bond", panel_x + 16., TOP + 61., 18., DARKGRAY);
            draw_text(
                &format!("{} — {}", a.element, b.element),
                panel_x + 16.,
                TOP + 96.,
                16.,
                DARKGRAY,
            );
            draw_text(
                &format!("Bond order: {}", bond.order),
                panel_x + 16.,
                TOP + 128.,
                16.,
                DARKGRAY,
            );
            draw_text(
                &format!("Style: {:?}", bond.style),
                panel_x + 16.,
                TOP + 160.,
                15.,
                DARKGRAY,
            );
            draw_text(
                &format!(
                    "Stereo: {}",
                    bond.stereo.as_deref().unwrap_or("unspecified")
                ),
                panel_x + 16.,
                TOP + 192.,
                14.,
                DARKGRAY,
            );
            if button(panel_x + 16., TOP + 218., 210., 33., "Delete bond", false) {
                e.checkpoint();
                e.mol.bonds.remove(i);
                e.selected_bond = None;
            }
        } else if let Some(gi) = e.selected_graphic.filter(|i| *i < e.graphics.len()) {
            let is_arrow = matches!(e.graphics[gi], Graphic::Arrow { .. });
            let is_electron = matches!(e.graphics[gi], Graphic::ElectronArrow { .. });
            draw_text(
                if is_arrow {
                    "Reaction arrow"
                } else if is_electron {
                    "Electron-flow arrow"
                } else {
                    "Graphic object"
                },
                panel_x + 16.,
                TOP + 61.,
                18.,
                DARKGRAY,
            );
            if is_arrow {
                if button(
                    panel_x + 16.,
                    TOP + 95.,
                    210.,
                    35.,
                    "Edit text above",
                    false,
                ) {
                    if let Graphic::Arrow { above, .. } = &e.graphics[gi] {
                        e.text_buffer = above.clone();
                    }
                    e.text_target = Some(TextTarget::ArrowAbove(gi));
                }
                if button(
                    panel_x + 16.,
                    TOP + 140.,
                    210.,
                    35.,
                    "Edit text below",
                    false,
                ) {
                    if let Graphic::Arrow { below, .. } = &e.graphics[gi] {
                        e.text_buffer = below.clone();
                    }
                    e.text_target = Some(TextTarget::ArrowBelow(gi));
                }
                if button(
                    panel_x + 16.,
                    TOP + 185.,
                    210.,
                    35.,
                    "Change arrow type",
                    false,
                ) {
                    e.checkpoint();
                    if let Graphic::Arrow { kind, .. } = &mut e.graphics[gi] {
                        *kind = match kind.as_str() {
                            "reaction" => "equilibrium",
                            "equilibrium" => "resonance",
                            "resonance" => "retrosynthesis",
                            _ => "reaction",
                        }
                        .into();
                    }
                }
                if let Graphic::Arrow { kind, .. } = &e.graphics[gi] {
                    draw_text(
                        &format!("Type: {kind}"),
                        panel_x + 20.,
                        TOP + 245.,
                        14.,
                        muted(),
                    );
                }
            } else if let Graphic::ElectronArrow { electrons, .. } = &e.graphics[gi] {
                draw_text(
                    if *electrons == 1 {
                        "One electron (fishhook)"
                    } else {
                        "Electron pair"
                    },
                    panel_x + 16.,
                    TOP + 96.,
                    15.,
                    muted(),
                );
            }
        } else {
            let cx = panel_x + 125.;
            draw_circle(cx, TOP + 131., 29., Color::from_rgba(237, 242, 252, 255));
            draw_circle_lines(
                cx,
                TOP + 131.,
                12.,
                2.,
                Color::from_rgba(129, 155, 217, 255),
            );
            draw_line(
                cx + 9.,
                TOP + 141.,
                cx + 19.,
                TOP + 151.,
                2.,
                Color::from_rgba(129, 155, 217, 255),
            );
            draw_text("Nothing selected", panel_x + 49., TOP + 187., 17., ink());
            draw_text(
                "Drag a box to select atoms",
                panel_x + 40.,
                TOP + 215.,
                13.,
                muted(),
            );
            draw_text(
                "or click a bond/object",
                panel_x + 44.,
                TOP + 234.,
                13.,
                muted(),
            );
        }
        let analysis = chemistry::analyze(&e.mol);
        round_rect(panel_x + 11., TOP + 308., 228., 245., 12., WHITE);
        draw_text("Whole document", panel_x + 25., TOP + 336., 20., ink());
        draw_text(
            &format!("Formula: {}", analysis.formula),
            panel_x + 16.,
            TOP + 365.,
            17.,
            DARKGRAY,
        );
        draw_text(
            &format!(
                "Molar: {} g/mol",
                analysis
                    .molar_mass
                    .map(|x| format!("{x:.3}"))
                    .unwrap_or_else(|| "unavailable".into())
            ),
            panel_x + 16.,
            TOP + 391.,
            16.,
            DARKGRAY,
        );
        draw_text(
            &format!(
                "Exact: {} Da",
                analysis
                    .exact_mass
                    .map(|x| format!("{x:.4}"))
                    .unwrap_or_else(|| "unavailable".into())
            ),
            panel_x + 16.,
            TOP + 417.,
            16.,
            DARKGRAY,
        );
        draw_text(
            &format!(
                "Selected implicit H: {}",
                e.selected
                    .and_then(|i| analysis.implicit_h.get(i).copied().flatten())
                    .map(|n| n.to_string())
                    .unwrap_or_else(|| "-".into())
            ),
            panel_x + 16.,
            TOP + 444.,
            15.,
            DARKGRAY,
        );
        draw_text(
            &format!("Warnings: {}", analysis.warnings.len()),
            panel_x + 16.,
            TOP + 473.,
            16.,
            if analysis.warnings.is_empty() {
                DARKGRAY
            } else {
                RED
            },
        );
        for (j, msg) in analysis.warnings.iter().take(3).enumerate() {
            let short: String = msg.chars().take(28).collect();
            draw_text(&short, panel_x + 16., TOP + 501. + j as f32 * 21., 14., RED);
        }
        if h - BOTTOM > TOP + 660. {
            round_rect(panel_x + 11., TOP + 562., 228., 95., 12., WHITE);
            draw_text("GRAPH", panel_x + 25., TOP + 584., 11., muted());
            draw_text(
                &format!(
                    "{} atoms  ·  {} bonds",
                    analysis.atom_count, analysis.bond_count
                ),
                panel_x + 25.,
                TOP + 610.,
                16.,
                ink(),
            );
            draw_text(
                &format!("Formal charge  {:+}", analysis.formal_charge),
                panel_x + 25.,
                TOP + 638.,
                15.,
                muted(),
            );
        }
        draw_rectangle(0., h - BOTTOM, w, BOTTOM, WHITE);
        draw_line(
            0.,
            h - BOTTOM,
            w,
            h - BOTTOM,
            1.,
            Color::from_rgba(218, 226, 238, 255),
        );
        draw_text("ELEMENTS", 17., h - BOTTOM + 32., 11., muted());
        let elements = [
            "C", "N", "O", "S", "P", "F", "Cl", "Br", "I", "H", "B", "Si",
        ];
        let mut ex = 88.;
        for el in elements {
            if button(ex, h - BOTTOM + 10., 48., 38., el, e.element == el) {
                e.element = el.into();
                e.tool = Tool::Atom;
            }
            ex += 53.;
        }
        draw_line(
            0.,
            h - 31.,
            w,
            h - 31.,
            1.,
            Color::from_rgba(237, 241, 248, 255),
        );
        draw_circle(22., h - 15., 4., Color::from_rgba(54, 187, 143, 255));
        draw_text(&e.status, 34., h - 10., 14., muted());
        if !e.quick.pending.is_empty() {
            draw_text(
                &format!("Input: {}", e.quick.pending),
                w - RIGHT - 180.,
                70.,
                18.,
                accent(),
            );
        }
        draw_text(
            "Keys: 1/2/3 bonds | Shift+R ring | E erase | Esc select | Cmd+Z undo | Cmd+S save",
            w - 660.,
            h - 10.,
            12.,
            muted(),
        );
        let cmd = is_key_down(KeyCode::LeftSuper)
            || is_key_down(KeyCode::RightSuper)
            || is_key_down(KeyCode::LeftControl)
            || is_key_down(KeyCode::RightControl);
        if e.file_dialog.is_none()
            && e.pending_export.is_none()
            && !e.periodic_open
            && !e.templates_open
            && e.text_target.is_none()
            && e.menu_open.is_none()
            && e.info_overlay.is_none()
            && !e.settings_open
            && !e.palette_open
        {
            if cmd
                && (is_key_down(KeyCode::LeftShift) || is_key_down(KeyCode::RightShift))
                && is_key_pressed(KeyCode::P)
            {
                e.palette_open = true;
                e.palette_query.clear();
                e.palette_selection = 0;
            }
            if cmd && is_key_pressed(KeyCode::Z) {
                if is_key_down(KeyCode::LeftShift) || is_key_down(KeyCode::RightShift) {
                    e.redo()
                } else {
                    e.undo()
                }
            }
            if cmd && is_key_pressed(KeyCode::S) {
                e.file_dialog = Some(true);
            }
            if cmd && is_key_pressed(KeyCode::O) {
                e.file_dialog = Some(false);
            }
            if cmd && is_key_pressed(KeyCode::E) {
                e.periodic_open = true;
            }
            if cmd && is_key_pressed(KeyCode::Y) {
                e.redo();
            }
            if cmd && is_key_pressed(KeyCode::N) {
                e.checkpoint();
                e.mol = Molecule::default();
                e.graphics.clear();
                e.selected = None;
                e.selected_atoms.clear();
                e.selected_bond = None;
                e.selected_graphic = None;
            }
            if is_key_pressed(KeyCode::Delete) || is_key_pressed(KeyCode::Backspace) {
                if e.selected_atoms.len() > 1 {
                    e.checkpoint();
                    for i in e.selected_atoms.clone().into_iter().rev() {
                        e.remove_atom(i);
                    }
                    e.selected_atoms.clear();
                    e.selected = None;
                } else if let Some(i) = e.selected {
                    e.checkpoint();
                    e.remove_atom(i);
                    e.selected = None;
                    e.selected_atoms.clear();
                } else if let Some(i) = e.selected_bond.take() {
                    e.checkpoint();
                    e.mol.bonds.remove(i);
                } else if let Some(i) = e.selected_graphic.take() {
                    e.checkpoint();
                    e.graphics.remove(i);
                }
            }
            if is_key_pressed(KeyCode::Escape) {
                e.tool = Tool::Select;
                e.pending_arrow = None;
                e.selected = None;
                e.selected_atoms.clear();
                e.selected_bond = None;
                e.selected_graphic = None;
                e.selection_box = None;
                e.quick.pending.clear();
            }
            if is_key_down(KeyCode::LeftShift) && is_key_pressed(KeyCode::R) {
                e.tool = Tool::Ring(6);
            }
            if !cmd && is_key_pressed(KeyCode::E) {
                e.tool = Tool::Erase;
            }
            if !cmd {
                while let Some(ch) = get_char_pressed() {
                    for a in e.quick.push(ch, get_time()) {
                        e.apply_quick(a);
                    }
                }
                for a in e.quick.tick(get_time()) {
                    e.apply_quick(a);
                }
            } else {
                e.quick.pending.clear();
            }
            if canvas(p) {
                if is_mouse_button_pressed(MouseButton::Left) {
                    e.drag_start = Some(p);
                    e.moved = false;
                    match e.tool {
                        Tool::Select => {
                            e.select_at(p);
                        }
                        Tool::Erase => {
                            if let Some(i) = e.hit_atom(p) {
                                e.checkpoint();
                                e.remove_atom(i);
                                e.selected = None;
                                e.selected_atoms.clear();
                                e.selected_bond = None;
                                e.selected_graphic = None;
                            } else if let Some(i) = e.hit_bond(p) {
                                e.checkpoint();
                                e.mol.bonds.remove(i);
                                e.selected_bond = None;
                            } else if let Some(i) = e.hit_graphic(p) {
                                e.checkpoint();
                                e.graphics.remove(i);
                                e.selected_graphic = None;
                            }
                        }
                        Tool::Atom => {
                            e.checkpoint();
                            if let Some(i) = e.hit_atom(p) {
                                e.mol.atoms[i].element = e.element.clone();
                            } else {
                                let el = e.element.clone();
                                e.add_atom(p, &el);
                            }
                        }
                        Tool::Ring(n) => {
                            e.checkpoint();
                            e.ring(p, n);
                        }
                        Tool::Template(kind) => e.insert_template(kind, p),
                        Tool::Charge(n) => {
                            if let Some(i) = e.hit_atom(p) {
                                e.checkpoint();
                                e.mol.atoms[i].charge = (e.mol.atoms[i].charge + n).clamp(-9, 9);
                            }
                        }
                        Tool::Arrow
                        | Tool::Electron(_)
                        | Tool::StyledBond(_)
                        | Tool::Bond(_)
                        | Tool::Chain
                        | Tool::Shape(_) => {}
                        Tool::Plus => {
                            e.checkpoint();
                            e.graphics.push(Graphic::Plus { pos: p });
                        }
                        Tool::Text => {
                            e.text_target = Some(TextTarget::New(p));
                            e.text_buffer.clear();
                        }
                    }
                }
                if is_mouse_button_down(MouseButton::Left) && e.tool == Tool::Select {
                    if let Some(start) = e.selection_box {
                        if p.distance(start) > 3. {
                            e.select_box(start, p);
                        }
                    } else if let (Some(i), Some(start)) = (e.selected, e.drag_start) {
                        if p.distance(start) > 2. {
                            if !e.moved {
                                e.checkpoint();
                                e.moved = true;
                            }
                            e.mol.atoms[i].pos = p;
                        }
                    }
                }
                if is_mouse_button_released(MouseButton::Left) {
                    if let Some(start) = e.selection_box.take() {
                        e.select_box(start, p);
                    }
                    if matches!(e.tool, Tool::Arrow | Tool::Electron(_)) {
                        e.finish_arrow(p);
                    }
                    if let (Some(start), Tool::Shape(kind)) = (e.drag_start, e.tool) {
                        if canvas(start) {
                            e.checkpoint();
                            e.graphics.push(Graphic::Shape {
                                kind,
                                start,
                                end: p,
                            });
                            e.status = format!("Drew {}", kind.code());
                        }
                    }
                    if let Some(start) = e.drag_start.filter(|_| {
                        matches!(e.tool, Tool::Bond(_) | Tool::StyledBond(_) | Tool::Chain)
                    }) {
                        if canvas(start) {
                            if e.tool == Tool::Chain {
                                e.checkpoint();
                                e.draw_chain(start, p);
                            } else {
                                e.checkpoint();
                                let a = e.hit_atom(start).unwrap_or_else(|| e.add_atom(start, "C"));
                                let origin = e.mol.atoms[a].pos;
                                let end = if p.distance(origin) < 14. {
                                    e.suggest_endpoint(a)
                                } else {
                                    p
                                };
                                let b = e.hit_atom(end).unwrap_or_else(|| e.add_atom(end, "C"));
                                match e.tool {
                                    Tool::Bond(order) => e.add_bond(a, b, order),
                                    Tool::StyledBond(style) => {
                                        e.add_styled_bond(a, b, style);
                                        if let Some(q) = &e.bond_query {
                                            if let Some(bond) =
                                                e.mol.bonds.iter_mut().find(|bond| {
                                                    (bond.a == a && bond.b == b)
                                                        || (bond.a == b && bond.b == a)
                                                })
                                            {
                                                bond.query = Some(q.clone());
                                            }
                                        }
                                    }
                                    _ => {}
                                }
                            }
                        }
                    }
                    e.drag_start = None;
                }
            } else if is_mouse_button_released(MouseButton::Left) {
                e.drag_start = None;
            }
        } else if e.palette_open {
            draw_rectangle(0., 0., w, h, Color::from_rgba(0, 0, 0, 95));
            let commands = all_commands();
            let query = e.palette_query.to_lowercase();
            let matches: Vec<&str> = commands
                .into_iter()
                .filter(|name| *name != "Command palette" && name.to_lowercase().contains(&query))
                .collect();
            if !matches.is_empty() {
                e.palette_selection = e.palette_selection.min(matches.len() - 1);
            } else {
                e.palette_selection = 0;
            }
            let width = 540.;
            let row_height = 37.;
            let shown = matches.len().min(9);
            let height = 112. + shown as f32 * row_height;
            let x = (w - width) / 2.;
            let y = (h - height) / 2.;
            round_rect(
                x + 4.,
                y + 6.,
                width,
                height,
                15.,
                Color::from_rgba(0, 0, 0, 34),
            );
            round_rect(x, y, width, height, 15., WHITE);
            draw_text("COMMAND PALETTE", x + 20., y + 26., 12., muted());
            draw_rectangle_lines(x + 16., y + 39., width - 32., 40., 1., accent());
            draw_text(&e.palette_query, x + 27., y + 66., 20., ink());
            while let Some(ch) = get_char_pressed() {
                if !ch.is_control() {
                    e.palette_query.push(ch);
                    e.palette_selection = 0;
                }
            }
            if is_key_pressed(KeyCode::Backspace) {
                e.palette_query.pop();
                e.palette_selection = 0;
            }
            if is_key_pressed(KeyCode::Up) {
                e.palette_selection = e.palette_selection.saturating_sub(1);
            }
            if is_key_pressed(KeyCode::Down) && !matches.is_empty() {
                e.palette_selection = (e.palette_selection + 1).min(matches.len() - 1);
            }
            if is_key_pressed(KeyCode::Escape) {
                e.palette_open = false;
            }
            let mut selected_command = None;
            for (index, command) in matches.iter().take(9).enumerate() {
                if button(
                    x + 14.,
                    y + 84. + index as f32 * row_height,
                    width - 28.,
                    33.,
                    command,
                    index == e.palette_selection,
                ) {
                    selected_command = Some(*command);
                }
            }
            if is_key_pressed(KeyCode::Enter) {
                selected_command = matches.get(e.palette_selection).copied();
            }
            if let Some(command) = selected_command {
                e.palette_open = false;
                e.menu_action(command);
            }
            if matches.is_empty() {
                draw_text("No matching commands", x + 22., y + 100., 15., muted());
            }
        } else if let Some(idx) = e.menu_open {
            let x = (304. + idx as f32 * 94.).min(w - 265.);
            let y = 38.;
            let items = menu_items(idx);
            draw_rectangle(x, y, 250., items.len() as f32 * 39. + 12., WHITE);
            draw_rectangle_lines(x, y, 250., items.len() as f32 * 39. + 12., 1., GRAY);
            for (j, item) in items.iter().enumerate() {
                if button(x + 6., y + 6. + j as f32 * 39., 238., 34., item, false) {
                    e.menu_open = None;
                    e.menu_action(item);
                }
            }
            if is_key_pressed(KeyCode::Escape) {
                e.menu_open = None;
            }
            if is_mouse_button_pressed(MouseButton::Left)
                && !(p.x >= x
                    && p.x <= x + 250.
                    && p.y >= y
                    && p.y <= y + items.len() as f32 * 39. + 12.)
                && p.y > 36.
            {
                e.menu_open = None;
            }
        } else if e.settings_open {
            let width = 440.;
            let height = 278.;
            let x = (w - width) / 2.;
            let y = (h - height) / 2.;
            round_rect(
                x + 5.,
                y + 7.,
                width,
                height,
                18.,
                Color::from_rgba(0, 0, 0, 30),
            );
            round_rect(x, y, width, height, 18., WHITE);
            round_rect(x, y, width, 58., 18., Color::from_rgba(238, 247, 241, 255));
            draw_rectangle(x, y + 40., width, 18., Color::from_rgba(238, 247, 241, 255));
            draw_text("Settings", x + 22., y + 36., 25., ink());
            draw_text("Interface language", x + 24., y + 94., 17., DARKGRAY);
            let english_selected = e.language == Language::English;
            let danish_selected = e.language == Language::Danish;
            UI_INPUT_ENABLED.with(|enabled| enabled.set(true));
            if button(x + 24., y + 113., 185., 48., "English", english_selected) {
                e.set_language(Language::English);
            }
            if button(x + 231., y + 113., 185., 48., "Dansk", danish_selected) {
                e.set_language(Language::Danish);
            }
            draw_text("Saved automatically", x + 24., y + 190., 14., muted());
            if button(x + width - 122., y + height - 55., 98., 36., "Close", true)
                || is_key_pressed(KeyCode::Escape)
            {
                e.settings_open = false;
            }
            UI_INPUT_ENABLED.with(|enabled| enabled.set(false));
        } else if let Some(info) = e.info_overlay.clone() {
            draw_rectangle(0., 0., w, h, Color::from_rgba(0, 0, 0, 100));
            let dx = (w - 650.) / 2.;
            let lines: Vec<&str> = info.lines().take(18).collect();
            let mh = (106. + lines.len() as f32 * 24.).max(300.).min(h - 60.);
            let dy = (h - mh) / 2.;
            round_rect(dx, dy, 650., mh, 16., WHITE);
            draw_text("Analysis & information", dx + 20., dy + 35., 24., ink());
            for (j, line) in lines.iter().enumerate() {
                draw_text(
                    &line.chars().take(75).collect::<String>(),
                    dx + 20.,
                    dy + 68. + j as f32 * 24.,
                    16.,
                    DARKGRAY,
                );
            }
            if button(dx + 530., dy + mh - 50., 100., 34., "Close", true)
                || is_key_pressed(KeyCode::Escape)
            {
                e.info_overlay = None;
            }
        } else if e.text_target.is_some() {
            draw_rectangle(0., 0., w, h, Color::from_rgba(0, 0, 0, 100));
            let dx = (w - 500.) / 2.;
            let dy = (h - 175.) / 2.;
            draw_rectangle(dx, dy, 500., 175., WHITE);
            draw_text("Enter text", dx + 20., dy + 35., 24., DARKGRAY);
            draw_rectangle_lines(dx + 20., dy + 55., 460., 39., 1., accent());
            draw_text(&e.text_buffer, dx + 27., dy + 81., 20., DARKGRAY);
            while let Some(ch) = get_char_pressed() {
                if !ch.is_control() {
                    e.text_buffer.push(ch);
                }
            }
            if is_key_pressed(KeyCode::Backspace) {
                e.text_buffer.pop();
            }
            if is_key_pressed(KeyCode::Escape) {
                e.text_target = None;
            }
            if is_key_pressed(KeyCode::Enter) {
                e.commit_text();
            }
            if button(dx + 260., dy + 119., 100., 35., "Cancel", false) {
                e.text_target = None;
            }
            if button(dx + 372., dy + 119., 108., 35., "Apply", true) {
                e.commit_text();
            }
        } else if e.periodic_open {
            draw_rectangle(0., 0., w, h, Color::from_rgba(0, 0, 0, 100));
            let dx = (w - 800.) / 2.;
            let dy = (h - 420.) / 2.;
            draw_rectangle(dx, dy, 800., 420., WHITE);
            draw_text(
                "Periodic table - choose an element",
                dx + 15.,
                dy + 31.,
                23.,
                DARKGRAY,
            );
            for (z, sym) in chemistry::SYMBOLS.iter().enumerate() {
                let (col, row) = periodic_cell(z);
                let x = dx + 17. + col as f32 * 42.;
                let y = dy + 48. + row as f32 * 37.;
                if button(x, y, 38., 32., sym, false) {
                    e.element = (*sym).into();
                    e.tool = Tool::Atom;
                    e.periodic_open = false;
                    e.status = format!("Element: {sym}");
                }
            }
            if is_key_pressed(KeyCode::Escape) {
                e.periodic_open = false;
            }
        } else if e.templates_open {
            draw_rectangle(0., 0., w, h, Color::from_rgba(0, 0, 0, 100));
            let dx = (w - 470.) / 2.;
            let dy = (h - 465.) / 2.;
            draw_rectangle(dx, dy, 470., 465., WHITE);
            draw_text("Templates", dx + 20., dy + 35., 24., DARKGRAY);
            for (j, kind) in [
                "Benzene",
                "Cyclohexane",
                "Pyridine",
                "Ethanol",
                "Carboxyl",
                "Cyclopropane",
                "Cyclobutane",
                "Cyclopentane",
                "Cycloheptane",
                "Cyclooctane",
                "Pyrimidine",
                "Imidazole",
            ]
            .iter()
            .enumerate()
            {
                let col = (j % 2) as f32;
                let row = (j / 2) as f32;
                if button(
                    dx + 20. + col * 215.,
                    dy + 55. + row * 58.,
                    205.,
                    46.,
                    kind,
                    false,
                ) {
                    e.tool = Tool::Template(kind);
                    e.templates_open = false;
                    e.status = format!("Click canvas to place {kind}");
                }
            }
            if is_key_pressed(KeyCode::Escape) {
                e.templates_open = false;
            }
        } else if e.pending_export.is_some() {
            draw_rectangle(0., 0., w, h, Color::from_rgba(0, 0, 0, 90));
            let dx = (w - 560.) / 2.;
            let dy = (h - 190.) / 2.;
            draw_rectangle(dx, dy, 560., 190., WHITE);
            draw_text(
                "Export may lose information",
                dx + 20.,
                dy + 35.,
                24.,
                DARKGRAY,
            );
            draw_text(
                &e.status.chars().take(65).collect::<String>(),
                dx + 20.,
                dy + 75.,
                17.,
                RED,
            );
            draw_text(
                "Save as .mols to preserve the full document.",
                dx + 20.,
                dy + 105.,
                17.,
                DARKGRAY,
            );
            if button(dx + 250., dy + 135., 135., 34., "Cancel", false)
                || is_key_pressed(KeyCode::Escape)
            {
                e.pending_export = None;
            }
            if button(dx + 397., dy + 135., 140., 34., "Export", true)
                || is_key_pressed(KeyCode::Enter)
            {
                if let Some(path) = e.pending_export.take() {
                    e.save(&path);
                }
            }
        } else {
            draw_rectangle(0., 0., w, h, Color::from_rgba(0, 0, 0, 90));
            let dx = (w - 760.) / 2.;
            let dy = (h - 190.) / 2.;
            draw_rectangle(dx, dy, 760., 190., WHITE);
            draw_rectangle_lines(dx, dy, 760., 190., 1., GRAY);
            let saving = e.file_dialog == Some(true);
            draw_text(
                if saving {
                    "Save molecule"
                } else {
                    "Open MOL or MOLS"
                },
                dx + 22.,
                dy + 38.,
                25.,
                DARKGRAY,
            );
            draw_rectangle_lines(dx + 20., dy + 58., 720., 39., 1., accent());
            draw_text(&e.path_input, dx + 29., dy + 84., 20., DARKGRAY);
            while let Some(ch) = get_char_pressed() {
                if !ch.is_control() {
                    e.path_input.push(ch);
                }
            }
            if is_key_pressed(KeyCode::Backspace) {
                e.path_input.pop();
            }
            if is_key_pressed(KeyCode::Escape) {
                e.file_dialog = None;
            }
            if is_key_pressed(KeyCode::Enter) {
                let path = e.path_input.clone();
                if saving {
                    e.request_save(path);
                } else {
                    e.load(&path);
                }
                e.file_dialog = None;
            }
            if button(dx + 530., dy + 125., 94., 36., "Cancel", false) {
                e.file_dialog = None;
            }
            if button(
                dx + 636.,
                dy + 125.,
                104.,
                36.,
                if saving { "Save" } else { "Open" },
                true,
            ) {
                let path = e.path_input.clone();
                if saving {
                    e.request_save(path);
                } else {
                    e.load(&path);
                }
                e.file_dialog = None;
            }
            draw_text(
                "Use an absolute path or a path relative to the launch folder.",
                dx + 20.,
                dy + 117.,
                15.,
                GRAY,
            );
        }
        if e.file_dialog.is_none()
            && e.pending_export.is_none()
            && !e.periodic_open
            && !e.templates_open
            && e.text_target.is_none()
            && e.info_overlay.is_none()
            && e.menu_open.is_none()
        {
            if let Some((i, (_, t))) = tools.iter().enumerate().find(|(i, _)| {
                let y = TOP + 30. + *i as f32 * 35.;
                p.x >= 18. && p.x < 70. && p.y >= y && p.y < y + 33.
            }) {
                let text = tool_help(*t);
                let ty = (TOP + 30. + i as f32 * 35.).min(h - BOTTOM - 40.);
                round_rect(LEFT + 8., ty, 370., 34., 9., navy());
                draw_text(text, LEFT + 18., ty + 23., 14., WHITE);
            }
        }
        next_frame().await;
    }
}
fn tool_help(t: Tool) -> &'static str {
    match t {
        Tool::Select => "Select and drag atoms or graphic objects (Esc)",
        Tool::Erase => "Delete one atom, bond or object (E)",
        Tool::Bond(1) => "Draw a single bond (1)",
        Tool::Bond(2) => "Draw a double bond (2)",
        Tool::Bond(3) => "Draw a triple bond (3)",
        Tool::StyledBond(BondStyle::Aromatic) => "Draw an aromatic bond (4)",
        Tool::StyledBond(BondStyle::Wedge) => "Draw a filled wedge (5)",
        Tool::StyledBond(BondStyle::Hash) => "Draw a hashed wedge (6)",
        Tool::StyledBond(BondStyle::Wavy) => "Draw an unspecified stereo bond (7)",
        Tool::Atom => "Place or replace an atom (element symbol)",
        Tool::Chain => "Draw a zigzag carbon chain (drag between endpoints)",
        Tool::Ring(6) => "Place a six-membered ring (Shift+R)",
        Tool::Ring(5) => "Place a five-membered ring",
        Tool::Charge(1) => "Increase atom charge (+)",
        Tool::Charge(-1) => "Decrease atom charge (-)",
        Tool::Arrow => "Drag to draw a reaction arrow",
        Tool::Electron(1) => "Drag to draw a single-electron fishhook arrow",
        Tool::Electron(_) => "Drag to draw a two-electron curved arrow",
        Tool::Plus => "Place a reaction plus sign",
        Tool::Text => "Place a text label",
        Tool::Shape(ShapeKind::Line) => "Drag to draw a line",
        Tool::Shape(ShapeKind::Rectangle) => "Drag to draw a rectangle",
        Tool::Shape(ShapeKind::Ellipse) => "Drag to draw an ellipse",
        Tool::Template(_) => "Click canvas to place template",
        _ => "Draw a bond",
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn language_setting_roundtrips_and_localizes_menu_labels() {
        let path = std::env::temp_dir().join(format!(
            "molecula-language-test-{}.conf",
            std::process::id()
        ));
        save_language_to(&path, Language::Danish).unwrap();
        assert_eq!(load_language_from(&path), Language::Danish);
        assert_eq!(localized(Language::Danish, "Calculations"), "Beregninger");
        assert_eq!(localized(Language::English, "Calculations"), "Calculations");
        let _ = fs::remove_file(path);
    }

    #[test]
    fn two_click_arrows_are_real_undoable_objects() {
        let mut e = Editor::new();
        e.tool = Tool::Arrow;
        e.drag_start = Some(vec2(100., 100.));
        e.finish_arrow(vec2(100., 100.));
        assert!(e.graphics.is_empty() && e.pending_arrow.is_some());
        e.drag_start = Some(vec2(300., 100.));
        e.finish_arrow(vec2(300., 100.));
        assert!(matches!(e.graphics.first(), Some(Graphic::Arrow { .. })));
        e.undo();
        assert!(e.graphics.is_empty());
        e.tool = Tool::Electron(2);
        e.drag_start = Some(vec2(100., 100.));
        e.finish_arrow(vec2(100., 100.));
        e.drag_start = Some(vec2(200., 100.));
        e.finish_arrow(vec2(200., 100.));
        assert!(matches!(
            e.graphics.first(),
            Some(Graphic::ElectronArrow { electrons: 2, .. })
        ));
    }

    #[test]
    fn removing_atom_reindexes_remaining_bonds() {
        let mut editor = Editor::new();
        for x in [0., 40., 80., 120.] {
            editor.add_atom(vec2(x, 0.), "C");
        }
        editor.add_bond(0, 2, 1);
        editor.add_bond(2, 3, 2);
        editor.remove_atom(1);
        assert_eq!(editor.mol.atoms.len(), 3);
        assert_eq!((editor.mol.bonds[0].a, editor.mol.bonds[0].b), (0, 1));
        assert_eq!((editor.mol.bonds[1].a, editor.mol.bonds[1].b), (1, 2));
    }

    #[test]
    fn editing_existing_bond_does_not_duplicate_it() {
        let mut editor = Editor::new();
        editor.add_atom(vec2(0., 0.), "C");
        editor.add_atom(vec2(40., 0.), "O");
        editor.add_bond(0, 1, 1);
        editor.add_bond(1, 0, 2);
        assert_eq!(editor.mol.bonds.len(), 1);
        assert_eq!(editor.mol.bonds[0].order, 2);
    }

    #[test]
    fn mol_roundtrip_keeps_connectivity_charge_and_isotope() {
        let mut editor = Editor::new();
        let c = editor.add_atom(vec2(200., 200.), "C");
        let o = editor.add_atom(vec2(243., 200.), "O");
        editor.add_bond(c, o, 2);
        editor.mol.atoms[o].charge = -1;
        editor.mol.atoms[c].isotope = Some(13);
        let read = parse_mol_at(&editor.molfile(), vec2(300., 300.)).unwrap();
        assert_eq!(read.atoms.len(), 2);
        assert_eq!(read.bonds[0].order, 2);
        assert_eq!(read.atoms[1].charge, -1);
        assert_eq!(read.atoms[0].isotope, Some(13));
    }

    #[test]
    fn mol_import_rejects_non_finite_coordinates_and_invalid_bonds() {
        let bad_coordinate = "MOL\n  Rust\n\n  1  0  0  0  0  0            999 V2000\n       NaN    0.0000    0.0000 C   0  0  0  0  0  0  0  0  0  0  0  0\nM  END\n";
        assert!(parse_mol_at(bad_coordinate, vec2(0., 0.)).is_err());

        let invalid_order = "MOL\n  Rust\n\n  2  1  0  0  0  0            999 V2000\n       0.0000    0.0000    0.0000 C   0  0  0  0  0  0  0  0  0  0  0  0\n       1.0000    0.0000    0.0000 C   0  0  0  0  0  0  0  0  0  0  0  0\n  1  2  0  0  0  0  0\nM  END\n";
        assert!(parse_mol_at(invalid_order, vec2(0., 0.)).is_err());
    }

    #[test]
    fn undo_redo_restores_graphics_and_molecule() {
        let mut editor = Editor::new();
        editor.checkpoint();
        editor.add_atom(vec2(0., 0.), "N");
        editor.graphics.push(Graphic::Plus { pos: vec2(20., 0.) });
        editor.undo();
        assert!(editor.mol.atoms.is_empty() && editor.graphics.is_empty());
        editor.redo();
        assert_eq!(editor.mol.atoms.len(), 1);
        assert_eq!(editor.graphics.len(), 1);
    }

    #[test]
    fn lossy_export_is_flagged() {
        let mut editor = Editor::new();
        editor.graphics.push(Graphic::Plus { pos: vec2(0., 0.) });
        assert!(editor.export_losses("test.mols").is_empty());
        assert!(editor
            .export_losses("test.mol")
            .contains(&"graphics, reaction arrows and text"));
    }

    #[test]
    fn benzene_and_pyridine_templates_have_expected_graphs() {
        let mut benzene = Editor::new();
        benzene.insert_template("Benzene", vec2(300., 300.));
        assert_eq!((benzene.mol.atoms.len(), benzene.mol.bonds.len()), (6, 6));
        assert_eq!(chemistry::analyze(&benzene.mol).formula, "C6H6");
        let mut pyridine = Editor::new();
        pyridine.insert_template("Pyridine", vec2(300., 300.));
        assert_eq!(chemistry::analyze(&pyridine.mol).formula, "C5H5N");
    }

    #[test]
    fn explicit_hydrogen_add_remove_preserves_formula() {
        let mut e = Editor::new();
        let c1 = e.add_atom(vec2(0., 0.), "C");
        let c2 = e.add_atom(vec2(BOND, 0.), "C");
        let o = e.add_atom(vec2(BOND * 2., 0.), "O");
        e.add_bond(c1, c2, 1);
        e.add_bond(c2, o, 1);
        let formula = chemistry::analyze(&e.mol).formula;
        assert_eq!(formula, "C2H6O");
        e.add_explicit_hydrogens();
        assert_eq!(chemistry::analyze(&e.mol).formula, formula);
        assert_eq!(e.mol.atoms.iter().filter(|a| a.element == "H").count(), 6);
        e.remove_explicit_hydrogens();
        assert_eq!(chemistry::analyze(&e.mol).formula, formula);
    }

    #[test]
    fn mirror_inverts_stored_stereo_and_rotation_preserves_it() {
        let mut e = Editor::new();
        let i = e.add_atom(vec2(10., 20.), "C");
        e.mol.atoms[i].stereo = Some("R".into());
        e.transform_document(std::f32::consts::FRAC_PI_2, false, false);
        assert_eq!(e.mol.atoms[i].stereo.as_deref(), Some("R"));
        e.transform_document(0., true, false);
        assert_eq!(e.mol.atoms[i].stereo.as_deref(), Some("S"));
    }

    #[test]
    fn heterocycle_templates_are_real_aromatic_graphs() {
        let mut e = Editor::new();
        e.insert_template("Imidazole", vec2(300., 300.));
        assert_eq!((e.mol.atoms.len(), e.mol.bonds.len()), (5, 5));
        assert_eq!(e.mol.atoms.iter().filter(|a| a.element == "N").count(), 2);
        assert!(e.mol.atoms.iter().all(|a| a.aromatic));
        assert!(e.mol.bonds.iter().all(|b| b.style == BondStyle::Aromatic));
    }

    #[test]
    fn ion_charge_does_not_modify_unrelated_atoms() {
        let mut e = Editor::new();
        e.add_atom(vec2(0., 0.), "O");
        e.add_atom(vec2(40., 0.), "C");
        e.selected = Some(0);
        e.apply_quick(shortcuts::QuickAction::Charge(-1));
        assert_eq!(e.mol.atoms[0].charge, -1);
        assert_eq!(e.mol.atoms[1].charge, 0);
        e.undo();
        assert_eq!(e.mol.atoms[0].charge, 0);
    }

    #[test]
    fn every_top_level_menu_has_working_commands() {
        for (i, name) in MENU_NAMES.iter().enumerate() {
            assert!(!menu_items(i).is_empty(), "{} menu has no commands", name);
        }
        let calculation_commands = menu_items(7);
        assert!(calculation_commands.contains(&"Formula & mass"));
        assert!(calculation_commands.contains(&"Molecular properties"));
        assert!(calculation_commands.contains(&"Reaction analysis"));
        assert!(calculation_commands.contains(&"RDKit descriptors"));
    }

    #[test]
    fn calculation_menu_commands_return_real_results_or_clear_unavailable_states() {
        let mut e = Editor::new();
        e.add_atom(vec2(0., 0.), "C");
        e.menu_action("Formula & mass");
        assert!(e.info_overlay.as_deref().unwrap().contains("CH4"));
        e.menu_action("Molecular properties");
        assert!(e.info_overlay.as_deref().unwrap().contains("Atoms: 1"));
        e.menu_action("Reaction analysis");
        assert!(e
            .info_overlay
            .as_deref()
            .unwrap()
            .contains("Draw a reaction"));
        e.menu_action("RDKit descriptors");
        assert!(e
            .info_overlay
            .as_deref()
            .unwrap()
            .contains("Calculating RDKit"));
        assert!(e.calc_rx.is_some());
    }

    #[test]
    fn drag_selection_finds_atoms_in_a_rectangle_in_either_direction() {
        let mut e = Editor::new();
        e.add_atom(vec2(20., 30.), "C");
        e.add_atom(vec2(80., 90.), "O");
        e.add_atom(vec2(200., 200.), "N");
        assert_eq!(
            e.atoms_in_rect(vec2(10., 10.), vec2(100., 100.)),
            vec![0, 1]
        );
        e.select_box(vec2(100., 100.), vec2(10., 10.));
        assert_eq!(e.selected_atoms, vec![0, 1]);
        assert_eq!(e.selected, None);
        assert!(e.status.contains("2 atom(s)"));
    }

    #[test]
    fn click_selects_a_bond_for_the_inspector_and_delete_is_undoable() {
        let mut e = Editor::new();
        e.add_atom(vec2(100., 100.), "C");
        e.add_atom(vec2(143., 100.), "O");
        e.add_bond(0, 1, 2);
        e.select_at(vec2(121.5, 100.));
        assert_eq!(e.selected_bond, Some(0));
        assert!(e.selected.is_none());

        e.menu_action("Delete selection");
        assert!(e.mol.bonds.is_empty());
        e.undo();
        assert_eq!(e.mol.bonds.len(), 1);
    }

    #[test]
    fn save_open_and_export_workflow_uses_real_files() {
        let base = std::env::temp_dir().join(format!(
            "molecula-e2e-{}-{}",
            std::process::id(),
            std::time::SystemTime::now()
                .duration_since(std::time::UNIX_EPOCH)
                .unwrap()
                .as_nanos()
        ));
        let mols = base.with_extension("mols");
        let mol = base.with_extension("mol");
        let svg = base.with_extension("svg");

        let mut original = Editor::new();
        let c = original.add_atom(vec2(300., 300.), "C");
        let o = original.add_atom(vec2(343., 300.), "O");
        original.add_bond(c, o, 2);
        original.mol.atoms[c].isotope = Some(13);
        original.mol.atoms[o].charge = -1;
        original.graphics.push(Graphic::Arrow {
            start: vec2(300., 250.),
            end: vec2(350., 250.),
            kind: "reaction".into(),
            above: "heat".into(),
            below: "".into(),
        });

        original.save(mols.to_str().unwrap());
        assert!(original.status.starts_with("Saved "), "{}", original.status);
        let mut reopened = Editor::new();
        reopened.load(mols.to_str().unwrap());
        assert_eq!(reopened.mol, original.mol);
        assert_eq!(reopened.graphics, original.graphics);

        reopened.save(mol.to_str().unwrap());
        assert!(reopened.status.starts_with("Saved "), "{}", reopened.status);
        let mol_data = fs::read_to_string(&mol).unwrap();
        let imported = parse_mol_at(&mol_data, vec2(300., 300.)).unwrap();
        assert_eq!(imported.atoms.len(), 2);
        assert_eq!(imported.bonds.len(), 1);
        assert_eq!(imported.atoms[0].isotope, Some(13));
        assert_eq!(imported.atoms[1].charge, -1);

        reopened
            .write_svg(svg.to_str().unwrap(), 1920., 1080.)
            .unwrap();
        let svg_data = fs::read_to_string(&svg).unwrap();
        assert!(svg_data.starts_with("<svg "));
        assert!(svg_data.contains("<line "));
        assert!(svg_data.contains(">heat</text>"));

        for path in [mols, mol, svg] {
            let _ = fs::remove_file(path);
        }
    }

    #[test]
    fn undo_redo_remains_consistent_at_history_limit() {
        let mut e = Editor::new();
        for i in 0..125 {
            e.checkpoint();
            e.add_atom(vec2(i as f32 * 2., 0.), "C");
        }
        assert_eq!(e.mol.atoms.len(), 125);
        for _ in 0..100 {
            e.undo();
        }
        assert_eq!(e.mol.atoms.len(), 25);
        for _ in 0..100 {
            e.redo();
        }
        assert_eq!(e.mol.atoms.len(), 125);
        assert_eq!(chemistry::analyze(&e.mol).atom_count, 125);
    }
}
