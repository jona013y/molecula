use crate::{chemistry, Graphic, Molecule};
use std::collections::{BTreeMap, BTreeSet};

#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub enum Role {
    Reactant,
    Product,
    Agent,
}

pub struct ReactionReport {
    pub reactants: Vec<String>,
    pub products: Vec<String>,
    pub agents: Vec<String>,
    pub balanced: Option<bool>,
    pub charge_left: i32,
    pub charge_right: i32,
    pub warnings: Vec<String>,
    pub bond_changes: Vec<String>,
}

fn components(m: &Molecule) -> Vec<Vec<usize>> {
    let mut seen = vec![false; m.atoms.len()];
    let mut result = Vec::new();
    for root in 0..m.atoms.len() {
        if seen[root] {
            continue;
        }
        let mut stack = vec![root];
        let mut group = Vec::new();
        seen[root] = true;
        while let Some(i) = stack.pop() {
            group.push(i);
            for b in &m.bonds {
                let other = if b.a == i {
                    Some(b.b)
                } else if b.b == i {
                    Some(b.a)
                } else {
                    None
                };
                if let Some(j) = other {
                    if !seen[j] {
                        seen[j] = true;
                        stack.push(j);
                    }
                }
            }
        }
        result.push(group);
    }
    result
}

pub fn analyze(m: &Molecule, graphics: &[Graphic]) -> Result<ReactionReport, String> {
    let (start, end) = graphics
        .iter()
        .find_map(|g| match g {
            Graphic::Arrow {
                start, end, kind, ..
            } if kind == "reaction" || kind == "equilibrium" || kind == "retrosynthesis" => {
                Some((*start, *end))
            }
            _ => None,
        })
        .ok_or("Draw a reaction, equilibrium, or retrosynthesis arrow first")?;
    let axis = end - start;
    if axis.length_squared() < 100. {
        return Err("Reaction arrow is too short".into());
    }
    let mut out = ReactionReport {
        reactants: Vec::new(),
        products: Vec::new(),
        agents: Vec::new(),
        balanced: None,
        charge_left: 0,
        charge_right: 0,
        warnings: Vec::new(),
        bond_changes: Vec::new(),
    };
    let mut left = BTreeMap::<String, usize>::new();
    let mut right = BTreeMap::<String, usize>::new();
    let mut left_maps = BTreeSet::new();
    let mut right_maps = BTreeSet::new();
    let mut left_bonds = BTreeMap::<(u16, u16), u8>::new();
    let mut right_bonds = BTreeMap::<(u16, u16), u8>::new();
    let mut left_elements = BTreeMap::<u16, String>::new();
    let mut right_elements = BTreeMap::<u16, String>::new();
    let mut reliable = true;
    for group in components(m) {
        let center = group
            .iter()
            .map(|&i| m.atoms[i].pos)
            .sum::<macroquad::prelude::Vec2>()
            / group.len() as f32;
        let t = (center - start).dot(axis) / axis.length_squared();
        let role = if t < 0.45 {
            Role::Reactant
        } else if t > 0.55 {
            Role::Product
        } else {
            Role::Agent
        };
        let mut sub = Molecule::default();
        let mut remap = BTreeMap::new();
        for &i in &group {
            remap.insert(i, sub.atoms.len());
            sub.atoms.push(m.atoms[i].clone());
        }
        for b in &m.bonds {
            if let (Some(&a), Some(&c)) = (remap.get(&b.a), remap.get(&b.b)) {
                let mut bond = b.clone();
                bond.a = a;
                bond.b = c;
                sub.bonds.push(bond);
            }
        }
        let a = chemistry::analyze(&sub);
        if !a.warnings.is_empty() || a.implicit_h.iter().any(Option::is_none) {
            reliable = false;
            out.warnings.extend(a.warnings);
        }
        let formula = if a.formula.is_empty() {
            "?".into()
        } else {
            a.formula.clone()
        };
        let component_summary = match a.molar_mass {
            Some(mass) => format!("{formula} ({mass:.3} g/mol)"),
            None => format!("{formula} (molar mass unavailable)"),
        };
        match role {
            Role::Reactant | Role::Product => {
                let (counts, maps, names, charge) = if role == Role::Reactant {
                    (
                        &mut left,
                        &mut left_maps,
                        &mut out.reactants,
                        &mut out.charge_left,
                    )
                } else {
                    (
                        &mut right,
                        &mut right_maps,
                        &mut out.products,
                        &mut out.charge_right,
                    )
                };
                names.push(component_summary);
                *charge += a.formal_charge;
                for (el, n) in a.composition {
                    *counts.entry(el).or_default() += n;
                }
                let elements = if role == Role::Reactant {
                    &mut left_elements
                } else {
                    &mut right_elements
                };
                for atom in &sub.atoms {
                    if let Some(map) = atom.atom_map {
                        if !maps.insert(map) {
                            out.warnings
                                .push(format!("Atom map {map} is repeated on one side"));
                        }
                        elements.insert(map, atom.element.clone());
                    }
                }
                let mapped_bonds = if role == Role::Reactant {
                    &mut left_bonds
                } else {
                    &mut right_bonds
                };
                for bond in &sub.bonds {
                    if let (Some(a), Some(b)) =
                        (sub.atoms[bond.a].atom_map, sub.atoms[bond.b].atom_map)
                    {
                        let pair = (a.min(b), a.max(b));
                        mapped_bonds.insert(pair, bond.order);
                    }
                }
            }
            Role::Agent => out.agents.push(component_summary),
        }
    }
    if out.reactants.is_empty() || out.products.is_empty() {
        out.warnings
            .push("Place structures on both sides of the arrow".into());
    } else if reliable {
        out.balanced = Some(left == right && out.charge_left == out.charge_right);
    }
    if !left_maps.is_empty() || !right_maps.is_empty() {
        for map in left_maps.symmetric_difference(&right_maps) {
            out.warnings
                .push(format!("Atom map {map} occurs on only one side"));
        }
        for (map, element) in &left_elements {
            if let Some(other) = right_elements.get(map) {
                if element != other {
                    out.warnings.push(format!(
                        "Atom map {map} changes element: {element} → {other}"
                    ));
                }
            }
        }
        for pair in left_bonds
            .keys()
            .chain(right_bonds.keys())
            .collect::<BTreeSet<_>>()
        {
            let before = left_bonds.get(pair).copied().unwrap_or(0);
            let after = right_bonds.get(pair).copied().unwrap_or(0);
            if before == after {
                continue;
            }
            let label = if before == 0 {
                format!("{}-{} formed (order {after})", pair.0, pair.1)
            } else if after == 0 {
                format!("{}-{} broken (order {before})", pair.0, pair.1)
            } else {
                format!("{}-{} order {before} → {after}", pair.0, pair.1)
            };
            out.bond_changes.push(label);
        }
    }
    out.warnings.dedup();
    Ok(out)
}

pub fn report_text(r: &ReactionReport) -> String {
    let side = |v: &Vec<String>| {
        if v.is_empty() {
            "(none)".into()
        } else {
            v.join(" + ")
        }
    };
    let balance = match r.balanced {
        Some(true) => "Balanced by elements and formal charge",
        Some(false) => "Not balanced by elements and formal charge",
        None => "Balance unavailable: unresolved chemistry or incomplete sides",
    };
    let mut s=format!("Reaction analysis (first reaction arrow)\nReactants: {}\nProducts: {}\nAgents: {}\nFormal charge: {} → {}\n{}\nAssumes coefficient 1 per disconnected component.",side(&r.reactants),side(&r.products),side(&r.agents),r.charge_left,r.charge_right,balance);
    if !r.bond_changes.is_empty() {
        s.push_str("\nMapped bond changes:\n");
        s.push_str(&r.bond_changes.join("\n"));
    }
    if !r.warnings.is_empty() {
        s.push_str("\nWarnings:\n");
        s.push_str(&r.warnings.join("\n"));
    }
    s
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::Atom;
    use macroquad::prelude::vec2;
    #[test]
    fn balances_identical_sides_and_detects_mismatch() {
        let mut m = Molecule::default();
        m.atoms.push(Atom::new(vec2(100., 100.), "C"));
        m.atoms.push(Atom::new(vec2(400., 100.), "C"));
        let arrow = vec![Graphic::Arrow {
            start: vec2(200., 100.),
            end: vec2(300., 100.),
            kind: "reaction".into(),
            above: String::new(),
            below: String::new(),
        }];
        assert_eq!(analyze(&m, &arrow).unwrap().balanced, Some(true));
        m.atoms[1].element = "O".into();
        assert_eq!(analyze(&m, &arrow).unwrap().balanced, Some(false));
    }
    #[test]
    fn requires_a_reaction_arrow() {
        assert!(analyze(&Molecule::default(), &[]).is_err());
    }
    #[test]
    fn detects_broken_mapped_bond() {
        use crate::{Bond, BondStyle};
        let mut m = Molecule::default();
        for (x, map) in [(100., 1), (120., 2), (400., 1), (430., 2)] {
            let mut a = Atom::new(vec2(x, 100.), "C");
            a.atom_map = Some(map);
            m.atoms.push(a);
        }
        m.bonds.push(Bond {
            a: 0,
            b: 1,
            order: 1,
            style: BondStyle::Normal,
            stereo: None,
            query: None,
        });
        let arrow = vec![Graphic::Arrow {
            start: vec2(200., 100.),
            end: vec2(300., 100.),
            kind: "reaction".into(),
            above: String::new(),
            below: String::new(),
        }];
        let r = analyze(&m, &arrow).unwrap();
        assert!(r.bond_changes.iter().any(|s| s.contains("broken")));
    }
}
