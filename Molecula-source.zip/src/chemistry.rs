use crate::{BondStyle, Molecule};
use std::collections::BTreeMap;

pub const SYMBOLS: [&str; 118] = [
    "H", "He", "Li", "Be", "B", "C", "N", "O", "F", "Ne", "Na", "Mg", "Al", "Si", "P", "S", "Cl",
    "Ar", "K", "Ca", "Sc", "Ti", "V", "Cr", "Mn", "Fe", "Co", "Ni", "Cu", "Zn", "Ga", "Ge", "As",
    "Se", "Br", "Kr", "Rb", "Sr", "Y", "Zr", "Nb", "Mo", "Tc", "Ru", "Rh", "Pd", "Ag", "Cd", "In",
    "Sn", "Sb", "Te", "I", "Xe", "Cs", "Ba", "La", "Ce", "Pr", "Nd", "Pm", "Sm", "Eu", "Gd", "Tb",
    "Dy", "Ho", "Er", "Tm", "Yb", "Lu", "Hf", "Ta", "W", "Re", "Os", "Ir", "Pt", "Au", "Hg", "Tl",
    "Pb", "Bi", "Po", "At", "Rn", "Fr", "Ra", "Ac", "Th", "Pa", "U", "Np", "Pu", "Am", "Cm", "Bk",
    "Cf", "Es", "Fm", "Md", "No", "Lr", "Rf", "Db", "Sg", "Bh", "Hs", "Mt", "Ds", "Rg", "Cn", "Nh",
    "Fl", "Mc", "Lv", "Ts", "Og",
];

pub fn valid_element(s: &str) -> bool {
    SYMBOLS.contains(&s)
}
fn standard_mass(s: &str) -> Option<f64> {
    Some(match s {
        "H" => 1.008,
        "B" => 10.81,
        "C" => 12.011,
        "N" => 14.007,
        "O" => 15.999,
        "F" => 18.998403,
        "Si" => 28.085,
        "P" => 30.973762,
        "S" => 32.06,
        "Cl" => 35.45,
        "Br" => 79.904,
        "I" => 126.90447,
        "Na" => 22.989769,
        "K" => 39.0983,
        "Mg" => 24.305,
        "Ca" => 40.078,
        "Fe" => 55.845,
        "Cu" => 63.546,
        "Zn" => 65.38,
        "Ag" => 107.8682,
        "Pt" => 195.084,
        "Au" => 196.96657,
        _ => return None,
    })
}
fn isotope_mass(s: &str, n: u16) -> Option<f64> {
    Some(match (s, n) {
        ("H", 1) => 1.00782503223,
        ("H", 2) => 2.01410177812,
        ("H", 3) => 3.01604928199,
        ("C", 12) => 12.,
        ("C", 13) => 13.00335483507,
        ("N", 14) => 14.00307400443,
        ("N", 15) => 15.00010889888,
        ("O", 16) => 15.99491461957,
        ("O", 17) => 16.99913175650,
        ("O", 18) => 17.99915961286,
        ("S", 32) => 31.9720711744,
        ("Cl", 35) => 34.968852682,
        ("Br", 79) => 78.9183376,
        _ => return None,
    })
}
fn mono_mass(s: &str) -> Option<f64> {
    Some(match s {
        "H" => 1.00782503223,
        "C" => 12.,
        "N" => 14.00307400443,
        "O" => 15.99491461957,
        "F" => 18.998403163,
        "P" => 30.973761998,
        "S" => 31.9720711744,
        "Cl" => 34.968852682,
        "Br" => 78.9183376,
        "I" => 126.904468,
        _ => return None,
    })
}

#[derive(Debug, Clone)]
pub struct Analysis {
    pub formula: String,
    pub composition: Vec<(String, usize)>,
    pub formal_charge: i32,
    pub atom_count: usize,
    pub bond_count: usize,
    pub heavy_atom_count: usize,
    pub molar_mass: Option<f64>,
    pub exact_mass: Option<f64>,
    pub warnings: Vec<String>,
    pub implicit_h: Vec<Option<u8>>,
}

fn target_valence(element: &str, charge: i8, aromatic: bool) -> Option<i16> {
    if aromatic && element == "C" {
        return Some(3);
    }
    Some(match (element, charge) {
        ("C", 0) => 4,
        ("N", 0) => 3,
        ("N", 1) => 4,
        ("O", 0) => 2,
        ("O", -1) => 1,
        ("O", 1) => 3,
        ("S", 0) => 2,
        ("P", 0) => 3,
        ("B", 0) => 3,
        ("F" | "Cl" | "Br" | "I", 0) => 1,
        ("H", 0) => 1,
        _ => return None,
    })
}

pub fn analyze(m: &Molecule) -> Analysis {
    let mut warnings = Vec::new();
    let mut counts: BTreeMap<String, usize> = BTreeMap::new();
    let mut mass = Some(0.);
    let mut exact = Some(0.);
    let mut added_h = 0usize;
    let mut implicit = Vec::with_capacity(m.atoms.len());
    // Build per-atom degree and bond valence once. The inspector calls analyze
    // during rendering, so scanning every bond for every atom made large
    // structures quadratic and could freeze the UI.
    let mut degrees = vec![0i16; m.atoms.len()];
    let mut valences = vec![0i16; m.atoms.len()];
    for b in &m.bonds {
        let contribution = if b.style == BondStyle::Coordinate {
            0
        } else if b.style == BondStyle::Aromatic {
            1
        } else {
            b.order as i16
        };
        for index in [b.a, b.b] {
            if let (Some(degree), Some(valence)) = (degrees.get_mut(index), valences.get_mut(index))
            {
                *degree += 1;
                *valence += contribution;
            }
        }
    }
    for (i, a) in m.atoms.iter().enumerate() {
        if !valid_element(&a.element) {
            warnings.push(format!(
                "Atom {} has an unknown or pseudo element: {}",
                i + 1,
                a.element
            ));
        }
        let val = valences[i];
        let degree = degrees[i];
        let ih = if let Some(x) = a.implicit_h_override {
            Some(x)
        } else if a.element == "H" {
            Some(0)
        } else if a.radical > 0 || a.query.is_some() || a.r_group.is_some() {
            None
        } else if a.aromatic && a.element == "C" {
            Some((3 - degree).max(0) as u8)
        } else if a.aromatic && a.element == "N" {
            Some(0)
        } else {
            target_valence(&a.element, a.charge, a.aromatic)
                .map(|target| (target - val - a.explicit_h as i16).clamp(0, 8) as u8)
                .or_else(|| {
                    if valid_element(&a.element) {
                        Some(0)
                    } else {
                        None
                    }
                })
        };
        if let Some(target) = target_valence(&a.element, a.charge, a.aromatic) {
            if val + a.explicit_h as i16 > target {
                warnings.push(format!(
                    "Atom {} ({}): bond valence {} exceeds typical valence {}",
                    i + 1,
                    a.element,
                    val + a.explicit_h as i16,
                    target
                ));
            }
        }
        implicit.push(ih);
        *counts.entry(a.element.clone()).or_default() += 1;
        if let Some(h) = ih {
            added_h += h as usize;
            if h > 0 {
                *counts.entry("H".into()).or_default() += h as usize;
            }
        } else {
            mass = None;
            exact = None;
            warnings.push(format!(
                "Atom {}: implicit hydrogen count is unresolved",
                i + 1
            ));
        }
        if a.explicit_h > 0 {
            added_h += a.explicit_h as usize;
            *counts.entry("H".into()).or_default() += a.explicit_h as usize;
        }
        mass = mass.and_then(|x| {
            if let Some(n) = a.isotope {
                isotope_mass(&a.element, n)
            } else {
                standard_mass(&a.element)
            }
            .map(|v| x + v)
        });
        exact = exact.and_then(|x| {
            if let Some(n) = a.isotope {
                isotope_mass(&a.element, n)
            } else {
                mono_mass(&a.element)
            }
            .map(|v| x + v)
        });
    }
    mass = mass.and_then(|x| standard_mass("H").map(|v| x + v * added_h as f64));
    exact = exact.and_then(|x| mono_mass("H").map(|v| x + v * added_h as f64));
    let mut ordered = Vec::new();
    if let Some(n) = counts.remove("C") {
        ordered.push(("C".to_string(), n));
    }
    if let Some(n) = counts.remove("H") {
        ordered.push(("H".to_string(), n));
    }
    ordered.extend(counts);
    let formula = ordered
        .iter()
        .map(|(el, n)| {
            if *n == 1 {
                el.clone()
            } else {
                format!("{el}{n}")
            }
        })
        .collect::<String>();
    let composition = ordered;
    let formal_charge = m.atoms.iter().map(|a| a.charge as i32).sum();
    let atom_count = m.atoms.len();
    let bond_count = m.bonds.len();
    let heavy_atom_count = m.atoms.iter().filter(|a| a.element != "H").count();
    Analysis {
        formula,
        composition,
        formal_charge,
        atom_count,
        bond_count,
        heavy_atom_count,
        molar_mass: mass,
        exact_mass: exact,
        warnings,
        implicit_h: implicit,
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::{Atom, Bond, BondStyle};
    use macroquad::prelude::vec2;
    #[test]
    fn ethanol_formula_and_mass() {
        let mut m = Molecule::default();
        for x in ["C", "C", "O"] {
            m.atoms.push(Atom::new(vec2(0., 0.), x));
        }
        for (a, b) in [(0, 1), (1, 2)] {
            m.bonds.push(Bond {
                a,
                b,
                order: 1,
                style: BondStyle::Normal,
                stereo: None,
                query: None,
            });
        }
        let a = analyze(&m);
        assert_eq!(a.formula, "C2H6O");
        assert!((a.molar_mass.unwrap() - 46.069).abs() < 0.01);
    }
    #[test]
    fn invalid_valence_is_reported() {
        let mut m = Molecule::default();
        m.atoms.push(Atom::new(vec2(0., 0.), "C"));
        for i in 1..=5 {
            m.atoms.push(Atom::new(vec2(i as f32, 0.), "H"));
            m.bonds.push(Bond {
                a: 0,
                b: i,
                order: 1,
                style: BondStyle::Normal,
                stereo: None,
                query: None,
            });
        }
        assert!(analyze(&m).warnings.iter().any(|x| x.contains("exceeds")));
    }

    #[test]
    fn analyzes_large_chain_without_quadratic_bond_scans() {
        let n = 20_000usize;
        let mut m = Molecule::default();
        m.atoms
            .extend((0..n).map(|i| Atom::new(vec2(i as f32, 0.), "C")));
        m.bonds.extend((1..n).map(|i| Bond {
            a: i - 1,
            b: i,
            order: 1,
            style: BondStyle::Normal,
            stereo: None,
            query: None,
        }));
        let a = analyze(&m);
        assert_eq!(a.atom_count, n);
        assert_eq!(a.bond_count, n - 1);
        assert_eq!(a.implicit_h[0], Some(3));
        assert_eq!(a.implicit_h[n / 2], Some(2));
        assert_eq!(a.implicit_h[n - 1], Some(3));
    }
}
