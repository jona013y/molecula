use crate::chemistry::valid_element;

#[derive(Debug, Clone, PartialEq, Eq)]
pub enum QuickAction {
    Bond(u8),
    BondQuery(&'static str),
    Element(String),
    Charge(i8),
    RGroup(u16),
    AtomMap(u16),
    Query(String),
}
#[derive(Default)]
pub struct QuickInput {
    pub pending: String,
    last: f64,
}
impl QuickInput {
    pub fn push(&mut self, ch: char, time: f64) -> Vec<QuickAction> {
        let mut out = Vec::new();
        if !self.pending.is_empty() && time - self.last > 0.65 {
            out.extend(self.flush());
        }
        if ch.is_whitespace() {
            out.extend(self.flush());
            return out;
        }
        let candidate = format!("{}{}", self.pending, ch);
        if is_prefix(&candidate) {
            self.pending = candidate;
            self.last = time;
        } else {
            out.extend(self.flush());
            let single = ch.to_string();
            if is_prefix(&single) {
                self.pending = single;
                self.last = time;
            }
        }
        out
    }
    pub fn tick(&mut self, time: f64) -> Vec<QuickAction> {
        if !self.pending.is_empty() && time - self.last > 0.65 {
            self.flush()
        } else {
            vec![]
        }
    }
    pub fn flush(&mut self) -> Vec<QuickAction> {
        let text = std::mem::take(&mut self.pending);
        parse(&text).into_iter().collect()
    }
}
fn is_prefix(s: &str) -> bool {
    if s.is_empty() {
        return true;
    }
    if [
        "1", "2", "3", "4", "5", "6", "7", "0", "12", "14", "24", "+", "-", "*", "Q",
    ]
    .iter()
    .any(|x| x.starts_with(s))
    {
        return true;
    }
    if s.starts_with('R') && s[1..].chars().all(|c| c.is_ascii_digit()) {
        return true;
    }
    if s.starts_with('M') && s[1..].chars().all(|c| c.is_ascii_digit()) {
        return true;
    }
    if s.starts_with('.') && s.len() < 8 {
        return true;
    }
    if valid_element(s) {
        return true;
    }
    crate::chemistry::SYMBOLS.iter().any(|x| x.starts_with(s))
}
pub fn parse(s: &str) -> Option<QuickAction> {
    Some(match s {
        "1" => QuickAction::Bond(1),
        "2" => QuickAction::Bond(2),
        "3" => QuickAction::Bond(3),
        "4" => QuickAction::Bond(4),
        "5" => QuickAction::Bond(5),
        "6" => QuickAction::Bond(6),
        "7" => QuickAction::Bond(7),
        "0" => QuickAction::BondQuery("any"),
        "12" => QuickAction::BondQuery("single-or-double"),
        "14" => QuickAction::BondQuery("single-or-aromatic"),
        "24" => QuickAction::BondQuery("double-or-aromatic"),
        "+" => QuickAction::Charge(1),
        "-" => QuickAction::Charge(-1),
        "*" => QuickAction::Query("any atom".into()),
        "Q" => QuickAction::Query("heteroatom".into()),
        _ if s.starts_with('R') && s.len() > 1 => {
            let n = s[1..].parse().ok()?;
            if n == 0 || n > 32767 {
                return None;
            }
            QuickAction::RGroup(n)
        }
        _ if s.starts_with('M') && s.len() > 1 => QuickAction::AtomMap(s[1..].parse().ok()?),
        _ if s.starts_with('.') && s.len() > 1 => QuickAction::Query(s.into()),
        _ if valid_element(s) => QuickAction::Element(s.into()),
        _ => return None,
    })
}

#[cfg(test)]
mod tests {
    use super::*;
    #[test]
    fn multi_key_bond_does_not_commit_first_key() {
        let mut q = QuickInput::default();
        assert!(q.push('1', 0.).is_empty());
        assert!(q.push('2', 0.2).is_empty());
        assert_eq!(
            q.tick(0.9),
            vec![QuickAction::BondQuery("single-or-double")]
        );
    }
    #[test]
    fn cl_is_not_two_elements() {
        let mut q = QuickInput::default();
        assert!(q.push('C', 0.).is_empty());
        assert!(q.push('l', 0.1).is_empty());
        assert_eq!(q.tick(0.8), vec![QuickAction::Element("Cl".into())]);
    }
    #[test]
    fn incomplete_group_is_not_action() {
        assert_eq!(parse("R"), None);
        assert_eq!(parse("R32768"), None);
    }
}
