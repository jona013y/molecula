#define AppName "Molecula"
#define AppVersion "0.5.4"
#define AppExe "Molecula.exe"

[Setup]
AppId={{94EC2F58-5637-4C24-89D3-72C9DC4F1E17}
AppName={#AppName}
AppVersion={#AppVersion}
AppPublisher=Molecula
DefaultDirName={localappdata}\Programs\Molecula
DefaultGroupName=Molecula
PrivilegesRequired=lowest
ArchitecturesAllowed=x64
ArchitecturesInstallIn64BitMode=x64
UninstallDisplayIcon={app}\{#AppExe}
SetupIconFile=..\..\assets\Molecula.ico
OutputDir=..\..\dist\windows
OutputBaseFilename=Molecula-Windows-Setup
Compression=lzma2
SolidCompression=yes
WizardStyle=modern
CloseApplications=yes
RestartApplications=no

[Tasks]
Name: "desktopicon"; Description: "Create a desktop shortcut"; GroupDescription: "Additional shortcuts:"; Flags: unchecked

[Files]
Source: "..\..\target\release\marvin-rust.exe"; DestDir: "{app}"; DestName: "{#AppExe}"; Flags: ignoreversion
Source: "..\..\assets\Molecula.ico"; DestDir: "{app}"; Flags: ignoreversion

[Icons]
Name: "{autoprograms}\Molecula"; Filename: "{app}\{#AppExe}"; IconFilename: "{app}\Molecula.ico"
Name: "{autoprograms}\Molecula\Open startup log"; Filename: "{sys}\notepad.exe"; Parameters: """{localappdata}\Molecula\startup.log"""; IconFilename: "{sys}\notepad.exe"
Name: "{autodesktop}\Molecula"; Filename: "{app}\{#AppExe}"; IconFilename: "{app}\Molecula.ico"; Tasks: desktopicon
Name: "{autoprograms}\Uninstall Molecula"; Filename: "{uninstallexe}"

[Run]
Filename: "{app}\{#AppExe}"; Description: "Launch Molecula"; Flags: nowait postinstall skipifsilent
