# REA findings

- The installed target is `/Applications/MarvinSuite/MarvinSketch.app`, version 23.17.0, based on its Info.plist. REA evidence: `ev_79511e7507f0e377d9ffc8cefd5e422390a786df0c3547ce80c37697f50beb0f`.
- The bundle declares editing support for `mrv`, `cml`, `mol`, `smiles`, `smarts`, `rxn`, `rd`, `rdf`, and `cdx`. This is a file association declaration, not proof of working import/export behavior.
- The editor JAR is a ZIP archive. REA inventoried its entries and found model classes such as `AtomWrapper`, `BondWrapper`, `MoleculeWrapper`, as well as molecule fusion helpers. REA evidence: `ev_78150950f0df315a4fab9b20f7b64c44c4731b028dead0b99cfc97bda8395e40`.
- Launching the installed app displayed a license warning and did not expose the sketch editor. Therefore its actual toolbar, interactions, rendering, and chemical behavior were not observed. This clone's UI and detailed interaction choices are independent implementation decisions.

The full REA evidence is saved in `rea-evidence.json`.
